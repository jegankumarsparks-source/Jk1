"use client"

import { useState } from "react"
import { soundCategories } from "@/lib/meditation-data"
import { Card, CardContent } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Volume2 } from "lucide-react"

interface ActiveSound {
  id: string
  volume: number
}

export function SoundPlayer() {
  const [activeSounds, setActiveSounds] = useState<ActiveSound[]>([])

  const toggleSound = (soundId: string) => {
    setActiveSounds((prev) => {
      const existing = prev.find((s) => s.id === soundId)
      if (existing) {
        return prev.filter((s) => s.id !== soundId)
      }
      return [...prev, { id: soundId, volume: 70 }]
    })
  }

  const updateVolume = (soundId: string, volume: number) => {
    setActiveSounds((prev) =>
      prev.map((s) => (s.id === soundId ? { ...s, volume } : s))
    )
  }

  const isActive = (soundId: string) => activeSounds.some((s) => s.id === soundId)
  const getVolume = (soundId: string) => activeSounds.find((s) => s.id === soundId)?.volume ?? 70

  return (
    <section id="sounds" className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-primary font-medium mb-2">இயற்கை ஒலிகள்</p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            அமைதியான சூழலை உருவாக்குங்கள்
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            பல ஒலிகளை ஒன்றாக இணைத்து உங்களுக்கான சூழலை உருவாக்குங்கள்
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {soundCategories.map((sound) => (
            <Card
              key={sound.id}
              className={`cursor-pointer transition-all duration-300 ${
                isActive(sound.id)
                  ? "bg-primary/20 border-primary"
                  : "bg-card hover:bg-card/80 border-border hover:border-primary/50"
              }`}
              onClick={() => toggleSound(sound.id)}
            >
              <CardContent className="p-4 text-center">
                <div
                  className={`w-16 h-16 rounded-2xl mx-auto mb-3 flex items-center justify-center text-3xl transition-all ${
                    isActive(sound.id) ? "bg-primary/30 scale-110" : "bg-secondary"
                  }`}
                >
                  {sound.icon}
                </div>
                <p className="font-medium text-foreground">{sound.name}</p>
                
                {isActive(sound.id) && (
                  <div 
                    className="mt-4 flex items-center gap-2"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Volume2 className="w-4 h-4 text-primary" />
                    <Slider
                      value={[getVolume(sound.id)]}
                      onValueChange={(value) => updateVolume(sound.id, value[0])}
                      max={100}
                      step={1}
                      className="flex-1"
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Active sounds indicator */}
        {activeSounds.length > 0 && (
          <div className="mt-8 text-center">
            <div className="inline-flex items-center gap-2 bg-card border border-border rounded-full px-6 py-3">
              <div className="w-3 h-3 bg-primary rounded-full animate-pulse" />
              <span className="text-foreground">
                {activeSounds.length} ஒலிகள் இயங்குகின்றன
              </span>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
