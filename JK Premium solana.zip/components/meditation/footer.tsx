import { Sparkles, Heart } from "lucide-react"

export function Footer() {
  return (
    <footer className="py-12 border-t border-border">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <span className="text-xl font-bold text-foreground">அமைதி</span>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap items-center justify-center gap-6">
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors text-sm">
              தனியுரிமை கொள்கை
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors text-sm">
              பயன்பாட்டு விதிமுறைகள்
            </a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors text-sm">
              தொடர்பு கொள்ள
            </a>
          </nav>

          {/* Copyright */}
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <span>உருவாக்கியது</span>
            <Heart className="w-4 h-4 text-primary fill-primary" />
            <span>அன்புடன்</span>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-muted-foreground text-sm">
            &copy; 2026 அமைதி. அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.
          </p>
        </div>
      </div>
    </footer>
  )
}
