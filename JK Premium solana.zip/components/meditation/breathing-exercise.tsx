"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Play, Pause, RotateCcw } from "lucide-react"

type BreathPhase = "inhale" | "hold" | "exhale" | "rest"

const phaseConfig = {
  inhale: { duration: 4, label: "உள்ளிழு", color: "text-primary" },
  hold: { duration: 4, label: "நிறுத்து", color: "text-accent" },
  exhale: { duration: 6, label: "வெளிவிடு", color: "text-primary" },
  rest: { duration: 2, label: "ஓய்வு", color: "text-muted-foreground" }
}

const phaseOrder: BreathPhase[] = ["inhale", "hold", "exhale", "rest"]

export function BreathingExercise() {
  const [isActive, setIsActive] = useState(false)
  const [phase, setPhase] = useState<BreathPhase>("inhale")
  const [countdown, setCountdown] = useState(phaseConfig.inhale.duration)
  const [cycles, setCycles] = useState(0)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    if (isActive) {
      intervalRef.current = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            const currentIndex = phaseOrder.indexOf(phase)
            const nextIndex = (currentIndex + 1) % phaseOrder.length
            const nextPhase = phaseOrder[nextIndex]
            
            if (nextPhase === "inhale") {
              setCycles((c) => c + 1)
            }
            
            setPhase(nextPhase)
            return phaseConfig[nextPhase].duration
          }
          return prev - 1
        })
      }, 1000)
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isActive, phase])

  const handleReset = () => {
    setIsActive(false)
    setPhase("inhale")
    setCountdown(phaseConfig.inhale.duration)
    setCycles(0)
  }

  const getCircleScale = () => {
    if (phase === "inhale") return "scale-100"
    if (phase === "hold") return "scale-100"
    if (phase === "exhale") return "scale-75"
    return "scale-75"
  }

  return (
    <section id="breathing" className="py-16 md:py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-primary font-medium mb-2">சுவாசப் பயிற்சி</p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            4-4-6 சுவாச முறை
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            மன அழுத்தத்தைக் குறைக்கும் எளிய சுவாசப் பயிற்சி
          </p>
        </div>

        <div className="max-w-lg mx-auto">
          <div className="bg-card rounded-3xl p-8 md:p-12 border border-border">
            {/* Breathing Circle */}
            <div className="relative w-64 h-64 mx-auto mb-8">
              {/* Outer ring */}
              <div className="absolute inset-0 rounded-full border-4 border-border" />
              
              {/* Animated circle */}
              <div
                className={`absolute inset-4 rounded-full bg-primary/20 flex items-center justify-center transition-transform duration-1000 ease-in-out ${getCircleScale()}`}
              >
                <div className={`text-center transition-all duration-300 ${phaseConfig[phase].color}`}>
                  <p className="text-6xl font-bold">{countdown}</p>
                  <p className="text-xl mt-2">{phaseConfig[phase].label}</p>
                </div>
              </div>

              {/* Pulse effect */}
              {isActive && (
                <div className="absolute inset-0 rounded-full border-2 border-primary animate-ping opacity-30" />
              )}
            </div>

            {/* Cycles counter */}
            <div className="text-center mb-8">
              <p className="text-muted-foreground">
                முடிந்த சுழற்சிகள்: <span className="text-primary font-bold">{cycles}</span>
              </p>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4">
              <Button
                size="lg"
                className="rounded-full px-8 gap-2"
                onClick={() => setIsActive(!isActive)}
              >
                {isActive ? (
                  <>
                    <Pause className="w-5 h-5" />
                    நிறுத்து
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5" />
                    தொடங்கு
                  </>
                )}
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="rounded-full bg-transparent"
                onClick={handleReset}
              >
                <RotateCcw className="w-5 h-5" />
              </Button>
            </div>

            {/* Instructions */}
            <div className="mt-8 grid grid-cols-4 gap-2 text-center text-sm">
              <div className={`p-3 rounded-xl ${phase === "inhale" ? "bg-primary/20" : "bg-secondary"}`}>
                <p className="font-medium text-foreground">உள்ளிழு</p>
                <p className="text-muted-foreground">4 வி</p>
              </div>
              <div className={`p-3 rounded-xl ${phase === "hold" ? "bg-primary/20" : "bg-secondary"}`}>
                <p className="font-medium text-foreground">நிறுத்து</p>
                <p className="text-muted-foreground">4 வி</p>
              </div>
              <div className={`p-3 rounded-xl ${phase === "exhale" ? "bg-primary/20" : "bg-secondary"}`}>
                <p className="font-medium text-foreground">வெளிவிடு</p>
                <p className="text-muted-foreground">6 வி</p>
              </div>
              <div className={`p-3 rounded-xl ${phase === "rest" ? "bg-primary/20" : "bg-secondary"}`}>
                <p className="font-medium text-foreground">ஓய்வு</p>
                <p className="text-muted-foreground">2 வி</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
