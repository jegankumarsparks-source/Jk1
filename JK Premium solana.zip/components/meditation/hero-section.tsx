"use client"

import { useEffect, useState } from "react"
import { dailyQuotes } from "@/lib/meditation-data"
import { Button } from "@/components/ui/button"
import { Play, Heart } from "lucide-react"

export function HeroSection() {
  const [quote, setQuote] = useState(dailyQuotes[0])

  useEffect(() => {
    const randomIndex = Math.floor(Math.random() * dailyQuotes.length)
    setQuote(dailyQuotes[randomIndex])
  }, [])

  return (
    <section id="home" className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
      {/* Animated background circles */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Greeting */}
          <p className="text-primary font-medium mb-4">வணக்கம்</p>
          
          {/* Main heading */}
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 leading-tight text-balance">
            மன அமைதியை <br />
            <span className="text-primary">கண்டறியுங்கள்</span>
          </h1>

          {/* Quote card */}
          <div className="bg-card/50 backdrop-blur-sm rounded-2xl p-6 md:p-8 border border-border mb-8">
            <p className="text-lg md:text-xl text-foreground mb-3 text-pretty">
              {'"'}{quote.quote}{'"'}
            </p>
            <p className="text-muted-foreground">— {quote.author}</p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="w-full sm:w-auto gap-2 rounded-full px-8">
              <Play className="w-5 h-5" />
              தியானம் தொடங்கு
            </Button>
            <Button size="lg" variant="outline" className="w-full sm:w-auto gap-2 rounded-full px-8 bg-transparent">
              <Heart className="w-5 h-5" />
              இலவச பயிற்சிகள்
            </Button>
          </div>

          {/* Stats */}
          <div className="mt-12 grid grid-cols-3 gap-4 md:gap-8">
            <div className="text-center">
              <p className="text-2xl md:text-3xl font-bold text-primary">50+</p>
              <p className="text-sm text-muted-foreground">தியானங்கள்</p>
            </div>
            <div className="text-center">
              <p className="text-2xl md:text-3xl font-bold text-primary">10K+</p>
              <p className="text-sm text-muted-foreground">பயனர்கள்</p>
            </div>
            <div className="text-center">
              <p className="text-2xl md:text-3xl font-bold text-primary">100%</p>
              <p className="text-sm text-muted-foreground">தமிழில்</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
