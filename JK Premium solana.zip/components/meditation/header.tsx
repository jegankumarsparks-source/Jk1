"use client"

import { useState } from "react"
import { Menu, X, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <span className="text-xl font-bold text-foreground">அமைதி</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <a href="#home" className="text-muted-foreground hover:text-primary transition-colors">முகப்பு</a>
            <a href="#meditations" className="text-muted-foreground hover:text-primary transition-colors">தியானங்கள்</a>
            <a href="#sounds" className="text-muted-foreground hover:text-primary transition-colors">இசை</a>
            <a href="#breathing" className="text-muted-foreground hover:text-primary transition-colors">சுவாசம்</a>
          </nav>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 flex flex-col gap-4">
            <a href="#home" className="text-muted-foreground hover:text-primary transition-colors py-2">முகப்பு</a>
            <a href="#meditations" className="text-muted-foreground hover:text-primary transition-colors py-2">தியானங்கள்</a>
            <a href="#sounds" className="text-muted-foreground hover:text-primary transition-colors py-2">இசை</a>
            <a href="#breathing" className="text-muted-foreground hover:text-primary transition-colors py-2">சுவாசம்</a>
          </nav>
        )}
      </div>
    </header>
  )
}
