"use client"

import { useState } from "react"
import { meditationSessions, type MeditationSession } from "@/lib/meditation-data"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Play, Clock, X } from "lucide-react"

export function MeditationCards() {
  const [selectedSession, setSelectedSession] = useState<MeditationSession | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)

  return (
    <section id="meditations" className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-primary font-medium mb-2">தியானங்கள்</p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            உங்கள் பயணத்தைத் தேர்வு செய்யுங்கள்
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            ஒவ்வொரு தருணத்திற்கும் ஏற்ற தியான வழிகாட்டுதல்கள்
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {meditationSessions.map((session) => (
            <Card
              key={session.id}
              className="group cursor-pointer bg-card hover:bg-card/80 border-border hover:border-primary/50 transition-all duration-300"
              onClick={() => setSelectedSession(session)}
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center text-2xl">
                    {session.icon}
                  </div>
                  <span className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full">
                    {session.category}
                  </span>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  {session.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-4">
                  {session.description}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">{session.duration} நிமிடங்கள்</span>
                  </div>
                  <Button size="sm" variant="ghost" className="group-hover:bg-primary group-hover:text-primary-foreground rounded-full">
                    <Play className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Meditation Player Modal */}
      {selectedSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/90 backdrop-blur-md p-4">
          <div className="bg-card border border-border rounded-3xl p-8 max-w-md w-full relative">
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4"
              onClick={() => {
                setSelectedSession(null)
                setIsPlaying(false)
              }}
            >
              <X className="w-5 h-5" />
            </Button>

            <div className="text-center">
              <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center text-4xl mx-auto mb-6">
                {selectedSession.icon}
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">
                {selectedSession.title}
              </h3>
              <p className="text-muted-foreground mb-8">
                {selectedSession.description}
              </p>

              {/* Timer Display */}
              <div className="mb-8">
                <p className="text-5xl font-bold text-primary">
                  {selectedSession.duration}:00
                </p>
                <p className="text-muted-foreground mt-2">நிமிடங்கள்</p>
              </div>

              {/* Progress Ring */}
              <div className="relative w-48 h-48 mx-auto mb-8">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="96"
                    cy="96"
                    r="88"
                    className="fill-none stroke-secondary"
                    strokeWidth="8"
                  />
                  <circle
                    cx="96"
                    cy="96"
                    r="88"
                    className="fill-none stroke-primary"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray="553"
                    strokeDashoffset={isPlaying ? "138" : "553"}
                    style={{ transition: "stroke-dashoffset 1s ease-in-out" }}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Button
                    size="lg"
                    className="w-20 h-20 rounded-full"
                    onClick={() => setIsPlaying(!isPlaying)}
                  >
                    <Play className={`w-8 h-8 ${isPlaying ? "hidden" : "block"}`} />
                    <span className={`text-2xl ${isPlaying ? "block" : "hidden"}`}>॥</span>
                  </Button>
                </div>
              </div>

              <p className="text-sm text-muted-foreground">
                கண்களை மூடி, ஆழமாக சுவாசிக்கவும்
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
