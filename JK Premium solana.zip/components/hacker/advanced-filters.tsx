"use client";

import { useState } from "react";
import { 
  Sliders, 
  Droplets, 
  TrendingUp, 
  Clock, 
  Shield, 
  Target,
  Zap,
  AlertTriangle
} from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

interface FilterState {
  minLiquidity: number;
  maxLiquidity: number;
  minVolume: number;
  minWinProb: number;
  maxRugScore: number;
  minWhaleScore: number;
  minMomentum: number;
  maxAge: number;
  onlyBuySignals: boolean;
  onlyWhaleAlerts: boolean;
  onlyNewLaunches: boolean;
  onlyLowRisk: boolean;
}

const defaultFilters: FilterState = {
  minLiquidity: 1000,
  maxLiquidity: 10000000,
  minVolume: 0,
  minWinProb: 0,
  maxRugScore: 100,
  minWhaleScore: 0,
  minMomentum: 0,
  maxAge: 1440,
  onlyBuySignals: false,
  onlyWhaleAlerts: false,
  onlyNewLaunches: false,
  onlyLowRisk: false,
};

function formatValue(value: number, type: 'money' | 'percent' | 'time'): string {
  if (type === 'money') {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value}`;
  }
  if (type === 'percent') return `${value}%`;
  if (type === 'time') {
    if (value >= 1440) return '24h+';
    if (value >= 60) return `${Math.floor(value / 60)}h`;
    return `${value}m`;
  }
  return String(value);
}

interface AdvancedFiltersProps {
  onApplyFilters?: (filters: FilterState) => void;
}

export function AdvancedFilters({ onApplyFilters }: AdvancedFiltersProps) {
  const [filters, setFilters] = useState<FilterState>(defaultFilters);
  const [activePreset, setActivePreset] = useState<string | null>(null);
  const [hasChanges, setHasChanges] = useState(false);

  const updateFilters = (newFilters: Partial<FilterState>) => {
    setFilters(f => ({ ...f, ...newFilters }));
    setHasChanges(true);
  };

  const handleApply = () => {
    onApplyFilters?.(filters);
    setHasChanges(false);
  };

  const presets = [
    { 
      id: 'whale-hunter',
      name: 'WHALE HUNTER',
      icon: Target,
      color: 'text-accent',
      filters: {
        ...defaultFilters,
        minWhaleScore: 50,
        minLiquidity: 10000,
        onlyWhaleAlerts: true,
      }
    },
    { 
      id: 'early-gems',
      name: 'EARLY GEMS',
      icon: Zap,
      color: 'text-yellow-400',
      filters: {
        ...defaultFilters,
        maxAge: 180,
        minLiquidity: 3000,
        maxRugScore: 50,
        onlyNewLaunches: true,
      }
    },
    { 
      id: 'safe-plays',
      name: 'SAFE PLAYS',
      icon: Shield,
      color: 'text-primary',
      filters: {
        ...defaultFilters,
        maxRugScore: 35,
        minLiquidity: 20000,
        minWinProb: 50,
        onlyLowRisk: true,
      }
    },
    { 
      id: 'momentum',
      name: 'HIGH MOMENTUM',
      icon: TrendingUp,
      color: 'text-pink-400',
      filters: {
        ...defaultFilters,
        minMomentum: 60,
        minVolume: 5000,
        onlyBuySignals: true,
      }
    },
  ];

  const applyPreset = (preset: (typeof presets)[0]) => {
    setFilters(preset.filters);
    setActivePreset(preset.id);
    setHasChanges(true);
  };

  const resetFilters = () => {
    setFilters(defaultFilters);
    setActivePreset(null);
    setHasChanges(true);
  };

  return (
    <div className="border border-border/50 bg-card/30 backdrop-blur-sm">
      {/* Header */}
      <div className="p-3 sm:p-4 border-b border-border/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-bold tracking-wider">ADVANCED FILTERS</h3>
          </div>
          <button
            type="button"
            onClick={resetFilters}
            className="text-[10px] text-muted-foreground hover:text-primary transition-colors"
          >
            RESET ALL
          </button>
        </div>
      </div>

      {/* Quick Presets */}
      <div className="p-3 sm:p-4 border-b border-border/30">
        <p className="text-[10px] text-muted-foreground mb-3">QUICK PRESETS</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {presets.map((preset) => {
            const Icon = preset.icon;
            const isActive = activePreset === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => applyPreset(preset)}
                className={`flex items-center justify-center gap-1.5 px-3 py-2 text-[10px] font-mono transition-all ${
                  isActive
                    ? `bg-primary/20 border border-primary/50 ${preset.color}`
                    : 'bg-muted/30 border border-border/50 text-muted-foreground hover:border-primary/30 hover:text-foreground'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{preset.name}</span>
                <span className="sm:hidden">{preset.name.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Slider Controls */}
      <div className="p-3 sm:p-4 space-y-5">
        {/* Liquidity Range */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Droplets className="h-3.5 w-3.5 text-primary/70" />
              <span className="text-[10px] text-muted-foreground">MIN LIQUIDITY</span>
            </div>
            <span className="text-xs font-mono text-foreground">
              {formatValue(filters.minLiquidity, 'money')}
            </span>
          </div>
          <Slider
            value={[filters.minLiquidity]}
            min={500}
            max={100000}
            step={500}
            onValueChange={([v]) => setFilters(f => ({ ...f, minLiquidity: v }))}
            className="w-full"
          />
        </div>

        {/* Win Probability */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Target className="h-3.5 w-3.5 text-accent/70" />
              <span className="text-[10px] text-muted-foreground">MIN WIN PROBABILITY</span>
            </div>
            <span className="text-xs font-mono text-foreground">
              {formatValue(filters.minWinProb, 'percent')}
            </span>
          </div>
          <Slider
            value={[filters.minWinProb]}
            min={0}
            max={90}
            step={5}
            onValueChange={([v]) => setFilters(f => ({ ...f, minWinProb: v }))}
            className="w-full"
          />
        </div>

        {/* Rug Score */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-3.5 w-3.5 text-destructive/70" />
              <span className="text-[10px] text-muted-foreground">MAX RUG SCORE</span>
            </div>
            <span className="text-xs font-mono text-foreground">
              {formatValue(filters.maxRugScore, 'percent')}
            </span>
          </div>
          <Slider
            value={[filters.maxRugScore]}
            min={10}
            max={100}
            step={5}
            onValueChange={([v]) => setFilters(f => ({ ...f, maxRugScore: v }))}
            className="w-full"
          />
        </div>

        {/* Whale Score */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Zap className="h-3.5 w-3.5 text-yellow-400/70" />
              <span className="text-[10px] text-muted-foreground">MIN WHALE SCORE</span>
            </div>
            <span className="text-xs font-mono text-foreground">
              {formatValue(filters.minWhaleScore, 'percent')}
            </span>
          </div>
          <Slider
            value={[filters.minWhaleScore]}
            min={0}
            max={90}
            step={5}
            onValueChange={([v]) => setFilters(f => ({ ...f, minWhaleScore: v }))}
            className="w-full"
          />
        </div>

        {/* Momentum Score */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-3.5 w-3.5 text-pink-400/70" />
              <span className="text-[10px] text-muted-foreground">MIN MOMENTUM</span>
            </div>
            <span className="text-xs font-mono text-foreground">
              {formatValue(filters.minMomentum, 'percent')}
            </span>
          </div>
          <Slider
            value={[filters.minMomentum]}
            min={0}
            max={90}
            step={5}
            onValueChange={([v]) => setFilters(f => ({ ...f, minMomentum: v }))}
            className="w-full"
          />
        </div>

        {/* Max Age */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Clock className="h-3.5 w-3.5 text-primary/70" />
              <span className="text-[10px] text-muted-foreground">MAX AGE</span>
            </div>
            <span className="text-xs font-mono text-foreground">
              {formatValue(filters.maxAge, 'time')}
            </span>
          </div>
          <Slider
            value={[filters.maxAge]}
            min={5}
            max={1440}
            step={15}
            onValueChange={([v]) => setFilters(f => ({ ...f, maxAge: v }))}
            className="w-full"
          />
        </div>
      </div>

      {/* Toggle Switches */}
      <div className="p-3 sm:p-4 border-t border-border/30">
        <p className="text-[10px] text-muted-foreground mb-3">QUICK TOGGLES</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="flex items-center justify-between">
            <Label htmlFor="buySignals" className="text-[11px] text-muted-foreground cursor-pointer">
              ONLY BUY SIGNALS
            </Label>
            <Switch
              id="buySignals"
              checked={filters.onlyBuySignals}
              onCheckedChange={(v) => setFilters(f => ({ ...f, onlyBuySignals: v }))}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="whaleAlerts" className="text-[11px] text-muted-foreground cursor-pointer">
              ONLY WHALE ALERTS
            </Label>
            <Switch
              id="whaleAlerts"
              checked={filters.onlyWhaleAlerts}
              onCheckedChange={(v) => setFilters(f => ({ ...f, onlyWhaleAlerts: v }))}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="newLaunches" className="text-[11px] text-muted-foreground cursor-pointer">
              ONLY NEW LAUNCHES
            </Label>
            <Switch
              id="newLaunches"
              checked={filters.onlyNewLaunches}
              onCheckedChange={(v) => setFilters(f => ({ ...f, onlyNewLaunches: v }))}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="lowRisk" className="text-[11px] text-muted-foreground cursor-pointer">
              ONLY LOW RISK
            </Label>
            <Switch
              id="lowRisk"
              checked={filters.onlyLowRisk}
              onCheckedChange={(v) => setFilters(f => ({ ...f, onlyLowRisk: v }))}
            />
          </div>
        </div>
      </div>

      {/* Active Filter Summary */}
      <div className="p-3 sm:p-4 bg-muted/20 border-t border-border/30">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[10px] text-muted-foreground">ACTIVE:</span>
          {filters.minLiquidity > 1000 && (
            <span className="px-2 py-0.5 text-[9px] bg-primary/20 text-primary">
              LIQ {'>'}= {formatValue(filters.minLiquidity, 'money')}
            </span>
          )}
          {filters.minWinProb > 0 && (
            <span className="px-2 py-0.5 text-[9px] bg-accent/20 text-accent">
              WIN {'>'}= {filters.minWinProb}%
            </span>
          )}
          {filters.maxRugScore < 100 && (
            <span className="px-2 py-0.5 text-[9px] bg-destructive/20 text-destructive">
              RUG {'<'}= {filters.maxRugScore}%
            </span>
          )}
          {filters.minWhaleScore > 0 && (
            <span className="px-2 py-0.5 text-[9px] bg-yellow-500/20 text-yellow-400">
              WHALE {'>'}= {filters.minWhaleScore}%
            </span>
          )}
          {filters.onlyBuySignals && (
            <span className="px-2 py-0.5 text-[9px] bg-accent/20 text-accent">BUY ONLY</span>
          )}
          {filters.onlyWhaleAlerts && (
            <span className="px-2 py-0.5 text-[9px] bg-yellow-500/20 text-yellow-400">WHALES ONLY</span>
          )}
          {filters.onlyNewLaunches && (
            <span className="px-2 py-0.5 text-[9px] bg-pink-500/20 text-pink-400">NEW ONLY</span>
          )}
        </div>
      </div>
    </div>
  );
}
