"use client";

import { AlertTriangle, Zap, Star } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-6 sm:mt-8 safe-bottom">
      {/* Warning */}
      <div className="bg-red-500/10 border-y border-red-500/30 p-3 sm:p-4">
        <div className="max-w-7xl mx-auto flex items-start gap-3">
          <div className="h-8 w-8 rounded-lg bg-red-500/20 flex items-center justify-center shrink-0">
            <AlertTriangle className="h-4 w-4 text-red-400" />
          </div>
          <div>
            <p className="text-xs font-bold text-red-400 mb-1">RISK WARNING</p>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Crypto trading involves significant risk. Meme coins are extremely volatile. 
              Never invest more than you can afford to lose. DYOR before any trade.
            </p>
          </div>
        </div>
      </div>

      {/* Footer content */}
      <div className="glass-card p-4 sm:p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Brand */}
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl gradient-primary flex items-center justify-center">
                <Zap className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h3 className="text-sm font-black text-foreground">
                  JK <span className="text-primary">WORKSHOP</span>
                </h3>
                <p className="text-[10px] text-muted-foreground">Solana Whale Hunter</p>
              </div>
            </div>

            {/* Info */}
            <div className="flex flex-wrap items-center justify-center gap-3 text-[10px]">
              <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-green-500/10 border border-green-500/30">
                <div className="h-1.5 w-1.5 rounded-full bg-green-400 animate-pulse" />
                <span className="text-green-400 font-bold">LIVE</span>
              </div>
              <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-yellow-500/10 border border-yellow-500/30">
                <Star className="h-3 w-3 text-yellow-400" />
                <span className="text-yellow-400 font-bold">20 SURE HITS</span>
              </div>
              <span className="text-muted-foreground">SOL PAIRS ONLY</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
