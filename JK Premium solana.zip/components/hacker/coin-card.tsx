"use client";

import React from "react"

import { useState } from "react";
import { 
  TrendingUp, 
  TrendingDown, 
  ExternalLink, 
  Copy, 
  Check,
  AlertTriangle,
  Clock,
  Droplets,
  BarChart3,
  Users,
  Zap,
  Target,
  Shield,
  Flame,
  Star
} from "lucide-react";
import type { ProcessedCoin } from "@/lib/dexscreener-api";

function formatNumber(num: number): string {
  if (num >= 1000000) return `${(num / 1000000).toFixed(2)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(2)}K`;
  return num.toFixed(2);
}

function formatPrice(price: number): string {
  if (price < 0.00001) return price.toExponential(2);
  if (price < 0.01) return price.toFixed(6);
  if (price < 1) return price.toFixed(4);
  return price.toFixed(2);
}

const signalConfig: Record<string, { gradient: string; text: string; icon: React.ElementType }> = {
  WHALE_ALERT: { gradient: 'from-yellow-500 to-orange-500', text: 'text-yellow-400', icon: Zap },
  STRONG_BUY: { gradient: 'from-green-500 to-emerald-500', text: 'text-green-400', icon: Flame },
  BUY: { gradient: 'from-green-400 to-teal-500', text: 'text-green-400', icon: Target },
  HOLD: { gradient: 'from-blue-500 to-cyan-500', text: 'text-blue-400', icon: Shield },
  WATCH: { gradient: 'from-orange-500 to-amber-500', text: 'text-orange-400', icon: Clock },
  AVOID: { gradient: 'from-red-500 to-rose-500', text: 'text-red-400', icon: AlertTriangle },
};

const getDexScreenerLink = (pairAddress: string) => 
  `https://dexscreener.com/solana/${pairAddress}`;

interface CoinCardProps {
  coin: ProcessedCoin;
  rank?: number;
  isSureHit?: boolean;
}

export function CoinCard({ coin, rank, isSureHit }: CoinCardProps) {
  const [copied, setCopied] = useState(false);
  const signal = signalConfig[coin.signal] || signalConfig.WATCH;
  const SignalIcon = signal.icon;

  const copyAddress = async () => {
    await navigator.clipboard.writeText(coin.contractAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const priceUp = coin.priceChange5m >= 0;
  const isWhaleAlert = coin.signal === 'WHALE_ALERT';

  return (
    <div className={`coin-card rounded-2xl glass-card-strong border transition-all duration-300 active:scale-[0.98] ${
      isSureHit 
        ? 'border-yellow-500/50 ring-1 ring-yellow-500/20' 
        : isWhaleAlert 
          ? 'border-yellow-500/40' 
          : 'border-border/50 hover:border-primary/50'
    }`}>
      
      {/* Rank Badge for Sure Hits */}
      {rank && (
        <div className="absolute top-3 left-3 z-10">
          <div className="h-7 w-7 rounded-full sure-hit-badge flex items-center justify-center text-xs font-black">
            #{rank}
          </div>
        </div>
      )}

      {/* Signal Badge */}
      <div className="absolute top-3 right-3 z-10">
        <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-[9px] font-bold bg-gradient-to-r ${signal.gradient} text-white`}>
          <SignalIcon className="h-3 w-3" />
          {coin.signal.replace('_', ' ')}
        </div>
      </div>

      {/* Header */}
      <div className="p-4 pt-12">
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex-1 min-w-0">
            <h3 className="font-black text-lg text-foreground truncate">{coin.symbol}</h3>
            <p className="text-xs text-muted-foreground truncate">{coin.name}</p>
          </div>
          
          {/* Win Probability Circle */}
          <div className="relative h-14 w-14 shrink-0">
            <svg className="h-14 w-14 -rotate-90" viewBox="0 0 36 36">
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="text-muted/30"
              />
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeDasharray={`${coin.winProbability}, 100`}
                className={coin.winProbability >= 60 ? 'text-green-400' : coin.winProbability >= 40 ? 'text-yellow-400' : 'text-red-400'}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-sm font-black ${coin.winProbability >= 60 ? 'text-green-400' : coin.winProbability >= 40 ? 'text-yellow-400' : 'text-red-400'}`}>
                {coin.winProbability}%
              </span>
              <span className="text-[8px] text-muted-foreground">WIN</span>
            </div>
          </div>
        </div>

        {/* Price Section */}
        <div className="flex items-end justify-between mb-4">
          <div>
            <p className="text-[10px] text-muted-foreground mb-0.5">PRICE</p>
            <p className="text-xl font-black font-mono text-foreground">
              ${formatPrice(coin.price)}
            </p>
          </div>
          <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${priceUp ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
            {priceUp ? <TrendingUp className="h-4 w-4 text-green-400" /> : <TrendingDown className="h-4 w-4 text-red-400" />}
            <span className={`font-bold text-sm ${priceUp ? 'text-green-400' : 'text-red-400'}`}>
              {priceUp ? '+' : ''}{coin.priceChange5m.toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Price Changes Grid */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          {[
            { label: '1H', value: coin.priceChange1h },
            { label: '6H', value: coin.priceChange6h },
            { label: '24H', value: coin.priceChange24h },
          ].map((item) => (
            <div key={item.label} className="text-center px-2 py-1.5 rounded-lg bg-muted/30">
              <p className="text-[9px] text-muted-foreground">{item.label}</p>
              <p className={`text-xs font-bold ${item.value >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {item.value >= 0 ? '+' : ''}{item.value.toFixed(1)}%
              </p>
            </div>
          ))}
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-muted/20">
            <Droplets className="h-4 w-4 text-blue-400" />
            <div>
              <p className="text-[9px] text-muted-foreground">LIQUIDITY</p>
              <p className="text-xs font-bold">${formatNumber(coin.liquidity)}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-muted/20">
            <BarChart3 className="h-4 w-4 text-purple-400" />
            <div>
              <p className="text-[9px] text-muted-foreground">VOL 1H</p>
              <p className="text-xs font-bold">${formatNumber(coin.volume1h)}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-muted/20">
            <Users className="h-4 w-4 text-pink-400" />
            <div>
              <p className="text-[9px] text-muted-foreground">BUYS/SELLS</p>
              <p className="text-xs font-bold">
                <span className="text-green-400">{coin.buys1h}</span>
                <span className="text-muted-foreground">/</span>
                <span className="text-red-400">{coin.sells1h}</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-muted/20">
            <Clock className="h-4 w-4 text-cyan-400" />
            <div>
              <p className="text-[9px] text-muted-foreground">AGE</p>
              <p className="text-xs font-bold">{coin.age}</p>
            </div>
          </div>
        </div>

        {/* Scores Bar */}
        <div className="grid grid-cols-4 gap-1 mb-4">
          {[
            { label: 'WHALE', value: coin.whaleScore, color: 'text-yellow-400' },
            { label: 'MOMENTUM', value: coin.momentumScore, color: 'text-pink-400' },
            { label: 'LIQ', value: coin.liquidityScore, color: 'text-blue-400' },
            { label: 'OVERALL', value: coin.overallScore, color: 'text-green-400' },
          ].map((score) => (
            <div key={score.label} className="text-center">
              <p className="text-[8px] text-muted-foreground">{score.label}</p>
              <p className={`text-sm font-bold ${score.value >= 60 ? score.color : score.value >= 40 ? 'text-foreground' : 'text-muted-foreground'}`}>
                {score.value}
              </p>
            </div>
          ))}
        </div>

        {/* Rug Risk */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-[10px] mb-1">
            <span className="text-muted-foreground">RUG RISK</span>
            <span className={coin.rugScore > 50 ? 'text-red-400' : coin.rugScore > 30 ? 'text-yellow-400' : 'text-green-400'}>
              {coin.rugScore}/100
            </span>
          </div>
          <div className="h-1.5 rounded-full bg-muted/30 overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all ${
                coin.rugScore > 60 ? 'bg-red-500' : coin.rugScore > 40 ? 'bg-yellow-500' : 'bg-green-500'
              }`}
              style={{ width: `${coin.rugScore}%` }}
            />
          </div>
        </div>

        {/* Contract */}
        <div className="mb-4">
          <p className="text-[9px] text-muted-foreground mb-1">CONTRACT</p>
          <div className="flex items-center gap-2">
            <code className="flex-1 text-[10px] font-mono text-foreground/80 truncate bg-muted/30 px-2 py-1.5 rounded-lg">
              {coin.contractAddress}
            </code>
            <button
              type="button"
              onClick={copyAddress}
              className="h-8 w-8 flex items-center justify-center rounded-lg bg-muted/30 hover:bg-muted touch-btn active:scale-95"
            >
              {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {/* Quick Links */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {[
            { label: 'DEX', href: getDexScreenerLink(coin.pairAddress), primary: true },
            { label: 'BIRD', href: `https://birdeye.so/token/${coin.contractAddress}?chain=solana` },
            { label: 'RUG', href: `https://rugcheck.xyz/tokens/${coin.contractAddress}` },
            { label: 'SCAN', href: `https://solscan.io/token/${coin.contractAddress}` },
            { label: 'GMGN', href: `https://gmgn.ai/sol/token/${coin.contractAddress}` },
          ].map((link) => (
            <a 
              key={link.label}
              href={link.href}
              target="_blank"
              rel="noopener noreferrer"
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-[9px] font-bold touch-btn active:scale-95 ${
                link.primary 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted/30 hover:bg-muted text-foreground'
              }`}
            >
              <ExternalLink className="h-3 w-3" />
              {link.label}
            </a>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <a 
            href={getDexScreenerLink(coin.pairAddress)}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 flex items-center justify-center gap-1.5 h-11 rounded-xl bg-muted/50 hover:bg-muted text-sm font-bold touch-btn active:scale-95 transition-all"
          >
            <BarChart3 className="h-4 w-4" />
            CHART
          </a>
          <a 
            href={`https://jup.ag/swap/SOL-${coin.contractAddress}`}
            target="_blank"
            rel="noopener noreferrer"
            className={`flex-1 flex items-center justify-center gap-1.5 h-11 rounded-xl text-sm font-bold touch-btn active:scale-95 transition-all ${
              isSureHit || isWhaleAlert
                ? 'sure-hit-badge'
                : 'gradient-primary text-primary-foreground'
            }`}
          >
            <Zap className="h-4 w-4" />
            {isSureHit ? 'SURE BUY' : isWhaleAlert ? 'WHALE BUY' : 'BUY NOW'}
          </a>
        </div>
      </div>
    </div>
  );
}
