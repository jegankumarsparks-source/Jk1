"use client";

import React from "react";
import { useState } from "react";
import { 
  Target, 
  Clock, 
  TrendingUp, 
  Grid3X3, 
  RefreshCw, 
  Sparkles, 
  Rocket,
  Zap,
  Shield,
  Flame,
  AlertTriangle,
  Star
} from "lucide-react";
import { CoinCard } from "./coin-card";
import type { ProcessedCoin } from "@/lib/dexscreener-api";

type FilterType = 'sure' | 'whale' | 'new' | 'suggested' | 'buy' | 'trending' | 'momentum' | 'safe' | 'gems' | 'all';

interface CoinData {
  all: ProcessedCoin[];
  whaleAlerts: ProcessedCoin[];
  buySignals: ProcessedCoin[];
  newCoins: ProcessedCoin[];
  trending: ProcessedCoin[];
  suggested: ProcessedCoin[];
  highMomentum: ProcessedCoin[];
  lowRisk: ProcessedCoin[];
  earlyGems: ProcessedCoin[];
  sureHits: ProcessedCoin[];
}

const filters: { id: FilterType; label: string; mobileLabel: string; icon: React.ElementType; description: string; pillClass: string }[] = [
  { id: 'sure', label: 'SURE HITS', mobileLabel: 'SURE', icon: Star, description: 'Top 20 Sure Hit Coins', pillClass: 'sure-hit-badge' },
  { id: 'whale', label: 'WHALE ALERTS', mobileLabel: 'WHALE', icon: Zap, description: 'Early whale entry', pillClass: 'pill-whale' },
  { id: 'new', label: 'NEW LAUNCHES', mobileLabel: 'NEW', icon: Rocket, description: 'Just launched', pillClass: 'pill-new' },
  { id: 'gems', label: 'EARLY GEMS', mobileLabel: 'GEMS', icon: Sparkles, description: 'New + good metrics', pillClass: 'pill-gem' },
  { id: 'suggested', label: 'SUGGESTED', mobileLabel: 'PICKS', icon: Target, description: 'High win probability', pillClass: 'pill-buy' },
  { id: 'buy', label: 'BUY SIGNALS', mobileLabel: 'BUY', icon: Target, description: 'Strong buy signals', pillClass: 'pill-buy' },
  { id: 'momentum', label: 'MOMENTUM', mobileLabel: 'HOT', icon: Flame, description: 'High momentum', pillClass: 'pill-hot' },
  { id: 'trending', label: 'TRENDING', mobileLabel: 'TREND', icon: TrendingUp, description: 'High volume', pillClass: 'bg-blue-500 text-white' },
  { id: 'safe', label: 'LOW RISK', mobileLabel: 'SAFE', icon: Shield, description: 'Safest picks', pillClass: 'pill-safe' },
  { id: 'all', label: 'ALL', mobileLabel: 'ALL', icon: Grid3X3, description: 'All SOL pairs', pillClass: 'bg-muted text-foreground' },
];

export function CoinList({ 
  coins, 
  isLoading, 
  onRefresh 
}: { 
  coins: CoinData; 
  isLoading: boolean;
  onRefresh: () => void;
}) {
  const [activeFilter, setActiveFilter] = useState<FilterType>('sure');

  const getFilteredCoins = (): ProcessedCoin[] => {
    switch (activeFilter) {
      case 'sure':
        return coins.sureHits || [];
      case 'whale':
        return coins.whaleAlerts || [];
      case 'new':
        return coins.newCoins || [];
      case 'gems':
        return coins.earlyGems || [];
      case 'suggested':
        return coins.suggested || [];
      case 'buy':
        return coins.buySignals || [];
      case 'momentum':
        return coins.highMomentum || [];
      case 'trending':
        return coins.trending || [];
      case 'safe':
        return coins.lowRisk || [];
      default:
        return coins.all || [];
    }
  };

  const getCoinCount = (id: FilterType): number => {
    switch (id) {
      case 'sure': return coins.sureHits?.length || 0;
      case 'whale': return coins.whaleAlerts?.length || 0;
      case 'new': return coins.newCoins?.length || 0;
      case 'gems': return coins.earlyGems?.length || 0;
      case 'suggested': return coins.suggested?.length || 0;
      case 'buy': return coins.buySignals?.length || 0;
      case 'momentum': return coins.highMomentum?.length || 0;
      case 'trending': return coins.trending?.length || 0;
      case 'safe': return coins.lowRisk?.length || 0;
      default: return coins.all?.length || 0;
    }
  };

  const filteredCoins = getFilteredCoins();
  const activeFilterData = filters.find(f => f.id === activeFilter);

  return (
    <div>
      {/* Filter Pills - Mobile Horizontal Scroll */}
      <div className="overflow-x-auto -mx-3 px-3 sm:mx-0 sm:px-0 pb-3 scrollbar-hide">
        <div className="flex gap-2 min-w-max sm:flex-wrap sm:min-w-0">
          {filters.map((filter) => {
            const Icon = filter.icon;
            const isActive = activeFilter === filter.id;
            const count = getCoinCount(filter.id);
            return (
              <button
                key={filter.id}
                type="button"
                onClick={() => setActiveFilter(filter.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-full text-[10px] sm:text-[11px] font-bold touch-btn transition-all active:scale-95 ${
                  isActive 
                    ? filter.pillClass
                    : 'bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span className="sm:hidden">{filter.mobileLabel}</span>
                <span className="hidden sm:inline">{filter.label}</span>
                {count > 0 && (
                  <span className={`ml-1 px-1.5 py-0.5 text-[9px] rounded-full ${
                    isActive ? 'bg-black/20' : 'bg-background/50'
                  }`}>
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Filter Info */}
      <div className="flex items-center justify-between mb-4 mt-2">
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 bg-green-400 animate-pulse rounded-full" />
          <p className="text-xs text-muted-foreground">
            <span className="text-foreground font-bold">{filteredCoins.length}</span> {activeFilterData?.description}
          </p>
        </div>

        <button
          type="button"
          onClick={onRefresh}
          disabled={isLoading}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-muted/50 hover:bg-muted text-xs font-medium touch-btn active:scale-95 transition-all"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          {isLoading ? 'LIVE...' : 'REFRESH'}
        </button>
      </div>

      {/* Info Banners */}
      {activeFilter === 'sure' && filteredCoins.length > 0 && (
        <div className="mb-4 p-3 rounded-xl glass-card border border-yellow-500/30 animate-bounce-in">
          <div className="flex items-start gap-2">
            <div className="h-8 w-8 rounded-lg sure-hit-badge flex items-center justify-center shrink-0">
              <Star className="h-4 w-4" />
            </div>
            <div>
              <p className="text-sm font-bold text-yellow-400">SURE HIT 20 COINS</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                Top 20 coins with best combined scores: win probability, whale activity, momentum, and low rug risk. 
                Entry early for maximum profit potential.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeFilter === 'whale' && filteredCoins.length > 0 && (
        <div className="mb-4 p-3 rounded-xl glass-card border border-yellow-500/30 animate-bounce-in">
          <div className="flex items-start gap-2">
            <div className="h-8 w-8 rounded-lg pill-whale flex items-center justify-center shrink-0">
              <Zap className="h-4 w-4" />
            </div>
            <div>
              <p className="text-sm font-bold text-yellow-400">WHALE EARLY ENTRY</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                Whale activity detected! High volume transactions, unusual buy pressure. 
                Get in early with whales for best profit opportunity.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeFilter === 'gems' && filteredCoins.length > 0 && (
        <div className="mb-4 p-3 rounded-xl glass-card border border-purple-500/30 animate-bounce-in">
          <div className="flex items-start gap-2">
            <div className="h-8 w-8 rounded-lg pill-gem flex items-center justify-center shrink-0">
              <Sparkles className="h-4 w-4" />
            </div>
            <div>
              <p className="text-sm font-bold text-purple-400">EARLY GEM FINDER</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                New coins under 4 hours with good liquidity, low rug risk, and positive buy pressure.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Coins Grid */}
      {isLoading && filteredCoins.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 rounded-xl glass-card">
          <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center mb-4">
            <RefreshCw className="h-6 w-6 text-primary-foreground animate-spin" />
          </div>
          <p className="text-sm font-bold text-foreground">SCANNING SOLANA...</p>
          <p className="text-xs text-muted-foreground mt-1">Fetching live SOL pairs</p>
        </div>
      ) : filteredCoins.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 rounded-xl glass-card">
          <AlertTriangle className="h-10 w-10 text-muted-foreground mb-4" />
          <p className="text-sm font-bold text-foreground">NO {activeFilterData?.label} FOUND</p>
          <p className="text-xs text-muted-foreground mt-1">Try another filter or refresh</p>
          <button
            type="button"
            onClick={onRefresh}
            className="mt-4 flex items-center gap-1.5 px-4 py-2 rounded-lg gradient-primary text-primary-foreground text-sm font-bold touch-btn active:scale-95"
          >
            <RefreshCw className="h-4 w-4" />
            REFRESH
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 sm:gap-4">
          {filteredCoins.map((coin, index) => (
            <CoinCard 
              key={coin.id} 
              coin={coin} 
              rank={activeFilter === 'sure' ? index + 1 : undefined}
              isSureHit={activeFilter === 'sure'}
            />
          ))}
        </div>
      )}

      {/* Footer info */}
      {filteredCoins.length >= 10 && (
        <div className="mt-4 text-center">
          <p className="text-[10px] text-muted-foreground">
            Showing {filteredCoins.length} {activeFilterData?.description} • Auto-refresh active
          </p>
        </div>
      )}
    </div>
  );
}
