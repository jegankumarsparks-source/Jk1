"use client";

import { BarChart2, Shield, Search, Rocket, Activity, Wallet, ExternalLink, Zap, Target, Bot } from "lucide-react";

const links = [
  {
    name: "DEX",
    desc: "Charts",
    url: "https://dexscreener.com/solana",
    icon: BarChart2,
    gradient: "from-green-500 to-emerald-500"
  },
  {
    name: "JUPITER",
    desc: "Swap",
    url: "https://jup.ag",
    icon: Zap,
    gradient: "from-orange-500 to-amber-500"
  },
  {
    name: "PUMP",
    desc: "New",
    url: "https://pump.fun",
    icon: Rocket,
    gradient: "from-pink-500 to-rose-500"
  },
  {
    name: "RUG",
    desc: "Check",
    url: "https://rugcheck.xyz",
    icon: Shield,
    gradient: "from-red-500 to-orange-500"
  },
  {
    name: "BIRD",
    desc: "Gems",
    url: "https://birdeye.so/find-gems?chain=solana",
    icon: Search,
    gradient: "from-cyan-500 to-blue-500"
  },
  {
    name: "GMGN",
    desc: "Whales",
    url: "https://gmgn.ai/sol",
    icon: Target,
    gradient: "from-yellow-500 to-orange-500"
  },
  {
    name: "PHOTON",
    desc: "Sniper",
    url: "https://photon-sol.tinyastro.io/",
    icon: Bot,
    gradient: "from-purple-500 to-violet-500"
  },
  {
    name: "SCAN",
    desc: "Explorer",
    url: "https://solscan.io",
    icon: ExternalLink,
    gradient: "from-blue-500 to-indigo-500"
  }
];

export function QuickLinks() {
  return (
    <div className="overflow-x-auto scrollbar-hide -mx-3 px-3 sm:mx-0 sm:px-0">
      <div className="flex gap-2 min-w-max sm:grid sm:grid-cols-8 sm:min-w-0">
        {links.map((link) => {
          const Icon = link.icon;
          return (
            <a
              key={link.name}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-col items-center justify-center p-3 rounded-xl glass-card border border-border/50 hover:border-primary/50 transition-all touch-btn active:scale-95 min-w-[72px]"
            >
              <div className={`h-9 w-9 rounded-lg bg-gradient-to-br ${link.gradient} flex items-center justify-center mb-1.5`}>
                <Icon className="h-4 w-4 text-white" />
              </div>
              <span className="text-[10px] font-bold text-foreground text-center">{link.name}</span>
              <span className="text-[8px] text-muted-foreground text-center">{link.desc}</span>
            </a>
          );
        })}
      </div>
    </div>
  );
}
