"use client";

import { 
  Zap, 
  Shield, 
  TrendingUp, 
  AlertTriangle, 
  Target,
  Clock,
  DollarSign,
  Percent
} from "lucide-react";

const strategies = [
  {
    icon: Target,
    title: "DAILY 8 COINS",
    desc: "Scan 8 new coins daily, 1 moon = profit",
    color: "text-accent"
  },
  {
    icon: DollarSign,
    title: "$12.50 PER COIN",
    desc: "$100 ÷ 8 coins = Low risk spread",
    color: "text-primary"
  },
  {
    icon: Percent,
    title: "10X TARGET",
    desc: "1 coin 10x = $125 profit daily",
    color: "text-accent"
  },
  {
    icon: Shield,
    title: "RUGCHECK FIRST",
    desc: "Always verify before buying",
    color: "text-orange-400"
  },
  {
    icon: Clock,
    title: "EARLY ENTRY",
    desc: "Coins under 1 hour = best gains",
    color: "text-yellow-400"
  },
  {
    icon: AlertTriangle,
    title: "EXIT STRATEGY",
    desc: "Take profits at 3x, 5x, 10x",
    color: "text-destructive"
  }
];

export function StrategyPanel() {
  return (
    <div className="border border-border/30 bg-card/30 backdrop-blur-sm">
      <div className="border-b border-border/30 p-4">
        <div className="flex items-center gap-2">
          <Zap className="h-4 w-4 text-primary" />
          <h2 className="text-sm font-bold tracking-wider text-primary" style={{ fontFamily: 'var(--font-display), monospace' }}>
            JK STRATEGY // $100 → $1000
          </h2>
        </div>
        <p className="text-xs text-muted-foreground mt-1">30 day millionaire path</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6">
        {strategies.map((strategy, index) => {
          const Icon = strategy.icon;
          return (
            <div 
              key={index}
              className="p-4 border-r border-b border-border/30 last:border-r-0 hover:bg-muted/20 transition-colors"
            >
              <Icon className={`h-5 w-5 ${strategy.color} mb-2`} />
              <h3 className="text-xs font-bold text-foreground mb-1">{strategy.title}</h3>
              <p className="text-[10px] text-muted-foreground leading-relaxed">{strategy.desc}</p>
            </div>
          );
        })}
      </div>

      {/* Progress tracker */}
      <div className="p-4 border-t border-border/30 bg-muted/10">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-muted-foreground">30-DAY PROGRESS</span>
          <span className="text-xs font-mono text-primary">DAY 1 / 30</span>
        </div>
        <div className="flex gap-0.5">
          {Array.from({ length: 30 }).map((_, i) => (
            <div 
              key={i}
              className={`flex-1 h-2 ${i === 0 ? 'bg-accent' : 'bg-muted/30'}`}
            />
          ))}
        </div>
        <div className="flex justify-between mt-2 text-[10px] text-muted-foreground">
          <span>$100</span>
          <span>$316</span>
          <span>$1,000</span>
          <span className="text-primary">$10,000</span>
        </div>
      </div>
    </div>
  );
}
