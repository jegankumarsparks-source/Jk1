"use client";

import { useState, useEffect } from "react";
import { 
  Zap, 
  Wifi, 
  WifiOff, 
  Search, 
  Bell, 
  Settings,
  Menu,
  X,
  TrendingUp,
  Shield,
  Target,
  Sparkles,
  ExternalLink
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  isLive: boolean;
  onMenuToggle?: () => void;
}

export function HackerHeader({ isLive, onMenuToggle }: HeaderProps) {
  const [showMenu, setShowMenu] = useState(false);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const quickActions = [
    { label: 'WHALE ALERTS', icon: Zap, color: 'pill-whale', href: '#whale' },
    { label: 'NEW COINS', icon: Sparkles, color: 'pill-new', href: '#new' },
    { label: 'SURE HITS', icon: Target, color: 'pill-buy', href: '#buy' },
    { label: 'SAFE PICKS', icon: Shield, color: 'pill-safe', href: '#safe' },
  ];

  const externalLinks = [
    { label: 'DexScreener', href: 'https://dexscreener.com/solana' },
    { label: 'Birdeye', href: 'https://birdeye.so' },
    { label: 'Jupiter', href: 'https://jup.ag' },
    { label: 'RugCheck', href: 'https://rugcheck.xyz' },
  ];

  return (
    <header className="sticky top-0 z-50 safe-top">
      {/* Main Header Bar */}
      <div className="glass-card-strong border-b border-border/50">
        <div className="mx-auto max-w-7xl px-3 sm:px-4">
          <div className="flex items-center justify-between h-14 sm:h-16">
            {/* Logo */}
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="relative">
                <div className="flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl gradient-primary">
                  <Zap className="h-5 w-5 sm:h-6 sm:w-6 text-primary-foreground" />
                </div>
                {isLive && (
                  <div className="absolute -top-0.5 -right-0.5 h-3 w-3 rounded-full bg-green-400 border-2 border-background">
                    <div className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-75" />
                  </div>
                )}
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-black tracking-tight text-foreground">
                  JK <span className="text-primary">WORKSHOP</span>
                </h1>
                <div className="flex items-center gap-1.5">
                  <div className={`h-1.5 w-1.5 rounded-full ${isLive ? 'bg-green-400' : 'bg-red-400'}`} />
                  <span className="text-[9px] sm:text-[10px] text-muted-foreground tracking-wide">
                    {isLive ? 'LIVE' : 'OFFLINE'}
                  </span>
                </div>
              </div>
            </div>

            {/* Desktop Quick Actions */}
            <div className="hidden md:flex items-center gap-2">
              {quickActions.map((action) => {
                const Icon = action.icon;
                return (
                  <button
                    key={action.label}
                    type="button"
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-bold ${action.color} touch-btn`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    {action.label}
                  </button>
                );
              })}
            </div>

            {/* Right Section */}
            <div className="flex items-center gap-2">
              {/* Time Display */}
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-muted/50 border border-border/50">
                <span className="text-xs font-mono text-foreground tabular-nums">
                  {time.toLocaleTimeString('en-US', { hour12: false })}
                </span>
              </div>

              {/* Connection Status - Mobile */}
              <div className="sm:hidden flex items-center gap-1 px-2 py-1 rounded-lg bg-muted/30">
                {isLive ? (
                  <Wifi className="h-4 w-4 text-green-400" />
                ) : (
                  <WifiOff className="h-4 w-4 text-red-400" />
                )}
              </div>

              {/* Menu Button */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowMenu(!showMenu)}
                className="h-9 w-9 p-0 rounded-lg touch-btn"
              >
                {showMenu ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Quick Actions Bar */}
      <div className="md:hidden glass-card border-b border-border/30">
        <div className="overflow-x-auto scrollbar-hide">
          <div className="flex items-center gap-2 px-3 py-2 min-w-max">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <button
                  key={action.label}
                  type="button"
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-full text-[10px] font-bold ${action.color} touch-btn active:scale-95 transition-transform`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {action.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Dropdown Menu */}
      {showMenu && (
        <div className="absolute top-full left-0 right-0 glass-card-strong border-b border-border/50 animate-bounce-in">
          <div className="mx-auto max-w-7xl px-3 sm:px-4 py-4">
            {/* Quick Links */}
            <div className="mb-4">
              <p className="text-[10px] text-muted-foreground mb-2 tracking-wider">QUICK LINKS</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {externalLinks.map((link) => (
                  <a
                    key={link.label}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between px-3 py-2.5 rounded-lg bg-muted/30 hover:bg-muted/50 touch-btn transition-colors"
                  >
                    <span className="text-xs font-medium">{link.label}</span>
                    <ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
                  </a>
                ))}
              </div>
            </div>

            {/* Status Info */}
            <div className="flex items-center justify-between pt-3 border-t border-border/30">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <div className={`h-2 w-2 rounded-full ${isLive ? 'bg-green-400' : 'bg-red-400'}`} />
                  <span className="text-[10px] text-muted-foreground">
                    {isLive ? 'Connected to DexScreener' : 'Reconnecting...'}
                  </span>
                </div>
              </div>
              <span className="text-[10px] font-mono text-muted-foreground">
                {time.toLocaleTimeString('en-US', { hour12: false })}
              </span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
