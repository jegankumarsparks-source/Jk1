"use client";

import { useState } from "react";
import { Zap, TrendingUp, Target, Star, Sparkles, Shield, ChevronDown, ChevronUp, ExternalLink, X } from "lucide-react";
import type { ProcessedCoin } from "@/lib/dexscreener-api";

interface StatsPanelProps {
  stats: {
    totalCoins: number;
    avgWinRate: number;
    buySignals: number;
    newCoinsCount: number;
    whaleAlertsCount: number;
    suggestedCount: number;
    sureHitsCount?: number;
  };
  lastUpdate: number;
  coins?: {
    all: ProcessedCoin[];
    whaleAlerts: ProcessedCoin[];
    buySignals: ProcessedCoin[];
    newCoins: ProcessedCoin[];
    sureHits: ProcessedCoin[];
  };
}

type StatType = 'sureHits' | 'whaleAlerts' | 'buySignals' | 'newCoins' | 'avgWin' | 'total' | null;

function MiniCoinCard({ coin }: { coin: ProcessedCoin }) {
  const priceUp = coin.priceChange5m >= 0;
  const dexLink = `https://dexscreener.com/solana/${coin.pairAddress}`;
  
  return (
    <a 
      href={dexLink}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-3 p-3 rounded-xl bg-muted/30 hover:bg-muted/50 border border-border/30 hover:border-primary/50 transition-all active:scale-[0.98] touch-btn"
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-bold text-sm text-foreground truncate">{coin.symbol}</span>
          <span className={`text-xs font-bold ${priceUp ? 'text-green-400' : 'text-red-400'}`}>
            {priceUp ? '+' : ''}{coin.priceChange5m.toFixed(1)}%
          </span>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
          <span>${coin.price < 0.001 ? coin.price.toExponential(2) : coin.price.toFixed(4)}</span>
          <span>•</span>
          <span className="text-primary">{coin.winProbability}% WIN</span>
        </div>
      </div>
      <ExternalLink className="h-4 w-4 text-muted-foreground shrink-0" />
    </a>
  );
}

export function StatsPanel({ stats, coins }: StatsPanelProps) {
  const [expandedStat, setExpandedStat] = useState<StatType>(null);

  const statItems: Array<{
    key: StatType;
    label: string;
    value: number | string;
    icon: typeof Star;
    gradient: string;
    textColor: string;
    coins?: ProcessedCoin[];
  }> = [
    { 
      key: 'sureHits',
      label: 'SURE HITS', 
      value: stats.sureHitsCount || 20, 
      icon: Star, 
      gradient: 'from-yellow-500 to-orange-500',
      textColor: 'text-yellow-400',
      coins: coins?.sureHits?.slice(0, 10)
    },
    { 
      key: 'whaleAlerts',
      label: 'WHALE ALERTS', 
      value: stats.whaleAlertsCount, 
      icon: Zap, 
      gradient: 'from-yellow-400 to-amber-500',
      textColor: 'text-yellow-400',
      coins: coins?.whaleAlerts?.slice(0, 10)
    },
    { 
      key: 'buySignals',
      label: 'BUY SIGNALS', 
      value: stats.buySignals, 
      icon: Target, 
      gradient: 'from-green-500 to-emerald-500',
      textColor: 'text-green-400',
      coins: coins?.buySignals?.slice(0, 10)
    },
    { 
      key: 'newCoins',
      label: 'NEW COINS', 
      value: stats.newCoinsCount, 
      icon: Sparkles, 
      gradient: 'from-pink-500 to-rose-500',
      textColor: 'text-pink-400',
      coins: coins?.newCoins?.slice(0, 10)
    },
    { 
      key: 'avgWin',
      label: 'AVG WIN', 
      value: `${stats.avgWinRate}%`, 
      icon: TrendingUp, 
      gradient: 'from-blue-500 to-cyan-500',
      textColor: 'text-blue-400',
      coins: undefined
    },
    { 
      key: 'total',
      label: 'TOTAL', 
      value: stats.totalCoins, 
      icon: Shield, 
      gradient: 'from-purple-500 to-violet-500',
      textColor: 'text-purple-400',
      coins: coins?.all?.slice(0, 10)
    },
  ];

  const handleStatClick = (key: StatType) => {
    if (key === 'avgWin') return; // avgWin doesn't have coins
    setExpandedStat(expandedStat === key ? null : key);
  };

  const currentExpandedItem = statItems.find(item => item.key === expandedStat);

  return (
    <div className="space-y-3">
      {/* Stats Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 sm:gap-3">
        {statItems.map((item) => {
          const Icon = item.icon;
          const isExpanded = expandedStat === item.key;
          const hasCoins = item.coins && item.coins.length > 0;
          
          return (
            <button
              key={item.label}
              type="button"
              onClick={() => handleStatClick(item.key)}
              disabled={item.key === 'avgWin'}
              className={`glass-card rounded-xl p-3 sm:p-4 border transition-all touch-btn active:scale-95 text-left ${
                isExpanded 
                  ? 'border-primary ring-2 ring-primary/30' 
                  : 'border-border/50 hover:border-primary/30'
              } ${item.key === 'avgWin' ? 'cursor-default' : 'cursor-pointer'}`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className={`h-7 w-7 sm:h-8 sm:w-8 rounded-lg bg-gradient-to-br ${item.gradient} flex items-center justify-center`}>
                  <Icon className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-white" />
                </div>
                {hasCoins && (
                  <div className="h-5 w-5 flex items-center justify-center">
                    {isExpanded ? (
                      <ChevronUp className="h-3.5 w-3.5 text-primary" />
                    ) : (
                      <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                    )}
                  </div>
                )}
              </div>
              <p className={`text-lg sm:text-xl font-black ${item.textColor}`}>{item.value}</p>
              <p className="text-[9px] sm:text-[10px] text-muted-foreground tracking-wider">{item.label}</p>
            </button>
          );
        })}
      </div>

      {/* Expanded Mini Tab */}
      {expandedStat && currentExpandedItem?.coins && currentExpandedItem.coins.length > 0 && (
        <div className="animate-bounce-in">
          <div className="glass-card rounded-xl border border-primary/30 overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 bg-primary/5 border-b border-border/30">
              <div className="flex items-center gap-2">
                <div className={`h-6 w-6 rounded-lg bg-gradient-to-br ${currentExpandedItem.gradient} flex items-center justify-center`}>
                  <currentExpandedItem.icon className="h-3 w-3 text-white" />
                </div>
                <span className="text-sm font-bold text-foreground">{currentExpandedItem.label}</span>
                <span className="text-xs text-muted-foreground">({currentExpandedItem.coins.length})</span>
              </div>
              <button
                type="button"
                onClick={() => setExpandedStat(null)}
                className="h-7 w-7 flex items-center justify-center rounded-lg hover:bg-muted/50 touch-btn"
              >
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            </div>
            
            {/* Coins List */}
            <div className="p-3 grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[300px] overflow-y-auto scrollbar-hide">
              {currentExpandedItem.coins.map((coin, index) => (
                <MiniCoinCard key={`${coin.pairAddress}-${index}`} coin={coin} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
