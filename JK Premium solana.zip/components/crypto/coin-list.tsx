"use client";

import { useState, useEffect } from "react";
import { RefreshCw, Filter, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CoinCard } from "./coin-card";
import { generateMockCoins, type MemeСoin } from "@/lib/coin-data";

type FilterType = 'ALL' | 'BUY' | 'NEW' | 'TRENDING';

export function CoinList() {
  const [coins, setCoins] = useState<MemeСoin[]>([]);
  const [filter, setFilter] = useState<FilterType>('ALL');
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    setCoins(generateMockCoins());
  }, []);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setCoins(generateMockCoins());
      setIsRefreshing(false);
    }, 1000);
  };

  const filteredCoins = coins.filter(coin => {
    if (filter === 'BUY') return coin.signal === 'BUY';
    if (filter === 'NEW') return ['2m', '5m', '15m'].includes(coin.age);
    if (filter === 'TRENDING') return coin.priceChange24h > 50;
    return true;
  });

  const filters: { value: FilterType; label: string; count?: number }[] = [
    { value: 'ALL', label: 'All Coins', count: coins.length },
    { value: 'BUY', label: 'Buy Signals', count: coins.filter(c => c.signal === 'BUY').length },
    { value: 'NEW', label: 'Just Launched', count: coins.filter(c => ['2m', '5m', '15m'].includes(c.age)).length },
    { value: 'TRENDING', label: 'Trending', count: coins.filter(c => c.priceChange24h > 50).length },
  ];

  return (
    <div>
      {/* Header */}
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
            <Zap className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">New Meme Coins</h2>
            <p className="text-xs text-muted-foreground">Real-time Solana pair launches</p>
          </div>
        </div>
        
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="gap-2 bg-transparent"
        >
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Filters */}
      <div className="mb-4 flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f.value}
            onClick={() => setFilter(f.value)}
            className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium transition-all ${
              filter === f.value
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
          >
            <Filter className="h-3 w-3" />
            {f.label}
            {f.count !== undefined && (
              <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-xs">
                {f.count}
              </Badge>
            )}
          </button>
        ))}
      </div>

      {/* Coin Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filteredCoins.map((coin) => (
          <CoinCard key={coin.id} coin={coin} />
        ))}
      </div>

      {filteredCoins.length === 0 && (
        <div className="rounded-lg border border-dashed border-border bg-muted/20 p-8 text-center">
          <p className="text-muted-foreground">No coins match this filter. Try refreshing!</p>
        </div>
      )}
    </div>
  );
}
