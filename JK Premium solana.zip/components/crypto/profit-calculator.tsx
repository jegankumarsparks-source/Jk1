"use client";

import { useState } from "react";
import { Calculator, TrendingUp, DollarSign, Percent } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";

export function ProfitCalculator() {
  const [investment, setInvestment] = useState(100);
  const [multiplier, setMultiplier] = useState([10]);
  
  const potentialProfit = investment * multiplier[0];
  const profitAmount = potentialProfit - investment;

  const scenarios = [
    { x: 2, label: "2x Safe", color: "text-accent" },
    { x: 5, label: "5x Good", color: "text-primary" },
    { x: 10, label: "10x Moon", color: "text-orange-400" },
    { x: 100, label: "100x Lambo", color: "text-purple-400" },
  ];

  return (
    <Card className="border-primary/20 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4 sm:p-6">
        <div className="mb-4 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
            <Calculator className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">Profit Calculator</h2>
            <p className="text-xs text-muted-foreground">Calculate your potential gains</p>
          </div>
        </div>

        {/* Investment Input */}
        <div className="mb-4">
          <Label className="mb-2 flex items-center gap-2 text-sm text-muted-foreground">
            <DollarSign className="h-4 w-4" />
            Investment Amount
          </Label>
          <Input
            type="number"
            value={investment}
            onChange={(e) => setInvestment(Number(e.target.value))}
            className="bg-muted/50 text-lg font-semibold"
            min={1}
          />
        </div>

        {/* Multiplier Slider */}
        <div className="mb-4">
          <Label className="mb-2 flex items-center justify-between text-sm text-muted-foreground">
            <span className="flex items-center gap-2">
              <Percent className="h-4 w-4" />
              Multiplier
            </span>
            <span className="font-semibold text-primary">{multiplier[0]}x</span>
          </Label>
          <Slider
            value={multiplier}
            onValueChange={setMultiplier}
            min={2}
            max={100}
            step={1}
            className="my-4"
          />
        </div>

        {/* Quick Scenarios */}
        <div className="mb-4 flex flex-wrap gap-2">
          {scenarios.map((s) => (
            <button
              key={s.x}
              onClick={() => setMultiplier([s.x])}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                multiplier[0] === s.x
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        {/* Result */}
        <div className="rounded-xl bg-accent/10 p-4 text-center">
          <div className="flex items-center justify-center gap-2 text-accent">
            <TrendingUp className="h-5 w-5" />
            <span className="text-sm font-medium">Potential Return</span>
          </div>
          <p className="mt-2 text-3xl font-bold text-foreground">
            ${potentialProfit.toLocaleString()}
          </p>
          <p className="mt-1 text-sm text-accent">
            +${profitAmount.toLocaleString()} profit ({((profitAmount / investment) * 100).toFixed(0)}%)
          </p>
        </div>

        {/* Disclaimer */}
        <p className="mt-4 text-center text-xs text-muted-foreground">
          Machi, ithu just calculation. Crypto la risk irukku, DYOR!
        </p>
      </CardContent>
    </Card>
  );
}
