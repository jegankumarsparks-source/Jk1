"use client";

import { TrendingUp, Target, Trophy, Flame } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { portfolioStats, milestones } from "@/lib/coin-data";

export function PortfolioCard() {
  const progressToGoal = (portfolioStats.currentValue / 1000) * 100;

  return (
    <Card className="border-primary/20 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4 sm:p-6">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/20">
              <Trophy className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Portfolio Value</p>
              <h2 className="text-2xl font-bold text-foreground sm:text-3xl">
                ${portfolioStats.currentValue.toFixed(2)}
              </h2>
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-1 text-accent">
              <TrendingUp className="h-4 w-4" />
              <span className="text-lg font-bold">+{portfolioStats.profitPercentage.toFixed(1)}%</span>
            </div>
            <p className="text-xs text-muted-foreground">from $100</p>
          </div>
        </div>

        {/* Progress to $1000 */}
        <div className="mb-4">
          <div className="mb-2 flex items-center justify-between text-sm">
            <span className="text-muted-foreground">$100 to $1000 Journey</span>
            <span className="font-medium text-primary">{progressToGoal.toFixed(1)}%</span>
          </div>
          <Progress value={progressToGoal} className="h-3 bg-muted" />
        </div>

        {/* Milestones */}
        <div className="mb-4 flex flex-wrap gap-2">
          {milestones.map((milestone) => (
            <div
              key={milestone.target}
              className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${
                milestone.reached
                  ? "bg-accent/20 text-accent"
                  : milestone.target === 1000
                  ? "bg-primary/20 text-primary"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {milestone.reached && <Flame className="h-3 w-3" />}
              {milestone.label}
            </div>
          ))}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="rounded-lg bg-muted/50 p-3 text-center">
            <p className="text-lg font-bold text-foreground">{portfolioStats.totalTrades}</p>
            <p className="text-xs text-muted-foreground">Total Trades</p>
          </div>
          <div className="rounded-lg bg-muted/50 p-3 text-center">
            <p className="text-lg font-bold text-accent">{portfolioStats.winRate}%</p>
            <p className="text-xs text-muted-foreground">Win Rate</p>
          </div>
          <div className="rounded-lg bg-muted/50 p-3 text-center">
            <p className="text-lg font-bold text-primary">+{portfolioStats.bestTrade.profit}%</p>
            <p className="text-xs text-muted-foreground">Best Trade</p>
          </div>
          <div className="rounded-lg bg-muted/50 p-3 text-center">
            <div className="flex items-center justify-center gap-1">
              <Target className="h-4 w-4 text-primary" />
              <p className="text-lg font-bold text-foreground">{portfolioStats.daysRemaining}</p>
            </div>
            <p className="text-xs text-muted-foreground">Days Left</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
