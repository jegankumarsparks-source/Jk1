"use client";

import { useState } from "react";
import { 
  Lightbulb, 
  Shield, 
  BarChart3, 
  Target, 
  Brain,
  ChevronRight,
  Sparkles
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { tradingTips } from "@/lib/coin-data";

export function TradingTips() {
  const [activeTip, setActiveTip] = useState(0);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'safety': return Shield;
      case 'analysis': return BarChart3;
      case 'strategy': return Target;
      case 'mindset': return Brain;
      default: return Lightbulb;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'safety': return 'text-accent bg-accent/20';
      case 'analysis': return 'text-primary bg-primary/20';
      case 'strategy': return 'text-orange-400 bg-orange-500/20';
      case 'mindset': return 'text-purple-400 bg-purple-500/20';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  return (
    <Card className="border-primary/20 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4 sm:p-6">
        <div className="mb-4 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
            <Sparkles className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">Trading Tips - Tanglish Style</h2>
            <p className="text-xs text-muted-foreground">Machi, ithu follow pannunga!</p>
          </div>
        </div>

        {/* Active Tip */}
        <div className="mb-4 rounded-xl bg-muted/50 p-4">
          <div className="mb-2 flex items-center gap-2">
            {(() => {
              const IconComponent = getCategoryIcon(tradingTips[activeTip].category);
              return (
                <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${getCategoryColor(tradingTips[activeTip].category)}`}>
                  <IconComponent className="h-4 w-4" />
                </div>
              );
            })()}
            <h3 className="font-semibold text-foreground">{tradingTips[activeTip].title}</h3>
          </div>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {tradingTips[activeTip].tip}
          </p>
        </div>

        {/* Tip Navigation */}
        <div className="flex flex-wrap gap-2">
          {tradingTips.map((tip, index) => {
            const IconComponent = getCategoryIcon(tip.category);
            return (
              <button
                key={tip.id}
                onClick={() => setActiveTip(index)}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm transition-all ${
                  activeTip === index
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground hover:bg-muted/80'
                }`}
              >
                <IconComponent className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Tip {index + 1}</span>
                <span className="sm:hidden">{index + 1}</span>
              </button>
            );
          })}
        </div>

        {/* Quick Strategy */}
        <div className="mt-4 rounded-lg border border-primary/30 bg-primary/10 p-3">
          <div className="flex items-center gap-2 text-sm font-medium text-primary">
            <Target className="h-4 w-4" />
            Daily Strategy: 8 Coins, $12.50 Each = $100
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            Oru coin 10x aanalum, daily $25+ profit! 1 month la easy $1000!
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
