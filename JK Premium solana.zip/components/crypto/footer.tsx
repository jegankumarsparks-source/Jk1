"use client";

import { AlertTriangle, Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-card/30">
      <div className="mx-auto max-w-7xl px-4 py-6">
        {/* Disclaimer */}
        <div className="mb-4 rounded-lg border border-orange-500/30 bg-orange-500/10 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 flex-shrink-0 text-orange-400" />
            <div className="text-sm">
              <p className="mb-1 font-medium text-orange-400">Risk Warning - Machi Careful!</p>
              <p className="text-muted-foreground">
                Meme coin trading la high risk irukku. Invest only what you can afford to lose. 
                Ithu financial advice illa, just educational purpose thaan. DYOR (Do Your Own Research) pannunga!
              </p>
            </div>
          </div>
        </div>

        {/* Footer Info */}
        <div className="flex flex-col items-center justify-between gap-4 text-center sm:flex-row sm:text-left">
          <div>
            <p className="text-sm text-muted-foreground">
              SolMoon Tracker - $100 to $1000 Journey
            </p>
            <p className="text-xs text-muted-foreground/70">
              Not affiliated with Solana Foundation or any token projects
            </p>
          </div>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <span>Made with</span>
            <Heart className="h-4 w-4 text-destructive" />
            <span>for Solana Degens</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
