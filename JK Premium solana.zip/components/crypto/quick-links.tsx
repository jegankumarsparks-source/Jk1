"use client";

import { 
  ExternalLink, 
  BarChart2, 
  Shield, 
  Compass,
  Twitter,
  MessageCircle,
  Globe
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const links = [
  {
    name: "DEXScreener",
    description: "New pairs & charts",
    icon: BarChart2,
    url: "https://dexscreener.com/solana",
    color: "bg-accent/20 text-accent"
  },
  {
    name: "Birdeye",
    description: "Token analytics",
    icon: Compass,
    url: "https://birdeye.so/?chain=solana",
    color: "bg-primary/20 text-primary"
  },
  {
    name: "Jupiter",
    description: "Swap tokens",
    icon: Globe,
    url: "https://jup.ag/",
    color: "bg-blue-500/20 text-blue-400"
  },
  {
    name: "Raydium",
    description: "DEX trading",
    icon: Globe,
    url: "https://raydium.io/swap/",
    color: "bg-cyan-500/20 text-cyan-400"
  },
  {
    name: "RugCheck",
    description: "Safety scanner",
    icon: Shield,
    url: "https://rugcheck.xyz/",
    color: "bg-orange-500/20 text-orange-400"
  },
  {
    name: "Solscan",
    description: "Explorer",
    icon: Globe,
    url: "https://solscan.io/",
    color: "bg-purple-500/20 text-purple-400"
  },
  {
    name: "Pump.fun",
    description: "New launches",
    icon: BarChart2,
    url: "https://pump.fun/",
    color: "bg-pink-500/20 text-pink-400"
  },
  {
    name: "GMGN",
    description: "Whale tracker",
    icon: Compass,
    url: "https://gmgn.ai/sol",
    color: "bg-green-500/20 text-green-400"
  }
];

const socials = [
  { name: "Solana Twitter", icon: Twitter, url: "https://twitter.com/solana" },
  { name: "Crypto TG", icon: MessageCircle, url: "https://t.me/solana" },
];

export function QuickLinks() {
  return (
    <Card className="border-primary/20 bg-card/50 backdrop-blur-sm">
      <CardContent className="p-4 sm:p-6">
        <div className="mb-4 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
            <ExternalLink className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">Quick Links</h2>
            <p className="text-xs text-muted-foreground">Essential tools for trading</p>
          </div>
        </div>

        {/* Main Links */}
        <div className="mb-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
          {links.map((link) => (
            <a
              key={link.name}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-3 rounded-lg bg-muted/50 p-3 transition-all hover:bg-muted"
            >
              <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${link.color}`}>
                <link.icon className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium text-foreground group-hover:text-primary">
                  {link.name}
                </p>
                <p className="truncate text-xs text-muted-foreground">{link.description}</p>
              </div>
              <ExternalLink className="h-4 w-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
            </a>
          ))}
        </div>

        {/* Social Links */}
        <div className="flex gap-2">
          {socials.map((social) => (
            <a
              key={social.name}
              href={social.url}
              className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-muted/50 px-4 py-2 text-sm text-muted-foreground transition-all hover:bg-muted hover:text-foreground"
            >
              <social.icon className="h-4 w-4" />
              {social.name}
            </a>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
