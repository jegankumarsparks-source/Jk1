"use client";

import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Droplets, 
  Clock, 
  ExternalLink,
  AlertTriangle,
  CheckCircle,
  Eye,
  XCircle
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { MemeСoin } from "@/lib/coin-data";
import { 
  getDexScreenerLink, 
  getJupiterBuyLink, 
  getBirdeyeLink,
  getRugCheckLink 
} from "@/lib/coin-data";

interface CoinCardProps {
  coin: MemeСoin;
}

export function CoinCard({ coin }: CoinCardProps) {
  const formatNumber = (num: number) => {
    if (num >= 1000000) return `$${(num / 1000000).toFixed(2)}M`;
    if (num >= 1000) return `$${(num / 1000).toFixed(1)}K`;
    return `$${num.toFixed(2)}`;
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'LOW': return 'bg-accent/20 text-accent border-accent/30';
      case 'MEDIUM': return 'bg-primary/20 text-primary border-primary/30';
      case 'HIGH': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      case 'DEGEN': return 'bg-destructive/20 text-destructive border-destructive/30';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getSignalConfig = (signal: string) => {
    switch (signal) {
      case 'BUY': return { 
        color: 'bg-accent text-accent-foreground', 
        icon: CheckCircle,
        text: 'BUY SIGNAL'
      };
      case 'HOLD': return { 
        color: 'bg-primary text-primary-foreground', 
        icon: Eye,
        text: 'HOLD'
      };
      case 'WATCH': return { 
        color: 'bg-orange-500 text-white', 
        icon: Eye,
        text: 'WATCH'
      };
      case 'AVOID': return { 
        color: 'bg-destructive text-destructive-foreground', 
        icon: XCircle,
        text: 'AVOID'
      };
      default: return { 
        color: 'bg-muted text-muted-foreground', 
        icon: Eye,
        text: 'UNKNOWN'
      };
    }
  };

  const signalConfig = getSignalConfig(coin.signal);
  const SignalIcon = signalConfig.icon;

  return (
    <Card className="group border-border/50 bg-card/50 backdrop-blur-sm transition-all hover:border-primary/30 hover:bg-card/80">
      <CardContent className="p-4">
        {/* Header */}
        <div className="mb-3 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-lg font-bold text-primary">
              {coin.symbol.slice(0, 2)}
            </div>
            <div>
              <h3 className="font-semibold text-foreground">{coin.name}</h3>
              <p className="text-sm text-muted-foreground">${coin.symbol}</p>
            </div>
          </div>
          <Badge className={`${signalConfig.color} gap-1`}>
            <SignalIcon className="h-3 w-3" />
            {signalConfig.text}
          </Badge>
        </div>

        {/* Price */}
        <div className="mb-3 flex items-end justify-between">
          <div>
            <p className="text-2xl font-bold text-foreground">
              ${coin.price.toFixed(8)}
            </p>
            <div className={`flex items-center gap-1 text-sm ${
              coin.priceChange24h >= 0 ? 'text-accent' : 'text-destructive'
            }`}>
              {coin.priceChange24h >= 0 ? (
                <TrendingUp className="h-4 w-4" />
              ) : (
                <TrendingDown className="h-4 w-4" />
              )}
              <span className="font-medium">
                {coin.priceChange24h >= 0 ? '+' : ''}{coin.priceChange24h.toFixed(1)}%
              </span>
            </div>
          </div>
          <Badge variant="outline" className={getRiskColor(coin.riskLevel)}>
            {coin.riskLevel} RISK
          </Badge>
        </div>

        {/* Stats */}
        <div className="mb-3 grid grid-cols-2 gap-2 text-sm">
          <div className="flex items-center gap-2 rounded-lg bg-muted/50 p-2">
            <Droplets className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">Liquidity</p>
              <p className="font-medium text-foreground">{formatNumber(coin.liquidity)}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-lg bg-muted/50 p-2">
            <Users className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">Holders</p>
              <p className="font-medium text-foreground">{coin.holders.toLocaleString()}</p>
            </div>
          </div>
        </div>

        {/* Risk Indicators */}
        <div className="mb-3 flex items-center gap-2">
          <div className="flex-1">
            <div className="mb-1 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Rug Risk</span>
              <span className={coin.rugPullRisk > 50 ? 'text-destructive' : 'text-accent'}>
                {coin.rugPullRisk}%
              </span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-muted">
              <div 
                className={`h-full transition-all ${
                  coin.rugPullRisk > 70 ? 'bg-destructive' : 
                  coin.rugPullRisk > 40 ? 'bg-orange-500' : 'bg-accent'
                }`}
                style={{ width: `${coin.rugPullRisk}%` }}
              />
            </div>
          </div>
          <div className="flex-1">
            <div className="mb-1 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Social</span>
              <span className="text-primary">{coin.socialScore}%</span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-muted">
              <div 
                className="h-full bg-primary transition-all"
                style={{ width: `${coin.socialScore}%` }}
              />
            </div>
          </div>
        </div>

        {/* Contract Address */}
        <div className="mb-3 rounded-lg bg-muted/30 p-2">
          <p className="mb-1 text-xs text-muted-foreground">Contract Address</p>
          <div className="flex items-center gap-2">
            <code className="flex-1 truncate text-xs font-mono text-foreground/80">
              {coin.contractAddress}
            </code>
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0"
              onClick={() => {
                navigator.clipboard.writeText(coin.contractAddress);
              }}
            >
              <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/>
                <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
              </svg>
            </Button>
          </div>
        </div>

        {/* Quick Links */}
        <div className="mb-3 flex flex-wrap gap-1">
          <a 
            href={getDexScreenerLink(coin.pairAddress)} 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 rounded-md bg-muted/50 px-2 py-1 text-xs text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
          >
            <ExternalLink className="h-3 w-3" />
            DEXScreener
          </a>
          <a 
            href={getBirdeyeLink(coin.contractAddress)} 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 rounded-md bg-muted/50 px-2 py-1 text-xs text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
          >
            <ExternalLink className="h-3 w-3" />
            Birdeye
          </a>
          <a 
            href={getRugCheckLink(coin.contractAddress)} 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 rounded-md bg-orange-500/10 px-2 py-1 text-xs text-orange-400 hover:bg-orange-500/20 transition-colors"
          >
            <AlertTriangle className="h-3 w-3" />
            RugCheck
          </a>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-border/50 pt-3">
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span>Age: {coin.age}</span>
          </div>
          <div className="flex gap-2">
            <a 
              href={getDexScreenerLink(coin.pairAddress)}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button size="sm" variant="outline" className="h-8 gap-1 text-xs bg-transparent">
                <ExternalLink className="h-3 w-3" />
                Chart
              </Button>
            </a>
            {(coin.signal === 'BUY' || coin.signal === 'WATCH') && (
              <a 
                href={getJupiterBuyLink(coin.contractAddress)}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button size="sm" className="h-8 gap-1 bg-accent text-accent-foreground hover:bg-accent/90">
                  <TrendingUp className="h-3 w-3" />
                  Buy on Jupiter
                </Button>
              </a>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
