export interface MeditationSession {
  id: string
  title: string
  description: string
  duration: number // in minutes
  category: string
  icon: string
}

export interface DailyQuote {
  quote: string
  author: string
}

export const meditationSessions: MeditationSession[] = [
  {
    id: "morning",
    title: "காலை தியானம்",
    description: "உங்கள் நாளை அமைதியாக தொடங்குங்கள்",
    duration: 10,
    category: "காலை",
    icon: "🌅"
  },
  {
    id: "breathing",
    title: "சுவாசப் பயிற்சி",
    description: "ஆழ்ந்த சுவாசத்துடன் மன அமைதி",
    duration: 5,
    category: "சுவாசம்",
    icon: "🌬️"
  },
  {
    id: "stress",
    title: "மன அழுத்த நிவாரணம்",
    description: "கவலைகளை விடுவித்து அமைதி பெறுங்கள்",
    duration: 15,
    category: "அமைதி",
    icon: "🧘"
  },
  {
    id: "sleep",
    title: "இரவு தூக்கம்",
    description: "நிம்மதியான தூக்கத்திற்கு வழிகாட்டுதல்",
    duration: 20,
    category: "தூக்கம்",
    icon: "🌙"
  },
  {
    id: "focus",
    title: "கவன ஒருமுகப்படுத்தல்",
    description: "மனதை ஒருமுகப்படுத்தி வேலை செய்யுங்கள்",
    duration: 10,
    category: "கவனம்",
    icon: "🎯"
  },
  {
    id: "gratitude",
    title: "நன்றி தியானம்",
    description: "நன்றியுணர்வை வளர்த்துக்கொள்ளுங்கள்",
    duration: 8,
    category: "நன்றி",
    icon: "🙏"
  }
]

export const dailyQuotes: DailyQuote[] = [
  {
    quote: "மனம் அமைதியாக இருக்கும்போது, உலகம் அழகாகத் தெரியும்.",
    author: "திருவள்ளுவர்"
  },
  {
    quote: "ஒவ்வொரு நிமிடமும் ஒரு புதிய தொடக்கம்.",
    author: "பாரதியார்"
  },
  {
    quote: "அமைதி என்பது உள்ளிருந்து வருவது, வெளியிலிருந்து அல்ல.",
    author: "புத்தர்"
  },
  {
    quote: "சுவாசிப்பது வாழ்வது, நினைவுடன் சுவாசிப்பது நன்றாக வாழ்வது.",
    author: "தீச் நாட் ஹான்"
  },
  {
    quote: "இப்போது இந்த கணத்தில் இருங்கள், அதுவே உண்மையான சந்தோஷம்.",
    author: "ஓஷோ"
  }
]

export const soundCategories = [
  { id: "rain", name: "மழை", icon: "🌧️" },
  { id: "ocean", name: "கடல் அலை", icon: "🌊" },
  { id: "birds", name: "பறவைகள்", icon: "🐦" },
  { id: "wind", name: "காற்று", icon: "🍃" },
  { id: "fire", name: "நெருப்பு", icon: "🔥" },
  { id: "temple", name: "கோவில் மணி", icon: "🔔" }
]
