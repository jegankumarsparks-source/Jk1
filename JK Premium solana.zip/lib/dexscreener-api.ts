// DexScreener API Integration for Live Solana Pairs - ADVANCED VERSION
export interface DexPair {
  chainId: string;
  dexId: string;
  url: string;
  pairAddress: string;
  baseToken: {
    address: string;
    name: string;
    symbol: string;
  };
  quoteToken: {
    address: string;
    name: string;
    symbol: string;
  };
  priceNative: string;
  priceUsd: string;
  txns: {
    m5: { buys: number; sells: number };
    h1: { buys: number; sells: number };
    h6: { buys: number; sells: number };
    h24: { buys: number; sells: number };
  };
  volume: {
    m5: number;
    h1: number;
    h6: number;
    h24: number;
  };
  priceChange: {
    m5: number;
    h1: number;
    h6: number;
    h24: number;
  };
  liquidity?: {
    usd: number;
    base: number;
    quote: number;
  };
  fdv?: number;
  marketCap?: number;
  pairCreatedAt?: number;
  info?: {
    imageUrl?: string;
    websites?: { url: string }[];
    socials?: { type: string; url: string }[];
  };
}

export interface ProcessedCoin {
  id: string;
  name: string;
  symbol: string;
  contractAddress: string;
  pairAddress: string;
  price: number;
  priceChange5m: number;
  priceChange1h: number;
  priceChange6h: number;
  priceChange24h: number;
  volume24h: number;
  volume6h: number;
  volume1h: number;
  volume5m: number;
  liquidity: number;
  marketCap: number;
  fdv: number;
  buys5m: number;
  sells5m: number;
  buys1h: number;
  sells1h: number;
  buys6h: number;
  sells6h: number;
  buys24h: number;
  sells24h: number;
  age: string;
  ageMinutes: number;
  signal: 'WHALE_ALERT' | 'STRONG_BUY' | 'BUY' | 'HOLD' | 'WATCH' | 'AVOID';
  riskLevel: 'VERY_LOW' | 'LOW' | 'MEDIUM' | 'HIGH' | 'DEGEN';
  winProbability: number;
  rugScore: number;
  whaleScore: number;
  momentumScore: number;
  liquidityScore: number;
  socialScore: number;
  overallScore: number;
  dexUrl: string;
  dexId: string;
  hasWebsite: boolean;
  hasSocials: boolean;
  imageUrl?: string;
  buyPressure: number;
  holders?: number;
  topHolderPercent?: number;
}

// Advanced Filtering Options
export interface AdvancedFilters {
  minLiquidity: number;
  maxLiquidity: number;
  minVolume1h: number;
  minVolume24h: number;
  minMarketCap: number;
  maxMarketCap: number;
  minAge: number; // minutes
  maxAge: number; // minutes
  minBuyRatio: number;
  minWinProbability: number;
  maxRugScore: number;
  minWhaleScore: number;
  minMomentumScore: number;
  showOnlyBuySignals: boolean;
  showOnlyWhaleAlerts: boolean;
  showOnlyNewLaunches: boolean;
  sortBy: 'newest' | 'volume' | 'liquidity' | 'momentum' | 'whale' | 'winProb' | 'overall';
}

export const defaultFilters: AdvancedFilters = {
  minLiquidity: 1000,
  maxLiquidity: 10000000,
  minVolume1h: 0,
  minVolume24h: 0,
  minMarketCap: 0,
  maxMarketCap: 100000000,
  minAge: 0,
  maxAge: 1440, // 24 hours
  minBuyRatio: 0,
  minWinProbability: 0,
  maxRugScore: 100,
  minWhaleScore: 0,
  minMomentumScore: 0,
  showOnlyBuySignals: false,
  showOnlyWhaleAlerts: false,
  showOnlyNewLaunches: false,
  sortBy: 'overall',
};

// Calculate age string from timestamp
function getAgeString(createdAt: number | undefined): { age: string; ageMinutes: number } {
  if (!createdAt) return { age: 'Unknown', ageMinutes: 9999 };
  
  const now = Date.now();
  const diffMs = now - createdAt;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMins < 60) return { age: `${diffMins}m`, ageMinutes: diffMins };
  if (diffHours < 24) return { age: `${diffHours}h ${diffMins % 60}m`, ageMinutes: diffMins };
  return { age: `${diffDays}d ${diffHours % 24}h`, ageMinutes: diffMins };
}

// Advanced Whale Detection Score (0-100)
function calculateWhaleScore(coin: {
  volume1h: number;
  volume24h: number;
  buys1h: number;
  sells1h: number;
  buys24h: number;
  sells24h: number;
  liquidity: number;
  marketCap: number;
}): number {
  let score = 0;
  
  const { volume1h, volume24h, buys1h, sells1h, buys24h, sells24h, liquidity, marketCap } = coin;
  
  // High volume relative to liquidity indicates whale activity
  const volumeToLiquidityRatio = liquidity > 0 ? volume1h / liquidity : 0;
  if (volumeToLiquidityRatio > 0.5) score += 30;
  else if (volumeToLiquidityRatio > 0.3) score += 20;
  else if (volumeToLiquidityRatio > 0.1) score += 10;
  
  // Large average transaction size
  const totalTxns1h = buys1h + sells1h;
  const avgTxnSize = totalTxns1h > 0 ? volume1h / totalTxns1h : 0;
  if (avgTxnSize > 5000) score += 25;
  else if (avgTxnSize > 2000) score += 15;
  else if (avgTxnSize > 500) score += 8;
  
  // Volume spike detection (1h vs 24h normalized)
  const hourlyAvg24h = volume24h / 24;
  const volumeSpike = hourlyAvg24h > 0 ? volume1h / hourlyAvg24h : 1;
  if (volumeSpike > 5) score += 25;
  else if (volumeSpike > 3) score += 15;
  else if (volumeSpike > 1.5) score += 8;
  
  // Buy dominance with high volume
  const buyRatio1h = sells1h > 0 ? buys1h / sells1h : buys1h;
  if (buyRatio1h > 3 && volume1h > 10000) score += 20;
  else if (buyRatio1h > 2 && volume1h > 5000) score += 12;
  else if (buyRatio1h > 1.5 && volume1h > 2000) score += 5;
  
  return Math.min(100, score);
}

// Advanced Momentum Score (0-100)
function calculateMomentumScore(coin: {
  priceChange5m: number;
  priceChange1h: number;
  priceChange6h: number;
  priceChange24h: number;
  buys5m: number;
  sells5m: number;
  buys1h: number;
  sells1h: number;
  volume5m: number;
  volume1h: number;
}): number {
  let score = 50; // Base score
  
  const { priceChange5m, priceChange1h, priceChange6h, priceChange24h, buys5m, sells5m, buys1h, sells1h, volume5m, volume1h } = coin;
  
  // Price momentum (recent > older is good)
  if (priceChange5m > priceChange1h && priceChange5m > 0) score += 15;
  if (priceChange1h > priceChange6h && priceChange1h > 0) score += 10;
  if (priceChange5m > 10 && priceChange5m < 200) score += 10;
  if (priceChange1h > 20 && priceChange1h < 300) score += 10;
  
  // Negative momentum
  if (priceChange5m < -10) score -= 15;
  if (priceChange1h < -20) score -= 15;
  if (priceChange24h < -50) score -= 20;
  
  // Buy pressure momentum
  const buyRatio5m = sells5m > 0 ? buys5m / sells5m : buys5m;
  const buyRatio1h = sells1h > 0 ? buys1h / sells1h : buys1h;
  
  if (buyRatio5m > buyRatio1h && buyRatio5m > 1.5) score += 15;
  if (buyRatio5m > 2) score += 10;
  
  // Volume momentum
  const volRatio = volume1h > 0 ? (volume5m * 12) / volume1h : 0; // Normalized to hourly
  if (volRatio > 2) score += 10;
  else if (volRatio > 1.5) score += 5;
  
  return Math.max(0, Math.min(100, score));
}

// Advanced Liquidity Score (0-100)
function calculateLiquidityScore(coin: {
  liquidity: number;
  volume24h: number;
  marketCap: number;
}): number {
  let score = 0;
  
  const { liquidity, volume24h, marketCap } = coin;
  
  // Absolute liquidity
  if (liquidity >= 100000) score += 35;
  else if (liquidity >= 50000) score += 28;
  else if (liquidity >= 20000) score += 20;
  else if (liquidity >= 10000) score += 12;
  else if (liquidity >= 5000) score += 5;
  
  // Liquidity to market cap ratio
  const liqToMcap = marketCap > 0 ? liquidity / marketCap : 0;
  if (liqToMcap > 0.1) score += 25;
  else if (liqToMcap > 0.05) score += 18;
  else if (liqToMcap > 0.02) score += 10;
  
  // Volume to liquidity ratio (healthy range)
  const volToLiq = liquidity > 0 ? volume24h / liquidity : 0;
  if (volToLiq > 0.5 && volToLiq < 5) score += 25;
  else if (volToLiq > 0.2 && volToLiq < 10) score += 15;
  else if (volToLiq > 0.1) score += 8;
  
  // Penalize very low or suspicious ratios
  if (volToLiq > 20) score -= 15; // Possible wash trading
  if (liqToMcap < 0.01) score -= 10; // Dangerously low liquidity
  
  return Math.max(0, Math.min(100, score));
}

// Social/Info Score (0-100)
function calculateSocialScore(pair: DexPair): number {
  let score = 0;
  
  if (pair.info?.websites && pair.info.websites.length > 0) score += 30;
  if (pair.info?.socials) {
    const socials = pair.info.socials;
    if (socials.find(s => s.type === 'twitter')) score += 25;
    if (socials.find(s => s.type === 'telegram')) score += 20;
    if (socials.find(s => s.type === 'discord')) score += 15;
  }
  if (pair.info?.imageUrl) score += 10;
  
  return Math.min(100, score);
}

// Calculate rug score (0-100, higher = more risky) - Enhanced
function calculateRugScore(coin: {
  liquidity: number;
  volume24h: number;
  buys1h: number;
  sells1h: number;
  buys24h: number;
  sells24h: number;
  ageMinutes: number;
  socialScore: number;
  priceChange24h: number;
}): number {
  let score = 40; // Base score
  
  const { liquidity, volume24h, buys1h, sells1h, buys24h, sells24h, ageMinutes, socialScore, priceChange24h } = coin;
  
  // Liquidity check
  if (liquidity < 2000) score += 30;
  else if (liquidity < 5000) score += 20;
  else if (liquidity < 10000) score += 12;
  else if (liquidity < 30000) score += 5;
  else if (liquidity > 100000) score -= 15;
  
  // Volume check
  if (volume24h < 500) score += 15;
  else if (volume24h < 2000) score += 8;
  else if (volume24h > 100000) score -= 10;
  
  // Age check
  if (ageMinutes < 5) score += 25;
  else if (ageMinutes < 15) score += 18;
  else if (ageMinutes < 30) score += 12;
  else if (ageMinutes < 60) score += 6;
  else if (ageMinutes > 1440) score -= 12;
  else if (ageMinutes > 4320) score -= 18;
  
  // Buy/sell ratio (high sells = red flag)
  const sellRatio1h = buys1h > 0 ? sells1h / buys1h : 2;
  const sellRatio24h = buys24h > 0 ? sells24h / buys24h : 2;
  if (sellRatio1h > 3) score += 18;
  else if (sellRatio1h > 2) score += 10;
  if (sellRatio24h > 2) score += 10;
  
  // Social presence reduces rug risk
  score -= (socialScore / 4);
  
  // Massive dump = high risk
  if (priceChange24h < -70) score += 25;
  else if (priceChange24h < -50) score += 15;
  
  return Math.max(0, Math.min(100, Math.round(score)));
}

// Calculate signal based on all metrics
function calculateSignal(coin: {
  whaleScore: number;
  momentumScore: number;
  liquidityScore: number;
  rugScore: number;
  priceChange5m: number;
  priceChange1h: number;
  buyPressure: number;
  ageMinutes: number;
  volume1h: number;
  liquidity: number;
}): 'WHALE_ALERT' | 'STRONG_BUY' | 'BUY' | 'HOLD' | 'WATCH' | 'AVOID' {
  const { whaleScore, momentumScore, liquidityScore, rugScore, priceChange5m, priceChange1h, buyPressure, ageMinutes, volume1h, liquidity } = coin;
  
  // AVOID conditions (safety first)
  if (rugScore > 75) return 'AVOID';
  if (liquidity < 3000) return 'AVOID';
  if (priceChange1h < -40) return 'AVOID';
  
  // WHALE ALERT - Strong whale activity with good metrics
  if (
    whaleScore >= 70 &&
    momentumScore >= 55 &&
    liquidityScore >= 40 &&
    rugScore < 50 &&
    buyPressure > 1.3
  ) {
    return 'WHALE_ALERT';
  }
  
  // STRONG BUY - Excellent metrics across the board
  if (
    momentumScore >= 65 &&
    liquidityScore >= 50 &&
    rugScore < 40 &&
    buyPressure > 1.5 &&
    priceChange5m > 3 &&
    priceChange5m < 150 &&
    volume1h > 5000
  ) {
    return 'STRONG_BUY';
  }
  
  // BUY - Good metrics
  if (
    momentumScore >= 55 &&
    liquidityScore >= 40 &&
    rugScore < 50 &&
    buyPressure > 1.2 &&
    priceChange5m > 0 &&
    volume1h > 2000
  ) {
    return 'BUY';
  }
  
  // HOLD - Decent metrics
  if (
    momentumScore >= 45 &&
    liquidityScore >= 30 &&
    rugScore < 60 &&
    buyPressure > 0.8
  ) {
    return 'HOLD';
  }
  
  // WATCH - Potential but needs monitoring
  if (rugScore < 65 && liquidity > 5000) {
    return 'WATCH';
  }
  
  return 'AVOID';
}

// Calculate risk level
function calculateRiskLevel(coin: {
  liquidity: number;
  ageMinutes: number;
  rugScore: number;
  volume24h: number;
  socialScore: number;
}): 'VERY_LOW' | 'LOW' | 'MEDIUM' | 'HIGH' | 'DEGEN' {
  const { liquidity, ageMinutes, rugScore, volume24h, socialScore } = coin;
  
  // Calculate composite risk
  let riskPoints = 0;
  
  // Age risk
  if (ageMinutes < 15) riskPoints += 30;
  else if (ageMinutes < 60) riskPoints += 20;
  else if (ageMinutes < 360) riskPoints += 10;
  
  // Liquidity risk
  if (liquidity < 5000) riskPoints += 30;
  else if (liquidity < 20000) riskPoints += 20;
  else if (liquidity < 50000) riskPoints += 10;
  else riskPoints -= 10;
  
  // Rug score contribution
  riskPoints += (rugScore / 3);
  
  // Social presence reduces risk
  riskPoints -= (socialScore / 5);
  
  // Categorize
  if (riskPoints >= 70) return 'DEGEN';
  if (riskPoints >= 50) return 'HIGH';
  if (riskPoints >= 30) return 'MEDIUM';
  if (riskPoints >= 15) return 'LOW';
  return 'VERY_LOW';
}

// Calculate overall win probability
function calculateWinProbability(coin: {
  signal: string;
  whaleScore: number;
  momentumScore: number;
  liquidityScore: number;
  rugScore: number;
  socialScore: number;
  buyPressure: number;
}): number {
  let probability = 40; // Base
  
  const { signal, whaleScore, momentumScore, liquidityScore, rugScore, socialScore, buyPressure } = coin;
  
  // Signal based
  switch (signal) {
    case 'WHALE_ALERT': probability += 25; break;
    case 'STRONG_BUY': probability += 20; break;
    case 'BUY': probability += 12; break;
    case 'HOLD': probability += 5; break;
    case 'WATCH': probability -= 5; break;
    case 'AVOID': probability -= 25; break;
  }
  
  // Score contributions
  probability += (whaleScore / 10);
  probability += (momentumScore / 8);
  probability += (liquidityScore / 10);
  probability -= (rugScore / 5);
  probability += (socialScore / 12);
  
  // Buy pressure bonus
  if (buyPressure > 2) probability += 8;
  else if (buyPressure > 1.5) probability += 5;
  
  return Math.max(5, Math.min(95, Math.round(probability)));
}

// Calculate overall score for ranking
function calculateOverallScore(coin: {
  whaleScore: number;
  momentumScore: number;
  liquidityScore: number;
  rugScore: number;
  socialScore: number;
  winProbability: number;
}): number {
  const { whaleScore, momentumScore, liquidityScore, rugScore, socialScore, winProbability } = coin;
  
  // Weighted average
  const score = (
    (whaleScore * 0.2) +
    (momentumScore * 0.25) +
    (liquidityScore * 0.2) +
    ((100 - rugScore) * 0.2) +
    (socialScore * 0.05) +
    (winProbability * 0.1)
  );
  
  return Math.round(score);
}

// Process raw DexScreener pairs into our format
export function processPairs(pairs: DexPair[]): ProcessedCoin[] {
  return pairs
    .filter(pair => pair.chainId === 'solana')
    .map((pair, index) => {
      const { age, ageMinutes } = getAgeString(pair.pairCreatedAt);
      
      const socialScore = calculateSocialScore(pair);
      
      const baseMetrics = {
        priceChange5m: pair.priceChange?.m5 || 0,
        priceChange1h: pair.priceChange?.h1 || 0,
        priceChange6h: pair.priceChange?.h6 || 0,
        priceChange24h: pair.priceChange?.h24 || 0,
        liquidity: pair.liquidity?.usd || 0,
        volume5m: pair.volume?.m5 || 0,
        volume1h: pair.volume?.h1 || 0,
        volume6h: pair.volume?.h6 || 0,
        volume24h: pair.volume?.h24 || 0,
        buys5m: pair.txns?.m5?.buys || 0,
        sells5m: pair.txns?.m5?.sells || 0,
        buys1h: pair.txns?.h1?.buys || 0,
        sells1h: pair.txns?.h1?.sells || 0,
        buys6h: pair.txns?.h6?.buys || 0,
        sells6h: pair.txns?.h6?.sells || 0,
        buys24h: pair.txns?.h24?.buys || 0,
        sells24h: pair.txns?.h24?.sells || 0,
        marketCap: pair.fdv || pair.marketCap || 0,
        ageMinutes,
        socialScore,
      };
      
      const whaleScore = calculateWhaleScore({
        volume1h: baseMetrics.volume1h,
        volume24h: baseMetrics.volume24h,
        buys1h: baseMetrics.buys1h,
        sells1h: baseMetrics.sells1h,
        buys24h: baseMetrics.buys24h,
        sells24h: baseMetrics.sells24h,
        liquidity: baseMetrics.liquidity,
        marketCap: baseMetrics.marketCap,
      });
      
      const momentumScore = calculateMomentumScore({
        priceChange5m: baseMetrics.priceChange5m,
        priceChange1h: baseMetrics.priceChange1h,
        priceChange6h: baseMetrics.priceChange6h,
        priceChange24h: baseMetrics.priceChange24h,
        buys5m: baseMetrics.buys5m,
        sells5m: baseMetrics.sells5m,
        buys1h: baseMetrics.buys1h,
        sells1h: baseMetrics.sells1h,
        volume5m: baseMetrics.volume5m,
        volume1h: baseMetrics.volume1h,
      });
      
      const liquidityScore = calculateLiquidityScore({
        liquidity: baseMetrics.liquidity,
        volume24h: baseMetrics.volume24h,
        marketCap: baseMetrics.marketCap,
      });
      
      const rugScore = calculateRugScore({
        ...baseMetrics,
        socialScore,
      });
      
      const buyPressure = baseMetrics.sells1h > 0 
        ? baseMetrics.buys1h / baseMetrics.sells1h 
        : baseMetrics.buys1h > 0 ? 5 : 1;
      
      const signal = calculateSignal({
        whaleScore,
        momentumScore,
        liquidityScore,
        rugScore,
        priceChange5m: baseMetrics.priceChange5m,
        priceChange1h: baseMetrics.priceChange1h,
        buyPressure,
        ageMinutes,
        volume1h: baseMetrics.volume1h,
        liquidity: baseMetrics.liquidity,
      });
      
      const riskLevel = calculateRiskLevel({
        liquidity: baseMetrics.liquidity,
        ageMinutes,
        rugScore,
        volume24h: baseMetrics.volume24h,
        socialScore,
      });
      
      const winProbability = calculateWinProbability({
        signal,
        whaleScore,
        momentumScore,
        liquidityScore,
        rugScore,
        socialScore,
        buyPressure,
      });
      
      const overallScore = calculateOverallScore({
        whaleScore,
        momentumScore,
        liquidityScore,
        rugScore,
        socialScore,
        winProbability,
      });
      
      const coin: ProcessedCoin = {
        id: `pair-${index}-${pair.pairAddress}`,
        name: pair.baseToken.name,
        symbol: pair.baseToken.symbol,
        contractAddress: pair.baseToken.address,
        pairAddress: pair.pairAddress,
        price: parseFloat(pair.priceUsd) || 0,
        priceChange5m: baseMetrics.priceChange5m,
        priceChange1h: baseMetrics.priceChange1h,
        priceChange6h: baseMetrics.priceChange6h,
        priceChange24h: baseMetrics.priceChange24h,
        volume24h: baseMetrics.volume24h,
        volume6h: baseMetrics.volume6h,
        volume1h: baseMetrics.volume1h,
        volume5m: baseMetrics.volume5m,
        liquidity: baseMetrics.liquidity,
        marketCap: baseMetrics.marketCap,
        fdv: pair.fdv || 0,
        buys5m: baseMetrics.buys5m,
        sells5m: baseMetrics.sells5m,
        buys1h: baseMetrics.buys1h,
        sells1h: baseMetrics.sells1h,
        buys6h: baseMetrics.buys6h,
        sells6h: baseMetrics.sells6h,
        buys24h: baseMetrics.buys24h,
        sells24h: baseMetrics.sells24h,
        age,
        ageMinutes,
        signal,
        riskLevel,
        winProbability,
        rugScore,
        whaleScore,
        momentumScore,
        liquidityScore,
        socialScore,
        overallScore,
        dexUrl: pair.url,
        dexId: pair.dexId,
        hasWebsite: !!(pair.info?.websites && pair.info.websites.length > 0),
        hasSocials: !!(pair.info?.socials && pair.info.socials.length > 0),
        imageUrl: pair.info?.imageUrl,
        buyPressure,
      };
      
      return coin;
    })
    .sort((a, b) => b.overallScore - a.overallScore);
}

// Apply advanced filters
export function applyFilters(coins: ProcessedCoin[], filters: AdvancedFilters): ProcessedCoin[] {
  let filtered = coins.filter(coin => {
    if (coin.liquidity < filters.minLiquidity) return false;
    if (coin.liquidity > filters.maxLiquidity) return false;
    if (coin.volume1h < filters.minVolume1h) return false;
    if (coin.volume24h < filters.minVolume24h) return false;
    if (coin.marketCap < filters.minMarketCap && coin.marketCap > 0) return false;
    if (coin.marketCap > filters.maxMarketCap && filters.maxMarketCap > 0) return false;
    if (coin.ageMinutes < filters.minAge) return false;
    if (coin.ageMinutes > filters.maxAge) return false;
    if (coin.buyPressure < filters.minBuyRatio) return false;
    if (coin.winProbability < filters.minWinProbability) return false;
    if (coin.rugScore > filters.maxRugScore) return false;
    if (coin.whaleScore < filters.minWhaleScore) return false;
    if (coin.momentumScore < filters.minMomentumScore) return false;
    
    if (filters.showOnlyBuySignals && !['BUY', 'STRONG_BUY', 'WHALE_ALERT'].includes(coin.signal)) return false;
    if (filters.showOnlyWhaleAlerts && coin.signal !== 'WHALE_ALERT') return false;
    if (filters.showOnlyNewLaunches && coin.ageMinutes > 60) return false;
    
    return true;
  });
  
  // Sort
  switch (filters.sortBy) {
    case 'newest':
      filtered.sort((a, b) => a.ageMinutes - b.ageMinutes);
      break;
    case 'volume':
      filtered.sort((a, b) => b.volume1h - a.volume1h);
      break;
    case 'liquidity':
      filtered.sort((a, b) => b.liquidity - a.liquidity);
      break;
    case 'momentum':
      filtered.sort((a, b) => b.momentumScore - a.momentumScore);
      break;
    case 'whale':
      filtered.sort((a, b) => b.whaleScore - a.whaleScore);
      break;
    case 'winProb':
      filtered.sort((a, b) => b.winProbability - a.winProbability);
      break;
    case 'overall':
    default:
      filtered.sort((a, b) => b.overallScore - a.overallScore);
  }
  
  return filtered;
}

// Helper functions for links
export const getDexScreenerLink = (pairAddress: string) => 
  `https://dexscreener.com/solana/${pairAddress}`;

export const getJupiterBuyLink = (contractAddress: string) => 
  `https://jup.ag/swap/SOL-${contractAddress}`;

export const getRaydiumBuyLink = (contractAddress: string) => 
  `https://raydium.io/swap/?inputMint=sol&outputMint=${contractAddress}`;

export const getBirdeyeLink = (contractAddress: string) => 
  `https://birdeye.so/token/${contractAddress}?chain=solana`;

export const getRugCheckLink = (contractAddress: string) => 
  `https://rugcheck.xyz/tokens/${contractAddress}`;

export const getSolscanLink = (contractAddress: string) => 
  `https://solscan.io/token/${contractAddress}`;

export const getPumpFunLink = () => 
  `https://pump.fun/`;

export const getGmgnLink = (contractAddress: string) => 
  `https://gmgn.ai/sol/token/${contractAddress}`;

export const getPhotonLink = (contractAddress: string) =>
  `https://photon-sol.tinyastro.io/en/lp/${contractAddress}`;

export const getBullxLink = (contractAddress: string) =>
  `https://bullx.io/terminal?chainId=1399811149&address=${contractAddress}`;
