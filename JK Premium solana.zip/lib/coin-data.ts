export interface MemeСoin {
  id: string;
  name: string;
  symbol: string;
  price: number;
  priceChange24h: number;
  marketCap: number;
  liquidity: number;
  volume24h: number;
  holders: number;
  age: string;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'DEGEN';
  signal: 'BUY' | 'HOLD' | 'WATCH' | 'AVOID';
  contractAddress: string;
  pairAddress: string;
  launchTime: Date;
  socialScore: number;
  rugPullRisk: number;
}

// Helper functions for generating trading links
export const getDexScreenerLink = (pairAddress: string) => 
  `https://dexscreener.com/solana/${pairAddress}`;

export const getJupiterBuyLink = (contractAddress: string) => 
  `https://jup.ag/swap/SOL-${contractAddress}`;

export const getRaydiumBuyLink = (contractAddress: string) => 
  `https://raydium.io/swap/?inputMint=sol&outputMint=${contractAddress}`;

export const getBirdeyeLink = (contractAddress: string) => 
  `https://birdeye.so/token/${contractAddress}?chain=solana`;

export const getRugCheckLink = (contractAddress: string) => 
  `https://rugcheck.xyz/tokens/${contractAddress}`;

export const getSolscanLink = (contractAddress: string) => 
  `https://solscan.io/token/${contractAddress}`;

export const tradingTips = [
  {
    id: 1,
    title: "DYOR Pannunga Machi!",
    tip: "Eppo kooda oru coin vangarathuku munna, contract address verify pannunga. Rugcheck.xyz use pannunga.",
    category: "safety"
  },
  {
    id: 2,
    title: "Liquidity Check Pannunga",
    tip: "Minimum $10K liquidity irukkanum. Liquidity lock irukka nu check pannunga - team withdraw panna mudiyathu.",
    category: "analysis"
  },
  {
    id: 3,
    title: "Entry/Exit Strategy Venum",
    tip: "2x la half sell pannunga, 5x la another quarter. Original investment safe ah irukum!",
    category: "strategy"
  },
  {
    id: 4,
    title: "FOMO Avoid Pannunga",
    tip: "Already 100x ana coin la late entry vendam. Pudhu coins la early entry best!",
    category: "mindset"
  },
  {
    id: 5,
    title: "Social Check Important",
    tip: "Twitter, Telegram activity parunga. Real community irukkanum, bots vendam!",
    category: "analysis"
  },
  {
    id: 6,
    title: "Small Amounts Start Pannunga",
    tip: "Per trade $10-$15 max. 8 coins la spread pannunga daily. Oru moon ah irunthalum profit!",
    category: "strategy"
  }
];

// Sample Solana token data with real contract address format
export const generateMockCoins = (): MemeСoin[] => {
  const coinData = [
    { 
      name: "DogeMoon", 
      symbol: "DMOON",
      contract: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
      pair: "8HoQnePLqPj4M7PUDzfw8e3Ymdwgc7NLGnaTUapubyvu"
    },
    { 
      name: "CatSol", 
      symbol: "CATSOL",
      contract: "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr",
      pair: "9wFFyRfZBsuAha4YcuxcXLKwMxJR43S7fPfQLusDBzvT"
    },
    { 
      name: "PepeSolana", 
      symbol: "PSOL",
      contract: "CATSm6voKgwLqy8Dxe1xzWPe6S4J8MDTH6aL8L8Nqkzp",
      pair: "HZ1znC9XBasm9AMDhGocd9EHSyH8Pyj1EUdiPb4WnZjo"
    },
    { 
      name: "ShibaSun", 
      symbol: "SHISUN",
      contract: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
      pair: "GQsPr4RJk9AZkkfWHud7v8pQV4Rr2QeUjwq9gMRwm5K3"
    },
    { 
      name: "FroggyFi", 
      symbol: "FROGFI",
      contract: "FRoGsnKLZ2x9Cxj2L3pYjLWzscHhv9e9YKqBns5Rpump",
      pair: "3ne4mWqdYuNiYrYZC9TrA3FcfuFdErghH97vNPbjicr1"
    },
    { 
      name: "BonkBaby", 
      symbol: "BBONK",
      contract: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
      pair: "8QaXeHBrShJTdtN1rWCccBxpSVvKksQ2PCu5nufb2zbk"
    },
    { 
      name: "WenLambo", 
      symbol: "WLAMBO",
      contract: "WENWENvqqNya429ubCdR81ZmD69brwQaaBYY6p3LCpk",
      pair: "EP2ib6dYdEeqD8MfE2ezHCxX3kP3K2eLKkirfPm5eyMx"
    },
    { 
      name: "MoonRocket", 
      symbol: "MROCKET",
      contract: "MoonGEATbV8pqTWzT2tUjZn5E4x4A3GXWMn1GQKwrpK",
      pair: "FpCMFDFGYotvufJ7HrFHsWEiiQCGbkLCtwHiDnh7o28Q"
    }
  ];

  const riskLevels: ('LOW' | 'MEDIUM' | 'HIGH' | 'DEGEN')[] = ['LOW', 'MEDIUM', 'HIGH', 'DEGEN'];
  const signals: ('BUY' | 'HOLD' | 'WATCH' | 'AVOID')[] = ['BUY', 'HOLD', 'WATCH', 'AVOID'];
  const ages = ['2m', '5m', '15m', '30m', '1h', '2h', '4h', '12h', '1d'];

  return coinData.map((coin, index) => {
    const riskIndex = Math.floor(Math.random() * 4);
    const signalIndex = Math.min(riskIndex, 3);
    
    return {
      id: `coin-${index}`,
      name: coin.name,
      symbol: coin.symbol,
      price: Math.random() * 0.001,
      priceChange24h: (Math.random() - 0.3) * 500,
      marketCap: Math.random() * 500000 + 10000,
      liquidity: Math.random() * 100000 + 5000,
      volume24h: Math.random() * 200000 + 10000,
      holders: Math.floor(Math.random() * 5000) + 100,
      age: ages[Math.floor(Math.random() * ages.length)],
      riskLevel: riskLevels[riskIndex],
      signal: signals[signalIndex],
      contractAddress: coin.contract,
      pairAddress: coin.pair,
      launchTime: new Date(Date.now() - Math.random() * 86400000),
      socialScore: Math.floor(Math.random() * 100),
      rugPullRisk: Math.floor(Math.random() * 100)
    };
  });
};

export const portfolioStats = {
  initialInvestment: 100,
  currentValue: 287.45,
  totalProfit: 187.45,
  profitPercentage: 187.45,
  totalTrades: 24,
  winRate: 62.5,
  bestTrade: { coin: "BBONK", profit: 450 },
  worstTrade: { coin: "SDEGEN", loss: -85 },
  dailyTarget: 33.33, // To reach $1000 from $100 in 30 days
  daysRemaining: 27
};

export const milestones = [
  { target: 150, label: "1.5x", reached: true },
  { target: 200, label: "2x", reached: true },
  { target: 300, label: "3x", reached: false },
  { target: 500, label: "5x", reached: false },
  { target: 1000, label: "10x MILLIONAIRE", reached: false }
];
