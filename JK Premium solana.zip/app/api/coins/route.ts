import { NextResponse } from 'next/server';
import { processPairs, type DexPair } from '@/lib/dexscreener-api';

export const revalidate = 0;
export const dynamic = 'force-dynamic';

async function fetchAllSources(): Promise<DexPair[]> {
  const allPairs: DexPair[] = [];
  const seenAddresses = new Set<string>();

  try {
    // Fetch from multiple valid endpoints in parallel
    const responses = await Promise.all([
      fetch('https://api.dexscreener.com/token-boosts/latest/v1', {
        headers: { 'Accept': 'application/json' },
        cache: 'no-store',
        signal: AbortSignal.timeout(8000),
      }).catch(() => null),
      
      fetch('https://api.dexscreener.com/token-profiles/latest/v1', {
        headers: { 'Accept': 'application/json' },
        cache: 'no-store',
        signal: AbortSignal.timeout(8000),
      }).catch(() => null),

      fetch('https://api.dexscreener.com/token-boosts/top/v1', {
        headers: { 'Accept': 'application/json' },
        cache: 'no-store',
        signal: AbortSignal.timeout(8000),
      }).catch(() => null),

      fetch('https://api.dexscreener.com/latest/dex/search?q=SOL', {
        headers: { 'Accept': 'application/json' },
        cache: 'no-store',
        signal: AbortSignal.timeout(8000),
      }).catch(() => null),

      fetch('https://api.dexscreener.com/latest/dex/search?q=pump', {
        headers: { 'Accept': 'application/json' },
        cache: 'no-store',
        signal: AbortSignal.timeout(8000),
      }).catch(() => null),
    ]);

    const [boostResponse, profilesResponse, trendingResponse, solSearchResponse, pumpSearchResponse] = responses;
    const tokenAddresses: string[] = [];

    // Extract Solana tokens from boosted
    if (boostResponse?.ok) {
      try {
        const data = await boostResponse.json();
        if (Array.isArray(data)) {
          data
            .filter((t: { chainId?: string }) => t.chainId === 'solana')
            .slice(0, 60)
            .forEach((t: { tokenAddress?: string }) => {
              if (t.tokenAddress && !seenAddresses.has(t.tokenAddress)) {
                seenAddresses.add(t.tokenAddress);
                tokenAddresses.push(t.tokenAddress);
              }
            });
        }
      } catch { /* ignore */ }
    }

    // Extract from profiles (newest launches)
    if (profilesResponse?.ok) {
      try {
        const data = await profilesResponse.json();
        if (Array.isArray(data)) {
          data
            .filter((t: { chainId?: string }) => t.chainId === 'solana')
            .slice(0, 80)
            .forEach((t: { tokenAddress?: string }) => {
              if (t.tokenAddress && !seenAddresses.has(t.tokenAddress)) {
                seenAddresses.add(t.tokenAddress);
                tokenAddresses.push(t.tokenAddress);
              }
            });
        }
      } catch { /* ignore */ }
    }

    // Extract from trending
    if (trendingResponse?.ok) {
      try {
        const data = await trendingResponse.json();
        if (Array.isArray(data)) {
          data
            .filter((t: { chainId?: string }) => t.chainId === 'solana')
            .slice(0, 50)
            .forEach((t: { tokenAddress?: string }) => {
              if (t.tokenAddress && !seenAddresses.has(t.tokenAddress)) {
                seenAddresses.add(t.tokenAddress);
                tokenAddresses.push(t.tokenAddress);
              }
            });
        }
      } catch { /* ignore */ }
    }

    // Process SOL search results - ONLY SOL PAIRS
    const processSearchResponse = async (response: Response | null) => {
      if (response?.ok) {
        try {
          const data = await response.json();
          if (data.pairs && Array.isArray(data.pairs)) {
            const pairAddressSeen = new Set(allPairs.map(p => p.pairAddress));
            data.pairs
              .filter((p: DexPair) => {
                // ONLY SOLANA CHAIN AND SOL PAIRS
                if (p.chainId !== 'solana') return false;
                // Must be paired with SOL (WSOL)
                const quoteSymbol = p.quoteToken?.symbol?.toUpperCase();
                return quoteSymbol === 'SOL' || quoteSymbol === 'WSOL';
              })
              .slice(0, 60)
              .forEach((p: DexPair) => {
                if (!pairAddressSeen.has(p.pairAddress)) {
                  pairAddressSeen.add(p.pairAddress);
                  allPairs.push(p);
                }
                if (p.baseToken?.address && !seenAddresses.has(p.baseToken.address)) {
                  seenAddresses.add(p.baseToken.address);
                  tokenAddresses.push(p.baseToken.address);
                }
              });
          }
        } catch { /* ignore */ }
      }
    };

    await processSearchResponse(solSearchResponse);
    await processSearchResponse(pumpSearchResponse);

    // Fetch detailed pair data for collected tokens
    if (tokenAddresses.length > 0) {
      const batchSize = 30;
      const batches: string[][] = [];
      
      for (let i = 0; i < tokenAddresses.length; i += batchSize) {
        batches.push(tokenAddresses.slice(i, i + batchSize));
      }

      const batchResponses = await Promise.all(
        batches.map(batch => 
          fetch(`https://api.dexscreener.com/latest/dex/tokens/${batch.join(',')}`, {
            headers: { 'Accept': 'application/json' },
            cache: 'no-store',
            signal: AbortSignal.timeout(10000),
          }).catch(() => null)
        )
      );

      const pairAddressSeen = new Set(allPairs.map(p => p.pairAddress));
      
      for (const response of batchResponses) {
        if (response?.ok) {
          try {
            const data = await response.json();
            if (data.pairs && Array.isArray(data.pairs)) {
              data.pairs
                .filter((p: DexPair) => {
                  // ONLY SOLANA + SOL PAIRS
                  if (p.chainId !== 'solana') return false;
                  const quoteSymbol = p.quoteToken?.symbol?.toUpperCase();
                  return quoteSymbol === 'SOL' || quoteSymbol === 'WSOL';
                })
                .forEach((p: DexPair) => {
                  if (!pairAddressSeen.has(p.pairAddress)) {
                    pairAddressSeen.add(p.pairAddress);
                    allPairs.push(p);
                  }
                });
            }
          } catch { /* ignore */ }
        }
      }
    }

  } catch (error) {
    console.error('[API] Error fetching sources:', error);
  }

  return allPairs;
}

export async function GET() {
  try {
    const allPairs = await fetchAllSources();
    const processedCoins = processPairs(allPairs);
    
    // WHALE ALERTS - Early Entry Detection - Minimum 10 guaranteed
    let whaleAlerts = processedCoins
      .filter(c => c.signal === 'WHALE_ALERT' && c.liquidity > 3000)
      .slice(0, 20);
    
    // Expand whale detection for early entry
    if (whaleAlerts.length < 10) {
      const additionalWhales = processedCoins
        .filter(c => 
          c.whaleScore >= 40 && 
          c.liquidity > 2000 &&
          !whaleAlerts.find(w => w.id === c.id)
        )
        .sort((a, b) => b.whaleScore - a.whaleScore)
        .slice(0, 10 - whaleAlerts.length);
      
      whaleAlerts = [...whaleAlerts, ...additionalWhales];
    }
    
    // Add more potential whale entries
    if (whaleAlerts.length < 10) {
      const potentialWhales = processedCoins
        .filter(c => 
          c.buyPressure > 1.5 &&
          c.volume1h > 500 &&
          c.liquidity > 1500 &&
          !whaleAlerts.find(w => w.id === c.id)
        )
        .sort((a, b) => b.buyPressure - a.buyPressure)
        .slice(0, 10 - whaleAlerts.length);
      
      whaleAlerts = [...whaleAlerts, ...potentialWhales];
    }

    // SURE HITS - Always 20 coins guaranteed
    // Combined best signals: whale + buy + low risk + high win probability
    const sureHits = processedCoins
      .filter(c => {
        // Multiple criteria for "sure hit"
        const hasGoodLiquidity = c.liquidity > 2000;
        const hasLowRug = c.rugScore < 60;
        const hasGoodWinRate = c.winProbability >= 35;
        const hasBuySignal = ['BUY', 'STRONG_BUY', 'WHALE_ALERT'].includes(c.signal);
        const hasPositiveMomentum = c.momentumScore >= 30;
        
        return hasGoodLiquidity && hasLowRug && (hasGoodWinRate || hasBuySignal || hasPositiveMomentum);
      })
      .sort((a, b) => {
        // Score based on multiple factors
        const scoreA = a.winProbability + a.whaleScore + a.momentumScore - a.rugScore;
        const scoreB = b.winProbability + b.whaleScore + b.momentumScore - b.rugScore;
        return scoreB - scoreA;
      })
      .slice(0, 20);

    // If not enough sure hits, add more from best available
    const finalSureHits = sureHits.length >= 20 ? sureHits : [
      ...sureHits,
      ...processedCoins
        .filter(c => !sureHits.find(s => s.id === c.id) && c.liquidity > 1000)
        .sort((a, b) => b.overallScore - a.overallScore)
        .slice(0, 20 - sureHits.length)
    ];

    // TOP 20 NEW LAUNCHES
    const newCoins = processedCoins
      .filter(c => c.ageMinutes < 1440 && c.liquidity > 500)
      .sort((a, b) => a.ageMinutes - b.ageMinutes)
      .slice(0, 20);
    
    // SUGGESTED - High confidence picks
    const suggested = processedCoins
      .filter(c => c.winProbability >= 40 && c.liquidity > 3000 && c.rugScore < 60)
      .sort((a, b) => b.winProbability - a.winProbability)
      .slice(0, 20);
    
    // BUY SIGNALS
    const buySignals = processedCoins
      .filter(c => ['BUY', 'STRONG_BUY', 'WHALE_ALERT'].includes(c.signal))
      .sort((a, b) => b.momentumScore - a.momentumScore)
      .slice(0, 20);
    
    // TRENDING - High volume
    const trending = processedCoins
      .filter(c => c.volume1h > 50)
      .sort((a, b) => b.volume1h - a.volume1h)
      .slice(0, 20);
    
    // HIGH MOMENTUM
    const highMomentum = processedCoins
      .filter(c => c.momentumScore >= 50 && c.liquidity > 2000)
      .sort((a, b) => b.momentumScore - a.momentumScore)
      .slice(0, 20);
    
    // LOW RISK - Safe picks
    const lowRisk = processedCoins
      .filter(c => c.rugScore < 40 && c.liquidity > 5000)
      .sort((a, b) => a.rugScore - b.rugScore)
      .slice(0, 20);
    
    // EARLY GEMS
    const earlyGems = processedCoins
      .filter(c => 
        c.ageMinutes < 240 && 
        c.liquidity > 2000 && 
        c.rugScore < 55 &&
        c.buyPressure > 1.1
      )
      .sort((a, b) => b.overallScore - a.overallScore)
      .slice(0, 20);

    const totalCoins = processedCoins.length;
    const avgWinRate = processedCoins.length > 0 
      ? Math.round(processedCoins.reduce((acc, c) => acc + c.winProbability, 0) / processedCoins.length)
      : 0;
    
    return NextResponse.json({
      success: true,
      timestamp: Date.now(),
      stats: {
        totalCoins,
        avgWinRate,
        buySignals: buySignals.length,
        newCoinsCount: newCoins.length,
        whaleAlertsCount: whaleAlerts.length,
        suggestedCount: suggested.length,
        sureHitsCount: finalSureHits.length,
      },
      coins: {
        all: processedCoins.slice(0, 50),
        whaleAlerts,
        buySignals,
        newCoins,
        trending,
        suggested,
        highMomentum,
        lowRisk,
        earlyGems,
        sureHits: finalSureHits,
      }
    });
  } catch (error) {
    console.error('[API] Error:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch live data',
      timestamp: Date.now(),
      stats: { totalCoins: 0, avgWinRate: 0, buySignals: 0, newCoinsCount: 0, whaleAlertsCount: 0, suggestedCount: 0, sureHitsCount: 0 },
      coins: { all: [], whaleAlerts: [], buySignals: [], newCoins: [], trending: [], suggested: [], highMomentum: [], lowRisk: [], earlyGems: [], sureHits: [] }
    }, { status: 500 });
  }
}
