"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import useSWR from "swr";
import { HackerHeader } from "@/components/hacker/header";
import { StatsPanel } from "@/components/hacker/stats-panel";
import { CoinList } from "@/components/hacker/coin-list";
import { AdvancedFilters } from "@/components/hacker/advanced-filters";
import { QuickLinks } from "@/components/hacker/quick-links";
import { Footer } from "@/components/hacker/footer";
import type { ProcessedCoin } from "@/lib/dexscreener-api";
import { Sliders, ChevronDown, ChevronUp, Zap, Target } from "lucide-react";

interface ApiResponse {
  success: boolean;
  timestamp: number;
  stats: {
    totalCoins: number;
    avgWinRate: number;
    buySignals: number;
    newCoinsCount: number;
    whaleAlertsCount: number;
    suggestedCount: number;
    sureHitsCount: number;
  };
  coins: {
    all: ProcessedCoin[];
    whaleAlerts: ProcessedCoin[];
    buySignals: ProcessedCoin[];
    newCoins: ProcessedCoin[];
    trending: ProcessedCoin[];
    suggested: ProcessedCoin[];
    highMomentum: ProcessedCoin[];
    lowRisk: ProcessedCoin[];
    earlyGems: ProcessedCoin[];
    sureHits: ProcessedCoin[];
  };
}

const fetcher = (url: string) => fetch(url).then(res => res.json());

export default function Home() {
  const [mounted, setMounted] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMounted(true);
    
    // Suppress ResizeObserver error
    const handleError = (e: ErrorEvent) => {
      if (e.message?.includes('ResizeObserver')) {
        e.stopImmediatePropagation();
        e.preventDefault();
        return false;
      }
    };
    
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  // LIVE UPDATE - Every 2 seconds
  const { data, error, isLoading, mutate } = useSWR<ApiResponse>(
    '/api/coins',
    fetcher,
    {
      refreshInterval: 2000,
      revalidateOnFocus: true,
      dedupingInterval: 1000,
      keepPreviousData: true,
    }
  );

  const handleRefresh = useCallback(() => {
    mutate();
  }, [mutate]);

  const isLive = !error && !!data?.success;
  const stats = data?.stats || { 
    totalCoins: 0, 
    avgWinRate: 0, 
    buySignals: 0, 
    newCoinsCount: 0,
    whaleAlertsCount: 0,
    suggestedCount: 0,
    sureHitsCount: 0
  };
  const coins = data?.coins || { 
    all: [], 
    whaleAlerts: [],
    buySignals: [], 
    newCoins: [], 
    trending: [], 
    suggested: [],
    highMomentum: [],
    lowRisk: [],
    earlyGems: [],
    sureHits: []
  };
  const lastUpdate = data?.timestamp || Date.now();

  if (!mounted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center gradient-mesh">
        <div className="text-center px-4 animate-bounce-in">
          <div className="h-14 w-14 mx-auto mb-4 rounded-2xl gradient-primary flex items-center justify-center">
            <Zap className="h-7 w-7 text-primary-foreground animate-pulse" />
          </div>
          <h1 className="text-xl font-black text-foreground mb-2">JK WORKSHOP</h1>
          <p className="text-sm text-muted-foreground font-mono">CONNECTING TO SOLANA...</p>
          <div className="mt-4 flex justify-center gap-1">
            {[0, 1, 2].map((i) => (
              <div 
                key={i} 
                className="h-2 w-2 rounded-full bg-primary animate-bounce"
                style={{ animationDelay: `${i * 0.15}s` }}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="min-h-screen bg-background relative overflow-x-hidden">
      {/* Background effects */}
      <div className="fixed inset-0 gradient-mesh pointer-events-none opacity-50" />
      
      <div className="relative z-10">
        <HackerHeader isLive={isLive} />
        
        <main className="mx-auto max-w-7xl px-3 sm:px-4 py-4 sm:py-6 safe-bottom">
          {/* Hero Section */}
          <div className="mb-6 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/30 mb-3">
              <Target className="h-4 w-4 text-primary" />
              <span className="text-xs font-bold text-primary">SOLANA SOL PAIRS ONLY</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-foreground tracking-tight mb-2">
              <span className="text-primary">JK</span> WORKSHOP
            </h1>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Whale Early Entry Detection • Sure Hit 20 Coins • Live Analysis
            </p>
            
            {/* Live Stats Bar */}
            <div className="flex flex-wrap items-center justify-center gap-3 mt-4">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-yellow-500/10 border border-yellow-500/30">
                <Zap className="h-4 w-4 text-yellow-400" />
                <span className="text-xs font-bold text-yellow-400">{stats.whaleAlertsCount} WHALE ALERTS</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-500/10 border border-green-500/30">
                <Target className="h-4 w-4 text-green-400" />
                <span className="text-xs font-bold text-green-400">{stats.sureHitsCount || 20} SURE HITS</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className={`h-2.5 w-2.5 rounded-full ${isLive ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
                <span className="text-xs text-muted-foreground">
                  {isLive ? 'LIVE' : 'RECONNECTING'}
                </span>
              </div>
            </div>
          </div>

          {/* Stats Panel - Touchable Cards with Mini Tabs */}
          <div className="mb-4 sm:mb-6">
            <StatsPanel stats={stats} lastUpdate={lastUpdate} coins={coins} />
          </div>

          {/* Quick Links */}
          <div className="mb-4 sm:mb-6 overflow-x-auto -mx-3 px-3 sm:mx-0 sm:px-0 scrollbar-hide">
            <QuickLinks />
          </div>

          {/* Advanced Filters Toggle */}
          <div className="mb-4">
            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className="w-full flex items-center justify-between gap-2 px-4 py-3 rounded-xl glass-card border border-border/50 hover:border-primary/50 touch-btn transition-all active:scale-[0.98]"
            >
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg gradient-primary flex items-center justify-center">
                  <Sliders className="h-4 w-4 text-primary-foreground" />
                </div>
                <div className="text-left">
                  <span className="text-sm font-bold text-foreground">ADVANCED FILTERS</span>
                  <p className="text-[10px] text-muted-foreground">Customize your search</p>
                </div>
              </div>
              {showFilters ? (
                <ChevronUp className="h-5 w-5 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-5 w-5 text-muted-foreground" />
              )}
            </button>
          </div>

          {/* Advanced Filters Panel */}
          {showFilters && (
            <div className="mb-6 animate-bounce-in">
              <AdvancedFilters />
            </div>
          )}

          {/* Main Coin List */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg font-black text-foreground">
                  SOL PAIRS
                </h2>
                <p className="text-xs text-muted-foreground">
                  Live Solana pairs with DexScreener links
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Updated</p>
                <p className="text-sm font-mono text-primary">
                  {new Date(lastUpdate).toLocaleTimeString()}
                </p>
              </div>
            </div>
            <CoinList 
              coins={coins} 
              isLoading={isLoading} 
              onRefresh={handleRefresh}
            />
          </div>
        </main>

        <Footer />
      </div>
    </div>
  );
}
