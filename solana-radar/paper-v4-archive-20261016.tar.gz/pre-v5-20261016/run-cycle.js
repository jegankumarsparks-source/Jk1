const fs=require('fs'),vm=require('vm');
const {policy,qualify,fillGate,exitReason}=require('./paper-policy-v4');
const dir=__dirname,statePath=dir+'/state.json';
let d=JSON.parse(fs.readFileSync(statePath,'utf8'));
const save=()=>{fs.writeFileSync(statePath+'.tmp',JSON.stringify(d,null,2));fs.renameSync(statePath+'.tmp',statePath);};
const ctx={console,fetch,AbortController,setTimeout,clearTimeout,Math,Date,JSON,Map,Set,encodeURIComponent};
vm.createContext(ctx);vm.runInContext(fs.readFileSync(dir+'/engine-core.js','utf8')+'\nthis.engine={S,AUTO,REG,DEX,DISCOVERY,WALLETS,CLUSTERS,RISK,QUAL,RPC};this.scorer=SCORER;',ctx);
const {S,AUTO,REG,DEX,DISCOVERY,WALLETS,CLUSTERS,RISK,QUAL,RPC}=ctx.engine;
for(const k of ['candidates','wallets','signals'])S[k]=new Map(d[k]||[]);
S.scoreHistory=d.scoreHistory||[]; AUTO.positions=new Map(d.positions.map(p=>[p.id,p]));AUTO._cash=d.cash;AUTO.history=d.history;
// Source failures fail closed; avoid long automatic retries within a five-minute checkpoint.
const base=REG.fetchJSON.bind(REG);REG.fetchJSON=(id,url,opts={})=>base(id,url,{...opts,retries:0,timeoutMs:7000});
const started=Date.now(),before=d.eventsReported||0;
const sync=()=>{d.cash=AUTO.cash();d.positions=[...AUTO.positions.values()];d.history=AUTO.history;for(const k of ['candidates','wallets','signals'])d[k]=[...S[k].entries()];d.scoreHistory=S.scoreHistory;save();};
Object.assign(S.settings,d.settingsOverrides||{});
d.pendingOrders=d.pendingOrders||[];
const close=AUTO._close.bind(AUTO);AUTO._close=(...args)=>{close(...args);sync();};
AUTO.runCycle=async()=>{
 const open=AUTO.open();if(!open.length)return {checked:0};
 const prices=await DISCOVERY.refreshPricesFor([...new Set(open.map(p=>p.mint))]);
 for(const p of open){const pr=prices[p.mint];if(!pr?.ok||!(pr.priceUsd>0)){p.priceState='UNAVAILABLE';continue;}
 p.lastPrice=pr.priceUsd;p.lastPriceAt=pr.observedAt;p.priceState='LIVE';p.lastLiquidityUsd=pr.liquidityUsd;
 const ex=exitReason(p,pr);if(ex)AUTO._close(p,ex.rug?0:pr.priceUsd,ex.reason);
 }return {checked:open.length};
};
AUTO.refill=()=>0; // Never enter from an old frozen-price signal.
S.on('signal',g=>{
 if(d.pauseNewEntries||g.createdAt<=d.ruleChangeAt)return;
 if(d.pendingOrders.some(o=>o.mint===g.mint&&o.status==='PENDING')||AUTO.open().some(p=>p.mint===g.mint))return;
 const o={id:'limit_'+g.id,signalId:g.id,mint:g.mint,symbol:g.symbol,signalPrice:g.signalPriceUsd,limitPrice:g.signalPriceUsd*0.8,createdAt:g.createdAt,expiresAt:g.createdAt+60*60000,status:'PENDING',score:g.score,signalLiquidity:g.evidence.liquidityUsd};d.pendingOrders.push(o);
 AUTO.history.push({t:Date.now(),type:'LIMIT_PLACED',mint:o.mint,symbol:o.symbol,price:o.limitPrice,signalPrice:o.signalPrice,usd:policy.entrySizeUsd,reason:'entry-open-v4: -20% limit, expires in 60 minutes; no cash/slot consumed'});sync();
});
function tightened(c){return qualify(c,Date.now()).eligible;}
function cancel(o,reason){o.status='CANCELLED';o.cancelledAt=Date.now();o.cancelReason=reason;AUTO.history.push({t:Date.now(),type:'LIMIT_CANCELLED',mint:o.mint,symbol:o.symbol,price:o.limitPrice,reason});sync();}
(async()=>{
 const monitoring=await AUTO.runCycle();
 const discovery=await DISCOVERY.runCycle();let analyzed=0,newCandidateChecks=0,pendingChecks=0;
 const all=[...S.candidates.values()];const offset=(d.analysisCursor||0)%Math.max(1,all.length);const rotated=all.slice(offset).concat(all.slice(0,offset));
 const pendingMints=new Set(d.pendingOrders.filter(o=>o.status==='PENDING').map(o=>o.mint));
 const queue=[...rotated.filter(c=>pendingMints.has(c.mint)),...rotated.filter(c=>!pendingMints.has(c.mint))];
 for(const c of queue){
  if(Date.now()-started>80000)break;
  const isPending=pendingMints.has(c.mint);
  if(!isPending&&newCandidateChecks>=6)continue;
  if(isPending)pendingChecks++;else newCandidateChecks++;
  // All candidates may form a NEW post-override market observation signal.
  // Entry risk screens removed by user; risk/wallet caches are informational only.
  // Five-minute wake cadence exceeds the app's 30-second freshness gate.
  // Refresh market evidence before detecting a signal.
  try{await DISCOVERY.refreshCandidate(c.mint);}catch(e){c.lastError=e.message;c.fieldMeta.market={source:'dexscreener',observedAt:Date.now(),status:'ERROR'};c.state='DATA_INCOMPLETE';analyzed++;sync();continue;}
  // No risk result is an entry gate.
  // Detect new source-backed observation transitions without investment screens.
  const priorActive=!!c.v2QualificationActive;const oldId=c.signalId;
  // Expose scorer independently below; no invented wallet or risk evidence.
  // Score is optional cached context, never a gate.
  const gate=qualify(c,Date.now());const eligible=gate.eligible;
  if(!eligible){c.v2QualificationActive=false;c.wasQualifiedBeforeRuleChange=false;c.state='DATA_INCOMPLETE';}
  else if(!priorActive){
   const now=Date.now();const sig={id:'sig_open_'+now.toString(36)+'_'+Math.random().toString(36).slice(2,8),mint:c.mint,symbol:c.market.symbol,name:c.market.name,createdAt:now,signalPriceUsd:c.market.priceUsd,signalPriceAt:c.market.observedAt,score:c.score?.total??null,policyVersion:policy.version,evidence:{liquidityUsd:c.market.liquidityUsd,pairAddress:c.market.pairAddress,dexId:c.market.dexId},state:'PAPER_SIGNAL',consumed:false,paperOnly:true};
   S.signals.set(sig.id,sig);c.signalId=sig.id;c.state='PAPER_SIGNAL';c.v2QualificationActive=true;S.emit('signal',sig);
  }
  else {c.state='PAPER_SIGNAL';c.signalId=oldId;}
  const order=d.pendingOrders.find(o=>o.mint===c.mint&&o.status==='PENDING');
  if(order){
   if(Date.now()>=order.expiresAt)cancel(order,'60-minute signal expiry');
   else if(!eligible&&gate.state==='FAIL')cancel(order,'current tightened qualification failed');
   else if(eligible&&order.createdAt<started&&fillGate(order,c,Date.now())&&c.market.priceUsd>0&&c.market.priceUsd<=order.limitPrice&&AUTO.open().length<policy.maxPositions&&AUTO.cash()>=AUTO.cost()){
    const fill={...S.signals.get(order.signalId),signalPriceUsd:c.market.priceUsd,evidence:{liquidityUsd:c.market.liquidityUsd}};
    const r=AUTO.onSignal(fill);if(r.ok){order.status='FILLED';order.filledAt=Date.now();order.fillPrice=c.market.priceUsd;order.positionId=r.pos.id;r.pos.rulesVersion=policy.version;r.pos.rules='PAPER ONLY: TP 1.5x; SL -25%; defensive liquidity exit -30%; full-loss rug >=90% or <=$500; no time limit';r.pos.limitOrderId=order.id;r.pos.signalReferencePrice=order.signalPrice;r.pos.limitPrice=order.limitPrice;AUTO.history[AUTO.history.length-1].reason='limit fill at later real check price <= -20% signal limit';sync();}
   }
  }
  analyzed++;sync();
 }
 d.v2ScansCompleted=(d.v2ScansCompleted||0)+1;d.analysisCursor=offset+newCandidateChecks;for(const o of d.pendingOrders.filter(o=>o.status==='PENDING'))if(Date.now()>=o.expiresAt)cancel(o,'60-minute signal expiry');
 d.lastCycle={startedAt:new Date(started).toISOString(),completedAt:new Date().toISOString(),discovery,analyzed,pendingChecks,newCandidateChecks,monitoring,sources:REG.all(),states:[...S.candidates.values()].reduce((a,c)=>(a[c.state]=(a[c.state]||0)+1,a),{})};sync();
 const result={cash:d.cash,stats:AUTO.stats(),events:AUTO.history.slice(before),positions:d.positions,pendingOrders:d.pendingOrders,lastCycle:d.lastCycle};fs.writeFileSync(dir+'/last-result.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
})().catch(e=>{d.lastError={at:new Date().toISOString(),error:String(e)};sync();console.error(e);process.exitCode=1;});
