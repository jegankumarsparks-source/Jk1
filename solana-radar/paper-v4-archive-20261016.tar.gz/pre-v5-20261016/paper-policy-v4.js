// User-requested unscreened paper entries. Not a profit model.
const policy={version:'entry-open-v4',entrySizeUsd:10,maxPositions:4,riskMaxAgeMs:300000,minConfirmMs:0,stopMultiplier:.75,tpMultiplier:1.5,liquidityExitDropPct:30};
function qualify(c,now){
 const m=c.market;
 const ok=!!(c.mint&&m&&m.pairAddress&&m.dexId&&m.source==='dexscreener'&&Number.isFinite(m.priceUsd)&&m.priceUsd>0&&Number.isFinite(m.liquidityUsd)&&m.liquidityUsd>=0&&Number.isFinite(m.observedAt)&&now>=m.observedAt&&now-m.observedAt<30000&&c.fieldMeta?.market?.status==='LIVE');
 return {eligible:ok,state:ok?'PASS':'UNKNOWN',reason:ok?'user override: no entry risk/score screens; real identity and fresh price/liquidity evidence only':'missing identity or fresh market evidence'};
}
function fillGate(order,c,now){return now>order.createdAt&&c.market.priceUsd<=order.limitPrice;}
function exitReason(p,pr){
 const drop=p.entryLiquidity&&Number.isFinite(pr.liquidityUsd)?100*(1-pr.liquidityUsd/p.entryLiquidity):null;
 if(drop!==null&&(pr.liquidityUsd<=500||drop>=90))return {rug:true,reason:'RUG PULL - liquidity collapsed; >=90% drop or <=$500. Full position lost.'};
 if(drop!==null&&drop>=policy.liquidityExitDropPct)return {rug:false,reason:'DEFENSIVE_LIQUIDITY - observed liquidity drop '+drop.toFixed(2)+'% >=30%; actual observed-price paper exit'};
 const x=pr.priceUsd/p.entryRate;
 if(x>=policy.tpMultiplier)return {rug:false,reason:'TP - observed '+x.toFixed(4)+'x >=1.5x'};
 if(x<=policy.stopMultiplier)return {rug:false,reason:'SL - observed '+((x-1)*100).toFixed(2)+'% <=-25%'};
 return null;
}
module.exports={policy,qualify,fillGate,exitReason};
