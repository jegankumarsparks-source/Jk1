// User-requested unscreened paper entries. Not a profit model.
const policy={version:'rug-only-v5',entrySizeUsd:10,maxPositions:50,riskMaxAgeMs:300000,minConfirmMs:0,stopMultiplier:null,tpMultiplier:2,liquidityExitDropPct:null};
function qualify(c,now){
 const m=c.market;
 const ok=!!(c.mint&&m&&m.pairAddress&&m.dexId&&m.source==='dexscreener'&&Number.isFinite(m.priceUsd)&&m.priceUsd>0&&Number.isFinite(m.liquidityUsd)&&m.liquidityUsd>=0&&Number.isFinite(m.observedAt)&&now>=m.observedAt&&now-m.observedAt<30000&&c.fieldMeta?.market?.status==='LIVE');
 return {eligible:ok,state:ok?'PASS':'UNKNOWN',reason:ok?'user override: no entry risk/score screens; real identity and fresh price/liquidity evidence only':'missing identity or fresh market evidence'};
}
function fillGate(order,c,now){return qualify(c,now).eligible;}
function exitReason(p,pr){
 const liq=pr.liquidityUsd;
 if(!Number.isFinite(liq))return null;
 const drop=p.entryLiquidity>0?100*(1-liq/p.entryLiquidity):null;
 if(liq<=500||(drop!==null&&drop>=90))return {rug:true,reason:'RUG PULL - liquidity collapsed; >=90% drop or <=$500. Full position lost.'};
 const x=pr.priceUsd/p.entryRate;
 if(x>=2)return {rug:false,reason:'TP - observed '+x.toFixed(4)+'x >=2x'};
 return null;
}
module.exports={policy,qualify,fillGate,exitReason};
