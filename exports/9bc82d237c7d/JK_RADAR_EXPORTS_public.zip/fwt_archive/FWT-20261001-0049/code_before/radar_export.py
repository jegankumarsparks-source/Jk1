#!/usr/bin/env python3
"""DASHBOARD COMMAND CENTER exporter (his spec 14:28 + always-live 14:31).
READ-ONLY over radar.db + paper/wallet state. Publishes JSON snapshots +
center.html to GitHub Pages (Jk1) via Contents API. Token stays server-side.
Honest data only: real fields, N/A handled client-side, no fabrication.
Additive file - touches no engine code, thresholds, or paper rules."""
import json, os, sqlite3, time, urllib.request, base64, hashlib

ROOT = "/tmp/pumpwatch/radar"
DB = os.path.join(ROOT, "radar.db")
TOKEN = open("/tmp/pumpwatch/pumptrack/github_token.txt").read().strip()
REPO = "jegankumarsparks-source/Jk1"
SHA_CACHE = os.path.join(ROOT, ".export_sha.json")
BLOCKED = ("CKKPTC", "9aztCh", "9pDrz7")

def _conn():
    c = sqlite3.connect(DB, timeout=30)
    c.execute("PRAGMA busy_timeout=30000")
    c.row_factory = sqlite3.Row
    return c

def _iso(ts):
    if ts is None: return None
    try:
        if isinstance(ts, (int, float)): return time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime(float(ts)))
        return str(ts)
    except Exception: return None

def _age_s(ts):
    try: return round(time.time() - float(ts))
    except Exception: return None

def gather():
    c = _conn()
    now = time.time()
    day0 = now - 86400

    # --- funnel + counters ---
    fun = c.execute("SELECT * FROM funnel ORDER BY ts DESC LIMIT 1").fetchone()
    fun24 = c.execute("""SELECT sum(discovered) d, sum(filtered) f, sum(scored) s, sum(signals) sig
                         FROM funnel WHERE ts >= ?""", (day0,)).fetchone()
    outcomes = c.execute("SELECT * FROM wallet_radar_outcomes").fetchall()
    cands = c.execute("SELECT * FROM wallet_radar_candidates").fetchall()
    tokens = {r["mint"]: dict(r) for r in c.execute("SELECT * FROM tokens")}
    snaps = {}
    for r in c.execute("""SELECT s.* FROM snapshots s JOIN (SELECT mint, max(ts) mts FROM snapshots GROUP BY mint) q
                          ON s.mint=q.mint AND s.ts=q.mts"""):
        snaps[r["mint"]] = dict(r)
    ev_by_mint, ev_by_wallet = {}, {}
    for r in c.execute("SELECT * FROM wallet_events ORDER BY event_time DESC LIMIT 4000"):
        d = dict(r)
        ev_by_mint.setdefault(d["token_address"], []).append(d)
        ev_by_wallet.setdefault(d["wallet_address"], []).append(d)
    risk = c.execute("SELECT count(*) n FROM risk_events WHERE ts >= ?", (day0,)).fetchone()["n"] \
        if c.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='risk_events'").fetchone()[0] else 0
    tg_last = c.execute("SELECT * FROM tg_delivery ORDER BY ts DESC LIMIT 1").fetchone()
    tg_last_buy = c.execute("SELECT * FROM tg_delivery WHERE ok=1 AND (kind LIKE '%buy%' OR kind LIKE '%signal%') ORDER BY ts DESC LIMIT 1").fetchone()
    tg_err24 = c.execute("SELECT count(*) n FROM tg_delivery WHERE ok=0 AND ts >= ?", (day0,)).fetchone()["n"]
    tg_ok24 = c.execute("SELECT count(*) n FROM tg_delivery WHERE ok=1 AND ts >= ?", (day0,)).fetchone()["n"]
    wallets = {r["wallet_address"]: dict(r) for r in c.execute("SELECT * FROM wallets")}
    trades_by_wallet = {}
    for r in c.execute("SELECT * FROM wallet_trades ORDER BY entry_time DESC LIMIT 8000"):
        trades_by_wallet.setdefault(r["wallet_address"], []).append(dict(r))
    pairs = {}
    for r in c.execute("SELECT * FROM wallet_pairs"):
        pairs.setdefault(r["wallet_a"], []).append((r["wallet_b"], r["cluster_score"]))
        pairs.setdefault(r["wallet_b"], []).append((r["wallet_a"], r["cluster_score"]))
    lowconf_n = 0
    try: lowconf_n = sum(1 for _ in open(os.path.join(ROOT, "low_confidence_events.jsonl")))
    except Exception: pass
    c.close()

    # --- paper books ---
    def _book(path_state, path_ledger):
        try: st = json.load(open(path_state))
        except Exception: return None
        led = []
        try:
            for ln in open(path_ledger):
                try: led.append(json.loads(ln))
                except Exception: pass
        except Exception: pass
        pos = []
        for mint, p in (st.get("positions") or {}).items():
            t = tokens.get(mint) or {}
            sn = snaps.get(mint) or {}
            pos.append({"mint": mint, "sym": p.get("sym") or t.get("sym") or mint[:6],
                        "entry": p.get("entry"), "entry_time": _iso(p.get("entry_time")),
                        "last_mult": p.get("last_mult"), "max_mult": p.get("max_mult"),
                        "cur": (p.get("entry") or 0) * (p.get("last_mult") or 1.0),
                        "liq": sn.get("liq"), "mc": sn.get("mc"),
                        "tier": p.get("tier"), "kind": p.get("kind"),
                        "wallet_score": p.get("wallet_score"), "independent_count": p.get("independent_count")})
        closed = [dict(x, entry_time=_iso(x.get("entry_time")), exit_time=_iso(x.get("exit_time"))) for x in (st.get("closed") or [])[-50:]]
        open_val = sum(20 * (p.get("last_mult") or 1.0) for p in (st.get("positions") or {}).values())
        realised = sum(x.get("pnl", 0) for x in (st.get("closed") or []))
        unreal = sum(20 * ((p.get("last_mult") or 1.0) - 1) for p in (st.get("positions") or {}).values())
        return {"cash": st.get("cash"), "start": st.get("start", 500), "equity": (st.get("cash") or 0) + open_val,
                "realised": realised, "unrealised": unreal, "open": pos, "closed": closed,
                "n_tp": sum(1 for x in (st.get("closed") or []) if str(x.get("stage","")).endswith("TP")),
                "n_sl": sum(1 for x in (st.get("closed") or []) if str(x.get("stage","")).endswith("SL")),
                "n_rug": sum(1 for x in (st.get("closed") or []) if str(x.get("stage","")).endswith("RUG"))}

    main_book = _book(os.path.join(ROOT, "paper_state.json"), os.path.join(ROOT, "paper_ledger.jsonl"))
    color_books = {col: _book(os.path.join(ROOT, f"wallet_{col}_state.json"), os.path.join(ROOT, f"wallet_{col}_ledger.jsonl"))
                   for col in ("green", "yellow", "red", "blue")}
    try: race = json.load(open(os.path.join(ROOT, "wallet_race_state.json")))
    except Exception: race = None
    try: wr_state = json.load(open(os.path.join(ROOT, "wallet_radar_state.json")))
    except Exception: wr_state = {}
    pre_set = {m for m, ts in (wr_state.get("preentry") or {}).items()
               if now - float(ts) <= 21600 and not m.startswith(BLOCKED)}
    if race: race["history"] = race.get("history", [])[-60:]

    # --- binance listing (server-side check; honest flag) ---
    try:
        import radar_data as data
        binance_syms = {t.get("sym") for t in tokens.values() if t.get("sym") and data.binance_listed(t["sym"])}
    except Exception: binance_syms = set()

    # --- token detail builder ---
    cand_by_mint = {r["mint"]: dict(r) for r in cands}
    out_by_mint = {r["mint"]: dict(r) for r in outcomes}
    def token_detail(mint):
        t = tokens.get(mint) or {}
        sn = snaps.get(mint) or {}
        cd = cand_by_mint.get(mint) or {}
        oc = out_by_mint.get(mint) or {}
        evs = [e for e in ev_by_mint.get(mint, []) if not str(e["wallet_address"]).startswith(BLOCKED)]
        sym = cd.get("sym") or t.get("sym") or mint[:6]
        det = None
        try: det = json.loads(cd.get("detail_json") or "{}")
        except Exception: det = {}
        first_ev = evs[-1]["event_time"] if evs else None
        latest_ev = evs[0]["event_time"] if evs else None
        paper_pos = []
        if main_book:
            for p in main_book["open"]:
                if p["mint"] == mint: paper_pos.append(dict(p, book="MAIN"))
            for x in main_book["closed"]:
                if x.get("mint") == mint: paper_pos.append({"mint": mint, "sym": sym, "book": "MAIN", "stage": x.get("stage"),
                        "entry": x.get("entry"), "exit_mult": x.get("exit_mult"), "pnl": x.get("pnl"),
                        "entry_time": x.get("entry_time"), "exit_time": x.get("exit_time")})
        for col, bk in color_books.items():
            if not bk: continue
            for p in bk["open"]:
                if p["mint"] == mint: paper_pos.append(dict(p, book=col.upper()))
            for x in bk["closed"]:
                if x.get("mint") == mint: paper_pos.append({"mint": mint, "sym": sym, "book": col.upper(), "stage": x.get("stage"),
                        "entry": x.get("entry"), "exit_mult": x.get("exit_mult"), "pnl": x.get("pnl"),
                        "entry_time": x.get("entry_time"), "exit_time": x.get("exit_time")})
        b5, s5 = sn.get("b5m"), sn.get("s5m")
        b1, s1 = sn.get("b1h"), sn.get("s1h")
        ratio = None
        try: ratio = round((b1 or 0) / max(1, (b1 or 0) + (s1 or 0)), 3)
        except Exception: pass
        return {
            "mint": mint, "sym": sym, "name": t.get("name"), "binance": sym in binance_syms,
            "pair": t.get("pair"), "dex": t.get("dex"),
            "age_s": _age_s(t.get("pair_created")) if t.get("pair_created") else None,
            "first_seen": _iso(t.get("first_seen")), "last_update": _iso(sn.get("ts")),
            "status": cd.get("status") or ("OUTCOME" if oc else ("PAPER" if paper_pos else "TRACKED")),
            "market": {"price": sn.get("price"), "mc": sn.get("mc"), "liq": sn.get("liq"),
                       "v5m": sn.get("v5m"), "v1h": sn.get("v1h"), "v6h": sn.get("v6h"), "v24h": sn.get("v24h"),
                       "b5m": b5, "s5m": s5, "b1h": b1, "s1h": s1, "buy_ratio_1h": ratio,
                       "pc5m": sn.get("pc5m"), "pc1h": sn.get("pc1h"), "pc6h": sn.get("pc6h"), "pc24h": sn.get("pc24h"),
                       "holders": sn.get("holders"), "top10": sn.get("top10")},
            "wallet_intel": {"n_events": len(evs),
                             "wallet_count": cd.get("wallet_count"), "qualified_count": cd.get("qualified_count"),
                             "independent_count": cd.get("independent_count"), "related_count": cd.get("related_count"),
                             "best_wallet_score": cd.get("best_wallet_score"), "cluster_score": cd.get("cluster_score"),
                             "first_entry": cd.get("first_entry") or first_ev, "latest_entry": cd.get("latest_entry") or latest_ev,
                             "freshness": cd.get("freshness"),
                             "wallets": [{"w": e["wallet_address"], "score": e.get("wallet_score"),
                                          "time": e.get("event_time"), "usd": e.get("entry_position_usd")} for e in evs[:15]],
                             "score_components": det.get("components")},
            "outcome": {"signal_time": oc.get("signal_time"), "entry_price": oc.get("entry_price"),
                        "entry_mc": oc.get("entry_mc"), "entry_liq": oc.get("entry_liq"),
                        "max_multiple": oc.get("max_multiple"), "max_observed_at": oc.get("max_observed_at"),
                        "time_to_peak_s": oc.get("time_to_peak_s"), "max_drawdown": oc.get("max_drawdown"),
                        "reached_1_5x": oc.get("reached_1_5x"), "reached_2x": oc.get("reached_2x"),
                        "reached_3x": oc.get("reached_3x"), "reached_5x": oc.get("reached_5x"),
                        "reached_1_5x_at": oc.get("reached_1_5x_at"), "reached_2x_at": oc.get("reached_2x_at"),
                        "reached_3x_at": oc.get("reached_3x_at"), "reached_5x_at": oc.get("reached_5x_at"),
                        "rank_score": oc.get("rank_score")} if oc else None,
            "rank_score": cd.get("rank_score"), "paper": paper_pos,
        }

    all_mints = sorted(set(list(tokens.keys()) + list(cand_by_mint.keys()) + list(out_by_mint.keys())))
    all_mints = [m for m in all_mints if not m.startswith(BLOCKED)]
    details = {m: token_detail(m) for m in all_mints}

    # --- wallet detail builder ---
    def wallet_detail(addr):
        w = wallets.get(addr) or {}
        evs = [e for e in ev_by_wallet.get(addr, [])][:20]
        trs = trades_by_wallet.get(addr, [])[:30]
        rel = sorted(pairs.get(addr, []), key=lambda x: -(x[1] or 0))[:8]
        return {"address": addr, "score": w.get("smart_wallet_score"), "classification": w.get("classification"),
                "first_seen": w.get("first_seen"), "last_active": w.get("last_active"),
                "total_trades": w.get("total_trades_tracked"), "tokens_traded": w.get("total_tokens_traded"),
                "early_entries": w.get("early_entries"), "successful_early": w.get("successful_early_entries"),
                "max_multiple": w.get("maximum_multiple_observed"), "avg_max_multiple": w.get("average_max_multiple"),
                "median_max_multiple": w.get("median_max_multiple"), "win_rate": w.get("win_rate"),
                "profitable": w.get("profitable_trade_count"), "loss": w.get("loss_trade_count"),
                "rug_exposure": w.get("rug_exposure"), "risk_score": w.get("risk_score_w"),
                "early_entry_score": w.get("early_entry_score"), "consistency": w.get("consistency_score"),
                "act_24h": w.get("last_24h_activity"), "act_7d": w.get("last_7d_activity"),
                "open_positions": w.get("current_active_positions"),
                "recent_events": [{"mint": e["token_address"], "sym": (tokens.get(e["token_address"]) or {}).get("sym"),
                                   "time": e.get("event_time"), "usd": e.get("entry_position_usd")} for e in evs],
                "recent_trades": [{"mint": t["token_address"], "sym": (tokens.get(t["token_address"]) or {}).get("sym"),
                                   "entry_time": t.get("entry_time"), "entry_mc": t.get("entry_market_cap"),
                                   "max_multiple": t.get("max_multiple"), "outcome": t.get("outcome"),
                                   "early": t.get("is_early_entry")} for t in trs],
                "related": [{"w": a, "cluster_score": s} for a, s in rel]}

    cand_wallets = set()
    for cd in cand_by_mint.values():
        try:
            for x in json.loads(cd.get("detail_json") or "{}").get("wallets", []):
                cand_wallets.add(x.get("w"))
        except Exception: pass
    event_wallets = set(ev_by_wallet.keys())
    top_scored = sorted((a for a, w in wallets.items() if w.get("smart_wallet_score")),
                        key=lambda a: -wallets[a]["smart_wallet_score"])[:120]
    wallet_set = [a for a in dict.fromkeys(list(event_wallets) + [a for a in top_scored] ) if a and not str(a).startswith(BLOCKED)]
    wallet_set = wallet_set[:250]
    wdetails = {a: wallet_detail(a) for a in wallet_set}

    summary = {
        "publish_time": _iso(now), "ts": now,
        "funnel": dict(fun) if fun else None,
        "funnel_24h": {"discovered": fun24["d"], "filtered": fun24["f"], "scored": fun24["s"], "signals": fun24["sig"]},
        "counters": {
            "discovered": (fun24["d"] or 0), "scanned": (fun24["f"] or 0), "scored": (fun24["s"] or 0),
            "watch_candidates": len(cands), "pre_entry": len(pre_set),
            "signals_today": (fun24["sig"] or 0), "outcomes": len(outcomes),
            "2x": sum(1 for r in outcomes if r["reached_2x"]), "3x": sum(1 for r in outcomes if r["reached_3x"]),
            "5x": sum(1 for r in outcomes if r["reached_5x"]),
            "10x": sum(1 for r in outcomes if (r["max_multiple"] or 0) >= 10),
            "risk_alerts": risk, "wallets_tracked": len(wallets), "low_conf": lowconf_n,
            "buy_detected_24h": sum(len(v) for v in ev_by_mint.values()),
            "convergence": sum(1 for r in cands if (r["independent_count"] or 0) >= 2),
            "tokens_tracked": len(all_mints),
        },
        "race": {"state": race.get("state"), "winner": race.get("winner"), "win_reason": race.get("win_reason"),
                 "decided_at": race.get("decided_at"), "target_pnl": race.get("target_pnl"), "window_h": race.get("window_h"),
                 "leader": race.get("last_leader")} if race else None,
        "main": {"equity": main_book["equity"], "cash": main_book["cash"], "realised": main_book["realised"],
                 "unrealised": main_book["unrealised"], "n_open": len(main_book["open"]),
                 "n_tp": main_book["n_tp"], "n_sl": main_book["n_sl"], "n_rug": main_book["n_rug"]} if main_book else None,
        "color": {col.upper(): {"equity": bk["equity"], "n_open": len(bk["open"]),
                                "net_pnl": round(bk["realised"] + bk["unrealised"], 2)} if bk else None
                  for col, bk in color_books.items()},
        "telegram": {"online": bool(tg_ok24), "last_delivery": _iso(tg_last["ts"]) if tg_last else None,
                     "last_kind": tg_last["kind"] if tg_last else None,
                     "last_buy_alert": _iso(tg_last_buy["ts"]) if tg_last_buy else None,
                     "ok_24h": tg_ok24, "errors_24h": tg_err24},
    }
    try:
        _us = json.load(open("/tmp/pumpwatch/radar/user_settings.json"))
    except Exception:
        _us = {}
    _watch = _us.get("watch") or []
    settings = {"watched_count": len(_watch),
                "watched_masked": [f"{w[:6]}...{w[-4:]}" for w in _watch],
                "interval_min": _us.get("interval_min", 2),
                "alerts": bool(_us.get("alerts", True))}
    status = {"publish_time": summary["publish_time"], "ts": summary["ts"], "telegram": summary["telegram"],
              "race": summary["race"], "main_equity": (main_book or {}).get("equity"),
              "signals_today": summary["counters"]["signals_today"], "settings": settings}
    return summary, status, details, wdetails, main_book, color_books, race, pre_set

def _put(path, content_bytes, sha_cache):
    """PUT one file via Contents API; skip when unchanged (sha compare)."""
    h = hashlib.sha1(("blob %d\0" % len(content_bytes)).encode() + content_bytes).hexdigest()
    if sha_cache.get(path) == h: return "same"
    url = f"https://api.github.com/repos/{REPO}/contents/{path}"
    body = {"message": f"radar export {time.strftime('%H:%M')}", "content": base64.b64encode(content_bytes).decode()}
    if path in sha_cache:  # need current sha for update; fetch
        g = urllib.request.Request(url, headers={"Authorization": f"token {TOKEN}", "Accept": "application/vnd.github+json"})
        try:
            cur = json.load(urllib.request.urlopen(g, timeout=20)); body["sha"] = cur["sha"]
        except Exception: pass
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="PUT",
        headers={"Authorization": f"token {TOKEN}", "Accept": "application/vnd.github+json", "Content-Type": "application/json"})
    json.load(urllib.request.urlopen(req, timeout=30))
    sha_cache[path] = h
    return "put"

def export(push=True):
    summary, status, details, wdetails, main_book, color_books, race, pre_set = gather()
    files = {"data/status.json": status, "data/summary.json": summary}
    # token index + chunks
    tindex = {}
    mints = sorted(details.keys())
    for i in range(0, len(mints), 25):
        chunk = i // 25
        files[f"data/tc_{chunk}.json"] = {m: details[m] for m in mints[i:i+25]}
        for m in mints[i:i+25]:
            d = details[m]
            tindex[m] = {"c": chunk, "sym": d["sym"], "mc": d["market"].get("mc"), "liq": d["market"].get("liq"),
                         "mult": (d["outcome"] or {}).get("max_multiple"), "rank": d.get("rank_score"),
                         "status": d["status"], "indep": d["wallet_intel"].get("independent_count"),
                         "best_score": d["wallet_intel"].get("best_wallet_score"),
                         "v1h": d["market"].get("v1h"), "age_s": d.get("age_s"),
                         "paper": bool(d["paper"]), "binance": d["binance"], "pe": m in pre_set,
                         "first_seen": d.get("first_seen"), "last_update": d.get("last_update")}
    files["data/tokens.json"] = tindex
    windex = {}
    addrs = sorted(wdetails.keys())
    for i in range(0, len(addrs), 25):
        chunk = i // 25
        files[f"data/wc_{chunk}.json"] = {a: wdetails[a] for a in addrs[i:i+25]}
        for a in addrs[i:i+25]:
            w = wdetails[a]
            windex[a] = {"c": chunk, "score": w.get("score"), "classification": w.get("classification"),
                         "win_rate": w.get("win_rate"), "max_multiple": w.get("max_multiple"),
                         "act_24h": w.get("act_24h"), "trades": w.get("total_trades")}
    files["data/wallets.json"] = windex
    # --- LIVE SIGNALS export (Phase 4) ---
    try:
        import sqlite3 as _sq
        _sc = _sq.connect(os.path.join(ROOT, "radar.db")); _sc.row_factory = _sq.Row
        sig_feed = []
        for r in _sc.execute("SELECT * FROM sig_signals ORDER BY updated_at DESC LIMIT 40"):
            fj = json.loads(r["factors_json"] or "{}")
            sig_feed.append({
                "sig_id": r["sig_id"], "mint": r["mint"], "sym": r["sym"], "state": r["state"],
                "score": r["score"], "blocked_reason": r["blocked_reason"],
                "created_at": r["created_at"], "updated_at": r["updated_at"],
                "why": (fj.get("why") or [])[:3], "risks": (fj.get("risks") or [])[:2],
                "market": fj.get("market") or {},
                "factors": {kk: (fj.get("factors") or {}).get(kk) for kk in
                            ("large_buys", "large_sells", "unique_buyers", "smart_count", "net",
                             "buy_usd", "sell_usd", "buy_accel", "vol_accel", "repeat_buyers",
                             "data_age_s", "source")}})
            evs = [{"ts": e["ts"], "kind": e["kind"], "detail": e["detail"]}
                   for e in _sc.execute("SELECT ts,kind,detail FROM sig_events WHERE sig_id=? ORDER BY ts DESC LIMIT 20", (r["sig_id"],))]
            files[f"data/sig_{r['sig_id']}.json"] = {"signal": sig_feed[-1], "components": fj.get("components") or {},
                                                     "factors_full": fj.get("factors") or {}, "why": fj.get("why") or [],
                                                     "risks": fj.get("risks") or [], "events": evs}
        _sc.close()
        # V2 comparison data (Phase 7 - debug/admin fields only, production untouched)
        try:
            _sc2 = sqlite3.connect(os.path.join(ROOT, "radar.db")); _sc2.row_factory = sqlite3.Row
            _v2 = {}
            for r in _sc2.execute("""SELECT sig_id, score_v2, components_json, why_json, quality_gate
                FROM sig_scores_v2 WHERE (sig_id, ts) IN (SELECT sig_id, MAX(ts) FROM sig_scores_v2 GROUP BY sig_id)"""):
                _v2[r["sig_id"]] = {"score_v2": r["score_v2"], "components": json.loads(r["components_json"] or "{}"),
                                    "why": json.loads(r["why_json"] or "{}"), "gate": r["quality_gate"]}
            for r in _sc2.execute("""SELECT mint, n_wallets, total_usd, avg_quality FROM sig_clusters
                WHERE (mint, detected_at) IN (SELECT mint, MAX(detected_at) FROM sig_clusters GROUP BY mint)"""):
                for s in sig_feed:
                    if s["mint"] == r["mint"]:
                        _v2.setdefault(s["sig_id"], {})["cluster"] = {"n": r["n_wallets"], "usd": r["total_usd"], "avg_q": r["avg_quality"]}
            _sc2.close()
            files["data/sig_v2.json"] = {"publish_time": status["publish_time"], "v2": _v2}
        except Exception as _e:
            print("sig v2 export fail", str(_e)[:120])
            files["data/sig_v2.json"] = {"publish_time": status["publish_time"], "v2": {}}
        files["data/sig_feed.json"] = {"publish_time": status["publish_time"], "signals": sig_feed}
        try:
            files["data/sig_health.json"] = json.load(open(os.path.join(ROOT, "sig_health.json")))
        except Exception:
            files["data/sig_health.json"] = {"components": {}, "updated_at": 0}
    except Exception as _e:
        print("sig export fail", str(_e)[:120])
        files["data/sig_feed.json"] = {"publish_time": status["publish_time"], "signals": []}
    try:
        files["data/fwtest.json"] = json.load(open(os.path.join(ROOT, "fwtest.json")))
    except Exception:
        files["data/fwtest.json"] = {"publish_time": status["publish_time"], "error": "UNAVAILABLE"}
    files["data/paper.json"] = {"publish_time": status["publish_time"], "MAIN": main_book,
                                "wallets": {k.upper(): v for k, v in color_books.items()}, "race": race}
    # Outcome Layer: read-only paper/shadow analytics, separate from LIVE SIGNALS.
    try:
        import outcome_layer
        files["data/performance.json"] = outcome_layer.build()
    except Exception as _e:
        print("performance export fail", str(_e)[:160])
        files["data/performance.json"] = {"mode":"PAPER / SHADOW ANALYTICS - NOT REAL MONEY", "error":"UNAVAILABLE"}
    # frontend app itself (raw bytes, not JSON)
    try:
        files["center.html"] = open(os.path.join(ROOT, "center.html"), "rb").read()
    except Exception: pass
    results = {}
    if push:
        try: sha_cache = json.load(open(SHA_CACHE))
        except Exception: sha_cache = {}
        for path, obj in files.items():
            try:
                blob = obj if isinstance(obj, bytes) else json.dumps(obj, separators=(",", ":")).encode()
                results[path] = _put(path, blob, sha_cache)
            except Exception as e:
                results[path] = f"ERR {e}"
        json.dump(sha_cache, open(SHA_CACHE, "w"))
    return {p: results.get(p, "dry") for p in files}, summary["counters"]

if __name__ == "__main__":
    import sys
    res, counters = export(push=("--dry" not in sys.argv))
    puts = sum(1 for v in res.values() if v == "put")
    errs = {p: v for p, v in res.items() if str(v).startswith("ERR")}
    print(f"EXPORT: files={len(res)} pushed={puts} errors={len(errs)}")
    if errs: print("ERRORS:", errs)
