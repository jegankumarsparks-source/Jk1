#!/usr/bin/env python3
"""FIVE-WALLET FRESH PAPER TEST (PRIORITY #1 spec v3, his WA 00:52/00:54 via parent).
Shadow-only: independent $500 fresh ledgers mirroring NEW production entries.
Rules: $20/coin | max 12 open | TP +1.5x FULL | SL -50% FULL | RUG = -$20 | MAX HOLD 6h (5h review note).
Dynamic MAIN = top fresh-test equity (tiebreak: higher realized, then wallet name). No tuning/backfill. Production READ-ONLY."""
import json, os, sys, time, tempfile
from datetime import datetime, timezone

BASE = "/tmp/pumpwatch/radar"
STATE = f"{BASE}/fwtest_state.json"
LEDGER = f"{BASE}/fwtest_ledger.jsonl"
ARCHIVE = f"{BASE}/fwtest_archive.json"
WALLETS = ["MAIN", "GREEN", "YELLOW", "RED", "BLUE"]
SRC = {"MAIN": f"{BASE}/paper_state.json",
       "GREEN": f"{BASE}/wallet_green_state.json",
       "YELLOW": f"{BASE}/wallet_yellow_state.json",
       "RED": f"{BASE}/wallet_red_state.json",
       "BLUE": f"{BASE}/wallet_blue_state.json"}
START = 500.0; BET = 20.0; TP = 1.5; SL = 0.5; RUG = 0.1
MAX_OPEN = 12; MAX_HOLD_H = 6; REVIEW_H = 5
COHORT = "FWT-20261001-0049"

def load(p, d=None):
    try:
        with open(p) as f: return json.load(f)
    except Exception: return d

def save(d):
    fd, tmp = tempfile.mkstemp(dir=BASE, prefix=".fwtest")
    with os.fdopen(fd, "w") as f: json.dump(d, f)
    os.replace(tmp, STATE)

def iso_now(): return datetime.now(timezone.utc).isoformat()

def epoch(iso):
    try: return datetime.fromisoformat(iso).timestamp()
    except Exception: return time.time()

def ledger(rec):
    rec["recorded_at"] = iso_now(); rec["cohort"] = COHORT
    with open(LEDGER, "a") as f: f.write(json.dumps(rec) + "\n")

def fresh_wallet():
    return {"start_equity": START, "cash": START, "positions": {}, "closed": [],
            "skipped": [], "seen": [], "entries": 0, "peak_equity": START}

def init():
    st = load(STATE)
    if st:
        # upgrade to v3 spec fields
        st.setdefault("cohort", COHORT)
        st["rules"].update({"max_open": MAX_OPEN, "max_hold_h": MAX_HOLD_H, "review_h": REVIEW_H, "rug_loss": -BET})
        st.setdefault("main_metric", "top fresh-test equity (cash+open marks); tiebreak: higher realized P&L, then wallet name A-Z")
        for w in WALLETS: st["wallets"][w].setdefault("peak_equity", START)
        save(st)
        return st
    ts = iso_now()
    st = {"test": "FIVE-WALLET FRESH PAPER TEST", "cohort": COHORT,
          "rules": {"start": START, "bet": BET, "tp_mult": TP, "sl_mult": SL, "rug_mult": RUG,
                    "rug_loss": -BET, "max_open": MAX_OPEN, "max_hold_h": MAX_HOLD_H, "review_h": REVIEW_H},
          "main_metric": "top fresh-test equity (cash+open marks); tiebreak: higher realized P&L, then wallet name A-Z",
          "start_ts": ts, "start_epoch": time.time(), "window_h": 4,
          "wallets": {w: fresh_wallet() for w in WALLETS},
          "note": "5 wallets verified in production: main paper book (paper_state.json) + GREEN/YELLOW/RED/BLUE color books. SECOND wallet does not exist. Shadow-only; production read-only + LIVE; no backfill (only entries at/after start_ts)."}
    save(st)
    ledger({"type": "test_start", "ts": ts, "wallets": WALLETS, "rules": st["rules"], "cohort": COHORT})
    return st

def _close(tw, w, mint, stage, mult, pnl):
    p = tw["positions"].pop(mint)
    hold = time.time() - epoch(p.get("entry_time", iso_now()))
    rec = {"mint": mint, "sym": p.get("sym"), "stage": stage, "mult": round(mult, 4),
           "pnl": round(pnl, 4), "entry_time": p.get("entry_time"), "exit_ts": iso_now(),
           "hold_s": int(hold), "max_mult": round(p.get("max_mult") or 1.0, 4), "cohort": COHORT,
           "entry_price": p.get("entry"), "exit_reason": stage,
           "allocation_usd": BET, "exit_value": round(BET + pnl, 4),
           "exit_price": (round(p.get("entry") * mult, 12) if p.get("entry") is not None else None)}
    tw["closed"].append(rec)
    ledger({"type": "exit", "wallet": w, **rec})

def tick(st):
    for w in WALLETS:
        tw = st["wallets"][w]
        prod_pos = (load(SRC[w], {}) or {}).get("positions", {})
        for mint, p in prod_pos.items():
            et = p.get("entry_time", "")
            key = f"{mint}:{et}"
            if key in tw["seen"]: continue
            tw["seen"].append(key)
            if et < st["start_ts"]: continue  # no backfill
            if len(tw["positions"]) >= MAX_OPEN:
                tw["skipped"].append({"mint": mint, "sym": p.get("sym"), "reason": "max_open_12", "ts": iso_now()})
                ledger({"type": "skip", "wallet": w, "mint": mint, "sym": p.get("sym"), "reason": "max_open_12"})
                continue
            if tw["cash"] < BET:
                tw["skipped"].append({"mint": mint, "sym": p.get("sym"), "reason": "cash<20", "ts": iso_now()})
                ledger({"type": "skip", "wallet": w, "mint": mint, "sym": p.get("sym"), "reason": "cash<20"})
                continue
            tw["cash"] -= BET
            lm = p.get("last_mult") or 1.0
            tw["positions"][mint] = {"sym": p.get("sym"), "entry": p.get("entry"), "entry_time": et,
                                     "invested": BET, "last_mult": lm, "max_mult": lm,
                                     "entry_src_ts": et, "retrieval_ts": iso_now(), "lane": w, "cohort": COHORT}
            tw["entries"] += 1
            ledger({"type": "entry", "wallet": w, "mint": mint, "sym": p.get("sym"),
                    "entry_price": p.get("entry"), "entry_ts": et, "usd": BET, "allocation_usd": BET})
        for mint in list(tw["positions"].keys()):
            tp_ = tw["positions"][mint]
            pp = prod_pos.get(mint)
            if pp and pp.get("last_mult"):
                m = pp["last_mult"]
                tp_["last_mult"] = m
                tp_["max_mult"] = max(tp_.get("max_mult") or 1.0, m)
                tp_.pop("feed_lost", None)
            else:
                m = tp_.get("last_mult") or 1.0
                tp_["feed_lost"] = True
                # INTEGRITY LOGGING ONLY (approved): reference event, never an FWT exit, no accounting change
                if not tp_.get("prod_close"):
                    pcs = [c for c in (load(SRC[w], {}) or {}).get("closed", [])
                           if c.get("mint") == mint and c.get("entry") is not None and c.get("entry") == tp_.get("entry")]
                    if pcs:
                        c = pcs[-1]
                        ref = {"source": "PRODUCTION_CLOSE", "exit_reason": "PRODUCTION_CLOSE / " + str(c.get("stage")),
                               "production_exit_mult": c.get("exit_mult"), "production_pnl_ref": c.get("pnl"),
                               "production_exit_ts": None, "production_exit_ts_note": "NULL: production closed record carries no exit timestamp",
                               "recorded_at": iso_now(), "fwt_last_mark_before": round(tp_.get("last_mult") or 1.0, 4),
                               "not_fwt_execution": True}
                        tp_["prod_close"] = ref
                        ledger({"type": "production_close_reference", "wallet": w, "mint": mint, "sym": tp_.get("sym"),
                                "cohort": COHORT, "entry_price": tp_.get("entry"), "entry_ts": tp_.get("entry_time"),
                                "allocation_usd": BET, **ref})
            hold_h = (time.time() - epoch(tp_.get("entry_time", iso_now()))) / 3600
            if hold_h >= REVIEW_H and not tp_.get("review_5h"):
                tp_["review_5h"] = True
                ledger({"type": "review_5h", "wallet": w, "mint": mint, "sym": tp_.get("sym"),
                        "mult": round(m, 4), "decision": "hold to 6h (no early close - rotation permission not documented)"})
            if m >= TP:
                tw["cash"] += BET * TP
                _close(tw, w, mint, "TP_1.5X", TP, BET * (TP - 1))
            elif m <= RUG:
                _close(tw, w, mint, "RUG", m, -BET)
            elif m <= SL:
                tw["cash"] += BET * m
                _close(tw, w, mint, "STOP_-50", m, BET * (m - 1))
            elif hold_h >= MAX_HOLD_H:
                tw["cash"] += BET * m
                _close(tw, w, mint, "TIME_6H", m, BET * (m - 1))
        # peak equity tracking for drawdown
        a = accounting(tw)
        tw["peak_equity"] = max(tw.get("peak_equity") or START, a["equity"])
    save(st)
    write_public(st)

def accounting(tw):
    open_val = sum(BET * (p.get("last_mult") or 1.0) for p in tw["positions"].values())
    deployed = BET * len(tw["positions"])
    closed = tw["closed"]
    realized = sum(c["pnl"] for c in closed)
    equity = tw["cash"] + open_val
    wins = [c for c in closed if c["pnl"] > 0]
    losses = [c for c in closed if c["pnl"] < 0]
    gross_w = sum(c["pnl"] for c in wins); gross_l = abs(sum(c["pnl"] for c in losses))
    peak = tw.get("peak_equity") or START
    return {"equity": round(equity, 2), "cash": round(tw["cash"], 2), "deployed": round(deployed, 2),
            "realized": round(realized, 2), "unreal": round(open_val - deployed, 2),
            "entries": tw["entries"], "closed_n": len(closed), "wins": len(wins), "losses": len(losses),
            "rugs": sum(1 for c in closed if c["stage"] == "RUG"),
            "avg_win": round(gross_w / len(wins), 2) if wins else None,
            "avg_loss": round(-gross_l / len(losses), 2) if losses else None,
            "profit_factor": round(gross_w / gross_l, 2) if gross_l > 0 else None,
            "cur_dd": round((peak - equity) / peak * 100, 1),
            "best": max((c["pnl"] for c in closed), default=None),
            "worst": min((c["pnl"] for c in closed), default=None),
            "avg_hold_m": round(sum(c["hold_s"] for c in closed) / len(closed) / 60, 1) if closed else None,
            "max_hold_m": round(max((c["hold_s"] for c in closed), default=0) / 60, 1) if closed else None,
            "open": len(tw["positions"]), "skipped": len(tw["skipped"]),
            "net": round(equity - START, 2), "progress_pct": round((equity - START) / 100 * 100, 1)}

def ranks(st):
    order = sorted(WALLETS, key=lambda w: (-accounting(st["wallets"][w])["equity"],
                                           -accounting(st["wallets"][w])["realized"], w))
    return {w: i + 1 for i, w in enumerate(order)}

def block(st):
    el = int((time.time() - st["start_epoch"]) / 60)
    rk = ranks(st)
    leader = min(rk, key=rk.get)
    n_target = sum(1 for w in WALLETS if accounting(st["wallets"][w])["equity"] >= 600)
    lines = [f"FIVE-WALLET FRESH TEST | cohort {st.get('cohort')} | start {st['start_ts'][:19]}Z | elapsed {el}m | $500x5 | $20 TP1.5x SL-50% rug-$20 max12 6h | MAIN={leader} | overall {n_target}/5"]
    for w in WALLETS:
        a = accounting(st["wallets"][w])
        badge = " 👑MAIN" if w == leader else ""
        tgt = "TARGET REACHED" if a["equity"] >= 600 else "not yet"
        lines.append(f"#{rk[w]} {w}{badge}: eq ${a['equity']} (net {a['net']:+.2f}, {a['progress_pct']:+.1f}%) | cash {a['cash']} dep {a['deployed']} | R {a['realized']} U {a['unreal']} | open {a['open']}/12 closed {a['closed_n']} w{a['wins']} l{a['losses']} rug{a['rugs']} | DD {a['cur_dd']}% | $600: {tgt}")
    return "\n".join(lines)


def write_public(st):
    """Publish dashboard-shaped fwtest.json (actual test data only; None -> UNAVAILABLE on page)."""
    rk = ranks(st)
    leader = min(rk, key=rk.get)
    wl = []
    for w in WALLETS:
        a = accounting(st["wallets"][w])
        tw = st["wallets"][w]
        wl.append({"name": ("MAIN BOOK" if w == "MAIN" else w), "rank": rk[w], "is_main": w == leader, **a, "max_open": MAX_OPEN,
                   "target": "TARGET REACHED" if a["equity"] >= 600 else "IN PROGRESS",
                   "positions": [{"sym": p.get("sym"), "mult": round(p.get("last_mult") or 1.0, 3), "feed_lost": bool(p.get("feed_lost")), "prod_close": p.get("prod_close")} for p in tw["positions"].values()]})
    eq_total = round(sum(x["equity"] for x in wl), 2)
    doc = {"publish_time": iso_now(), "cohort": st.get("cohort"), "start_ts": st["start_ts"],
           "elapsed_m": int((time.time() - st["start_epoch"]) / 60), "rules": st["rules"],
           "main_metric": st.get("main_metric"), "leader": leader,
           "targets_reached": sum(1 for x in wl if x["equity"] >= 600),
           "summary": {"start_total": START * 5, "equity_total": eq_total,
                       "pnl": round(eq_total - START * 5, 2),
                       "open_total": sum(x["open"] for x in wl), "max_open_total": MAX_OPEN * 5},
           "wallets": wl}
    fd, tmp = tempfile.mkstemp(dir=BASE, prefix=".fwjson")
    with os.fdopen(fd, "w") as f: json.dump(doc, f)
    os.replace(tmp, f"{BASE}/fwtest.json")

if __name__ == "__main__":
    if "--report" in sys.argv:
        st = load(STATE)
        print(block(st) if st else "NOT STARTED")
        raise SystemExit
    st = init()
    if "--once" in sys.argv:
        tick(st); print(block(load(STATE))); raise SystemExit
    while True:
        try:
            st = load(STATE) or init()
            tick(st)
        except Exception as e:
            try: ledger({"type": "error", "err": str(e)[:200]})
            except Exception: pass
        time.sleep(60)
