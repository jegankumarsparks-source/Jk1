CREATE TABLE tokens(mint TEXT PRIMARY KEY, sym TEXT, name TEXT, pair TEXT, dex TEXT,
  pair_created REAL, first_seen REAL, icon TEXT, json TEXT);
CREATE TABLE snapshots(mint TEXT, ts REAL, price REAL, mc REAL, liq REAL, fdv REAL,
  v5m REAL, v1h REAL, v6h REAL, v24h REAL, b5m INT, s5m INT, b1h INT, s1h INT,
  pc5m REAL, pc1h REAL, pc6h REAL, pc24h REAL, holders INT, top10 REAL, json TEXT,
  PRIMARY KEY(mint, ts));
CREATE TABLE signals(signal_id TEXT PRIMARY KEY, mint TEXT, first_detected REAL,
  first_signal REAL, last_update REAL, stage TEXT, last_score REAL, highest_score REAL,
  highest_multiple REAL DEFAULT 1, entry_mc REAL, entry_price REAL, entry_liq REAL,
  entry_v1h REAL, entry_b1h INT, entry_holders INT, ai_score REAL, risk_score REAL,
  smart_score REAL, targets_hit TEXT DEFAULT '', dead INT DEFAULT 0);
CREATE TABLE wallet_activity(mint TEXT, wallet TEXT, ts REAL, sol REAL,
  PRIMARY KEY(mint, wallet, ts));
CREATE TABLE smart_wallets(wallet TEXT PRIMARY KEY, source TEXT, be_mult REAL,
  trades INT DEFAULT 0, wins INT DEFAULT 0, first_seen REAL);
CREATE TABLE risk_events(id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT, ts REAL,
  kind TEXT, detail TEXT);
CREATE TABLE sqlite_sequence(name,seq);
CREATE TABLE outcomes(signal_id TEXT, horizon TEXT, ts REAL, multiple REAL,
  drawdown REAL, PRIMARY KEY(signal_id, horizon));
CREATE TABLE tg_messages(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, mint TEXT,
  kind TEXT, message_id INT);
CREATE TABLE sys_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, lane TEXT, msg TEXT);
CREATE TABLE model_versions(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL,
  version TEXT, weights TEXT, backtest TEXT, active INT);
CREATE TABLE wallets (
  wallet_address TEXT PRIMARY KEY,
  first_seen TEXT, last_active TEXT,
  total_trades_tracked INTEGER DEFAULT 0,
  total_tokens_traded INTEGER DEFAULT 0,
  early_entries INTEGER DEFAULT 0,
  successful_early_entries INTEGER DEFAULT 0,
  maximum_multiple_observed REAL DEFAULT 0,
  average_max_multiple REAL DEFAULT 0,
  median_max_multiple REAL DEFAULT 0,
  average_holding_time REAL DEFAULT 0,
  profitable_trade_count INTEGER DEFAULT 0,
  loss_trade_count INTEGER DEFAULT 0,
  rug_exposure INTEGER DEFAULT 0,
  average_entry_market_cap REAL DEFAULT 0,
  average_entry_liquidity REAL DEFAULT 0,
  average_position_size REAL DEFAULT 0,
  win_rate REAL DEFAULT 0,
  early_entry_score REAL DEFAULT 0,
  consistency_score REAL DEFAULT 0,
  risk_score_w REAL DEFAULT 0,
  smart_wallet_score REAL DEFAULT 0,
  last_30d_activity INTEGER DEFAULT 0,
  last_7d_activity INTEGER DEFAULT 0,
  last_24h_activity INTEGER DEFAULT 0,
  current_active_positions INTEGER DEFAULT 0,
  classification TEXT DEFAULT 'UNKNOWN',
  source TEXT DEFAULT 'seed',
  funding_source TEXT,
  updated_at TEXT
);
CREATE TABLE wallet_trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  wallet_address TEXT, token_address TEXT,
  entry_time TEXT, entry_market_cap REAL, entry_liquidity REAL,
  entry_volume REAL, entry_holder_count INTEGER, entry_price REAL,
  entry_position_usd REAL,
  token_creation_time TEXT, first_liquidity_time TEXT,
  seconds_after_launch REAL,
  max_multiple REAL DEFAULT 0, max_drawdown REAL DEFAULT 0,
  time_to_max_seconds REAL, exit_time TEXT,
  reached_15x INTEGER DEFAULT 0, reached_2x INTEGER DEFAULT 0,
  reached_3x INTEGER DEFAULT 0, reached_5x INTEGER DEFAULT 0,
  reached_10x INTEGER DEFAULT 0,
  outcome TEXT DEFAULT 'open',
  is_early_entry INTEGER DEFAULT 0,
  quality_flag TEXT DEFAULT 'genuine',
  UNIQUE(wallet_address, token_address, entry_time)
);
CREATE TABLE wallet_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  wallet_address TEXT, token_address TEXT,
  event_time TEXT, event_type TEXT,
  wallet_score REAL, entry_market_cap REAL, entry_liquidity REAL,
  entry_position_usd REAL, processed INTEGER DEFAULT 0
);
CREATE TABLE wallet_pairs (
  wallet_a TEXT, wallet_b TEXT,
  co_entry_count INTEGER DEFAULT 0,
  avg_time_diff_seconds REAL DEFAULT 0,
  shared_token_count INTEGER DEFAULT 0,
  shared_success_count INTEGER DEFAULT 0,
  shared_failure_count INTEGER DEFAULT 0,
  cluster_score REAL DEFAULT 0,
  updated_at TEXT,
  PRIMARY KEY (wallet_a, wallet_b)
);
CREATE TABLE clusters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token_address TEXT, detected_at TEXT,
  wallet_count INTEGER, independent_wallet_count INTEGER,
  avg_wallet_score REAL, top_wallet_score REAL,
  cluster_score REAL, window_seconds INTEGER,
  wallets TEXT, funding_clusters INTEGER DEFAULT 0,
  status TEXT DEFAULT 'WATCH'
);
CREATE TABLE rejections (id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, mint TEXT, sym TEXT, reason TEXT, mc REAL, liq REAL, age_s REAL);
CREATE TABLE funnel (ts REAL PRIMARY KEY, discovered INT, filtered INT, scored INT, watch INT, sm_watch INT, clusters INT, signals INT, tg_sent INT);
CREATE TABLE tg_delivery (id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, kind TEXT, mint TEXT, msg_id TEXT, ok INT, detail TEXT);
CREATE TABLE wallet_radar_candidates(
        mint TEXT PRIMARY KEY, sym TEXT, first_detected TEXT, last_update TEXT, last_reported TEXT,
        wallet_count INT, qualified_count INT, independent_count INT, related_count INT,
        best_wallet_score REAL, combined_score REAL, cluster_score REAL, freshness TEXT,
        first_entry TEXT, latest_entry TEXT, rank_score REAL, report_hash TEXT,
        detail_json TEXT, status TEXT);
CREATE TABLE wallet_radar_outcomes(
        mint TEXT PRIMARY KEY, signal_time TEXT, entry_price REAL, entry_mc REAL, entry_liq REAL,
        wallet_count INT, independent_count INT, best_wallet_score REAL, cluster_score REAL,
        rank_score REAL, max_multiple REAL, max_observed_at TEXT, time_to_peak_s REAL,
        max_drawdown REAL, reached_2x INT, reached_3x INT, reached_5x INT, reached_10x INT,
        last_price REAL, last_check TEXT, status TEXT, entry_volume REAL, reached_1_5x INT DEFAULT 0, reached_1_5x_at TEXT, reached_2x_at TEXT, reached_3x_at TEXT, reached_5x_at TEXT, reached_10x_at TEXT, time_to_1_5x_s REAL, time_to_2x_s REAL, time_to_3x_s REAL, time_to_5x_s REAL, note TEXT);
CREATE TABLE sig_signals (
  sig_id TEXT PRIMARY KEY, mint TEXT, sym TEXT, state TEXT, score REAL,
  factors_json TEXT, blocked_reason TEXT, created_at REAL, updated_at REAL,
  last_alert_at REAL, alert_count INTEGER DEFAULT 0);
CREATE TABLE sig_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, sig_id TEXT, ts REAL, kind TEXT, detail TEXT);
CREATE TABLE sig_trades (
  sig TEXT PRIMARY KEY, mint TEXT, pair TEXT, side TEXT,
  usd REAL, owner TEXT, ts REAL, recv_at REAL);
CREATE INDEX sig_trades_mint_ts ON sig_trades(mint, ts);
CREATE TABLE sig_v2_cfg (
  key TEXT PRIMARY KEY, value REAL);
CREATE TABLE sig_wallet_profiles (
  wallet TEXT PRIMARY KEY, quality REAL, label TEXT, insufficient INTEGER,
  profile_json TEXT, updated_at REAL);
CREATE TABLE sig_clusters (
  id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT, detected_at REAL,
  n_wallets INTEGER, total_usd REAL, span_s REAL, avg_quality REAL,
  buy_accel REAL, overlap_hint TEXT, wallets_json TEXT, n_independent INTEGER, independence_status TEXT,
  UNIQUE(mint, detected_at));
CREATE TABLE sig_scores_v2 (
  sig_id TEXT, ts REAL, score_v2 REAL, score_prod REAL, components_json TEXT,
  why_json TEXT, quality_gate TEXT, PRIMARY KEY (sig_id, ts));
CREATE TABLE sig_latency (
  id INTEGER PRIMARY KEY AUTOINCREMENT, sig_id TEXT, onchain_ts REAL, stored_ts REAL,
  detected_ts REAL, scored_ts REAL, telegram_ts REAL, source TEXT);
CREATE TABLE sig_wallet_funding (
  wallet TEXT PRIMARY KEY, funder TEXT, funded_ts REAL, method TEXT,
  resolved_at REAL, evidence TEXT);
CREATE TABLE sig_security_provenance (
  mint TEXT PRIMARY KEY, status TEXT, provider TEXT, evidence TEXT, checked_at REAL);
CREATE TABLE sig_v2_observability (
  key TEXT PRIMARY KEY, value INTEGER);
CREATE TABLE sig_v2_candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT, sig_id TEXT, mint TEXT, ts REAL,
  prod_score REAL, v2_score REAL, prod_decision TEXT, v2_decision TEXT,
  ts_diff_s REAL, why_diff TEXT);
CREATE TABLE sig_v2_cluster_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT, sig_id TEXT, ts REAL,
  kind TEXT, detail_json TEXT);
CREATE TABLE sig_v2_candidate_evidence (
  id INTEGER PRIMARY KEY AUTOINCREMENT, sig_id TEXT, mint TEXT, ts REAL,
  prod_score REAL, v2_score REAL, prod_decision TEXT, v2_decision TEXT,
  wallet_quality_max REAL, n_quality_wallets INTEGER, funding_independence TEXT,
  data_fresh INTEGER, usd_volume_1h REAL, liquidity REAL, security_provenance TEXT,
  net_pressure REAL, token_age_h REAL, entry_ts REAL, reason TEXT, diff_type TEXT);
CREATE TABLE sig_v2_outcomes (
  trade_id TEXT PRIMARY KEY, signal_id TEXT, mint TEXT, strategy TEXT,
  entry_price REAL, exit_price REAL, roi_pct REAL, pnl_usd REAL,
  mfe_pct REAL, mae_pct REAL, max_drawdown_pct REAL, holding_s REAL,
  outcome_type TEXT, signal_reason TEXT, ts REAL, outcome_class TEXT, t_to_50_s REAL, t_to_100_s REAL, t_to_reversal_s REAL);
CREATE TABLE sig_v2_false_positives (
  id INTEGER PRIMARY KEY AUTOINCREMENT, signal_id TEXT, mint TEXT, trade_id TEXT,
  ts REAL, category TEXT, facts_json TEXT);
CREATE TABLE sig_v2_exit_ab (
  trade_id TEXT PRIMARY KEY, signal_id TEXT, mint TEXT, strategy TEXT,
  entry_price REAL, entry_at REAL, exit_at REAL, actual_exit_price REAL,
  actual_roi_pct REAL, actual_pnl_usd REAL, actual_outcome TEXT,
  max_price REAL, max_price_src TEXT,
  reached_50 INTEGER, reached_50_ts REAL, reached_100 INTEGER, reached_100_ts REAL,
  exit_15x_price REAL, roi_15x_pct REAL, pnl_15x_usd REAL,
  roi_diff_pct REAL, pnl_diff_usd REAL,
  mfe_pct REAL, mae_pct REAL, dd_after_50_pct REAL,
  reversal_after_50 INTEGER, status TEXT, note TEXT, updated_ts REAL, max_price_after_50 REAL, reversed_before_100 INTEGER, pnl_partial_usd REAL, t_entry_to_50_s REAL, t_50_to_100_s REAL, outcome_after_50 TEXT, partial_note TEXT);
CREATE TABLE sig_v2_qual_snapshots (
  signal_id TEXT PRIMARY KEY, mint TEXT, qual_ts REAL, snap_ts REAL,
  prod_score REAL, v2_score REAL, wallet_quality REAL, n_wallets INTEGER,
  funding_independence TEXT, net_pressure REAL, usd_volume_1h REAL, liquidity REAL,
  vol_to_liq REAL, token_age_h REAL, earlyness_s REAL, security_provenance TEXT,
  data_fresh INTEGER, entry_price REAL, market_cap REAL, outcome_class TEXT DEFAULT 'PENDING');
CREATE TABLE sig_v2_entry_evidence (
  signal_id TEXT PRIMARY KEY, mint TEXT, entry_ts REAL, captured_ts REAL,
  wallet_addresses TEXT, wallet_count INTEGER,
  funding_independence TEXT, net_pressure REAL, net_pressure_status TEXT,
  security_provenance TEXT, data_fresh INTEGER, data_age_s REAL,
  liquidity REAL, usd_volume_1h REAL, token_age_h REAL,
  prod_score REAL, v2_score REAL,
  field_status_json TEXT, source_json TEXT, completeness_pct REAL, entry_rank_score REAL, entry_wallet_score REAL, entry_independent_count INTEGER, entry_cluster_score REAL, lane TEXT, score_applicability TEXT, score_status TEXT, reason_code TEXT);
CREATE TABLE sig_v2_evidence_refresh (
  id INTEGER PRIMARY KEY AUTOINCREMENT, signal_id TEXT, mint TEXT,
  retrieved_ts REAL, source_ts REAL, field TEXT, value TEXT, source TEXT);
CREATE VIEW v_t0_sig_lane AS
SELECT e.signal_id, e.mint, e.entry_ts, e.captured_ts, e.prod_score, e.v2_score,
       e.score_applicability, e.score_status, e.reason_code, e.completeness_pct,
       o.trade_id, o.outcome_type, o.roi_pct, o.pnl_usd, o.ts AS outcome_ts
FROM sig_v2_entry_evidence e LEFT JOIN sig_v2_outcomes o ON o.signal_id=e.signal_id
WHERE COALESCE(e.lane, CASE WHEN e.signal_id LIKE 'SIG-%' THEN 'SIG' WHEN e.signal_id LIKE 'TIER-%' THEN 'TIER' WHEN e.signal_id LIKE 'WRO-%' THEN 'WRO' ELSE 'other' END)='SIG'
/* v_t0_sig_lane(signal_id,mint,entry_ts,captured_ts,prod_score,v2_score,score_applicability,score_status,reason_code,completeness_pct,trade_id,outcome_type,roi_pct,pnl_usd,outcome_ts) */;
CREATE VIEW v_t0_wallet_lane AS
SELECT e.signal_id, e.mint, e.entry_ts, e.captured_ts,
       e.entry_rank_score, e.entry_wallet_score, e.entry_independent_count, e.entry_cluster_score,
       e.wallet_count, e.funding_independence, e.liquidity, e.token_age_h, e.security_provenance,
       e.score_applicability, e.score_status, e.reason_code, e.completeness_pct,
       o.trade_id, o.outcome_type, o.roi_pct, o.pnl_usd, o.ts AS outcome_ts
FROM sig_v2_entry_evidence e LEFT JOIN sig_v2_outcomes o ON o.signal_id=e.signal_id
WHERE COALESCE(e.lane, CASE WHEN e.signal_id LIKE 'SIG-%' THEN 'SIG' WHEN e.signal_id LIKE 'TIER-%' THEN 'TIER' WHEN e.signal_id LIKE 'WRO-%' THEN 'WRO' ELSE 'other' END) IN ('TIER','WRO','other')
/* v_t0_wallet_lane(signal_id,mint,entry_ts,captured_ts,entry_rank_score,entry_wallet_score,entry_independent_count,entry_cluster_score,wallet_count,funding_independence,liquidity,token_age_h,security_provenance,score_applicability,score_status,reason_code,completeness_pct,trade_id,outcome_type,roi_pct,pnl_usd,outcome_ts) */;
CREATE TABLE shadow_signals (
  signal_id TEXT PRIMARY KEY, token TEXT NOT NULL, detected_at REAL NOT NULL,
  signal_state TEXT NOT NULL, entry_reference TEXT, exit_reference TEXT, outcome_id TEXT,
  qualification TEXT NOT NULL DEFAULT 'PENDING DATA');
CREATE TABLE shadow_trades (
  trade_id TEXT PRIMARY KEY, signal_id TEXT NOT NULL REFERENCES shadow_signals(signal_id),
  strategy TEXT NOT NULL, entry_reference TEXT UNIQUE NOT NULL, entry_at REAL NOT NULL,
  entry_price REAL NOT NULL CHECK(entry_price>0), position_usd REAL NOT NULL CHECK(position_usd>0),
  exit_reference TEXT UNIQUE, exit_at REAL, exit_price REAL CHECK(exit_price>0),
  outcome_id TEXT UNIQUE, status TEXT NOT NULL, reason TEXT,
  CHECK(exit_at IS NULL OR exit_at>=entry_at));
CREATE TABLE shadow_events (
  event_id TEXT PRIMARY KEY, signal_id TEXT NOT NULL REFERENCES shadow_signals(signal_id),
  trade_id TEXT REFERENCES shadow_trades(trade_id), ts REAL NOT NULL,
  state TEXT NOT NULL, reason TEXT NOT NULL, price REAL CHECK(price>0));
CREATE INDEX shadow_events_trade_time ON shadow_events(trade_id,ts);
